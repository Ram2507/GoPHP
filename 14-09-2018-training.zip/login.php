<?php 
session_start();
if(isset($_SESSION['loggedin']))
{
	header("Location:dashboard.php");
}
include("connect.php");
include("header.php");

?>

<div class="container">

	<!-- Page Heading/Breadcrumbs -->
	<h1 class="mt-4 mb-3">Login</h1>

	<ol class="breadcrumb">
		<li class="breadcrumb-item">
		  <a href="index.html">Home</a>
		</li>
		<li class="breadcrumb-item active">Login</li>
	</ol>
	<div class="row">
			
			<?php 
				if(isset($_POST['login']))
				{
					$email=$_POST['email'];
					$pass=md5($_POST['pwd']);
					$result=mysqli_query($con,
					"select *from register where email='$email'");
					if(mysqli_num_rows($result)==1)
					{
						$row=mysqli_fetch_assoc($result);
						if($row['password']==$pass)
						{
							if($row['status']==1)
							{
								$_SESSION['loggedin']=$row['id'];
								//header("Location:dashboard.php");
								?>
								<script>
									window.location="dashboard.php";
								</script>
								<?php
							}
							else
							{
								echo "<p class='alert alert-warning'>Please activate your account</p>";
							}
								
						}
						else
						{
							echo "<p class='alert alert-danger'>Password doesn't matched</p>";
						}
					}
					else
					{
						echo "<p class='alert alert-danger'>Email doesn't exists</p>";
					}
					
				}
			?>
		</div>
		<div>			
			<form action="" method="POST">
			
				<table class="table">
					
					<tr>
						<td>Email</td>
						<td>
							<input class="form-control" 
							type="text" name="email" id="email">
							
						</td>
					</tr>
					<tr>
						<td>Password</td>
						<td>
							<input class="form-control" 
							type="password" name="pwd" id="pwd"> 
							
						</td>
					</tr>

					<tr>
						<td></td>
						<td><input type="submit" name="login" 
						value="Login" class="btn btn-primary">
						<a href="">Forgot Password?</a>
						</td>
					</tr>
				</table>
			</form>	
	</div>
</div>

<?php 
include("footer.php");
?>