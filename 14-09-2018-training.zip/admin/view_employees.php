<?php 
session_start();
if(isset($_SESSION['adminlogin']))
{
	include("../connect.php");//$con
	include("header.php");
	?>
		
	<div id='page-wrapper'>
		<h2>View Employees</h2>
		
		<?php 
		if(isset($_COOKIE['success']))
		{
			echo "<p>".$_COOKIE['success']."</p>";
		}
		?>
		<?php 
		
		$result=mysqli_query($con,"select *from employee");
		if(mysqli_num_rows($result)>0)
		{
			?>
				<table border=1 class='table'>
				<tr>
					<th>Emp Id</th>
					<th>Name</th>
					<th>Email</th>
					<th>Mobile</th>
					<th>City</th>
					<th>Salary</th>
					<th>Status</th>
					<th>DOJ</th>
					<th>Action</th>
				</tr>
				<?php 
				while($row=mysqli_fetch_assoc($result))
				{
					?>
					<tr>
						<td><?php echo $row['eid']; ?></td>
						<td><?php echo $row['name']; ?></td>
						<td><?php echo $row['email']; ?></td>
						<td><?php echo $row['mobile']; ?></td>
						<td><?php echo $row['city']; ?></td>
						<td><?php echo $row['salary']; ?></td>
						<td><?php echo $row['status']; ?></td>
						<td><?php echo $row['date']; ?></td>
						<td>
							<a href="edit_employee.php?eid=<?php echo $row['eid'];?>"><i class='fa fa-pencil'></i></a>
							<a onclick="deleteRecord(<?php echo $row['eid']?>)" href="javascript:void(0)"><i class='fa fa-trash text-danger'></i></a>
						</td>
					</tr>
					<?php
				}
				?>
			</table>
			<?php
		}
		else
		{
			echo "<p>No Records Found</p>";
		}
		?>
		<script>
			function deleteRecord(id)
			{
				var c=confirm("do you want to delete?");
				if(c==true)
				{
					window.location="delete_employee.php?did="+id;
				}
			}
		</script>
		</div>
	
	<?php
	include("footer.php");
}
else
{
	header("Location:index.php");
}
?>