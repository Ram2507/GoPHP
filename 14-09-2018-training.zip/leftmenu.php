<div class="col-lg-3 mb-4">
		<div class="list-group">
            
            <?php 
			if($row['profile_pic']!="")
			{
				?>
					<a href="#" class="list-group-item">
						<div class='text-center'>
							<img style="border-radius:50px;" src="profiles/<?php echo $row['profile_pic']?>" height="80" width="80">
						</div>
					</a>
				<?php
			}
			?>
            <a href="dashboard.php" class="list-group-item">Dashboard</a>
            <a href="avatar.php" class="list-group-item">Upload Avatar</a>
			<a href="edit.php" class="list-group-item">Edit Profile</a>
            <a href="change_pass.php" class="list-group-item">Change password</a>
            <a href="logout.php" class="list-group-item">Logout</a>
		</div>
        </div>
