<?php 
class UserModel extends CI_Model
{
    public function getLoggedInUserData()
    {
        $id=$this->session->userdata("user_login");
        $res=$this->db->query("select *from register where id=$id");
        return $res->row_object();
    }
    public function updateUser($uname,$mobile,
            $addr,$city,$state)
    {
        $id=$this->session->userdata("user_login");
        $this->db->query("update register set 
                username=$uname,mobile=$mobile,
                city=$city,state=$state,
                address=$addr where id=$id");
        return $this->db->affected_rows();
    }
    public function updatePassword($npwd)
    {
         $id=$this->session->userdata("user_login");
         $this->db->query("update register set password='$npwd'
                 where id=$id");
         return $this->db->affected_rows();
    }
    public function uploadProfile($filename)
    {
         $id=$this->session->userdata("user_login");
          $this->db->query("update register set profile_pic='$filename'
                 where id=$id");
         return $this->db->affected_rows();
    }
}

?>