<?php

class SliderModel extends CI_Model
{
    public function addSlider($title,$subtitle,$link,$fimage,$bimage)
    {
        date_default_timezone_set("Asia/Calcutta");
        $data=array(
            "title"=>$title,
            "sub_title"=>$subtitle,
            "background_image"=>$bimage,
            "front_end_image"=>$fimage,
            "button_link"=>$link,
            "date"=>date("Y-m-d h:i:s"),
        );
        $this->db->insert("slider",$data);
        if($this->db->affected_rows()>0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    public function getAllSliders($role)
    {
        $this->db->order_by("id","desc");
        if($role=="user")
        {
            $this->db->where("status",1);
        }
        $result=$this->db->get("slider");
        if($result->num_rows()>0)
        {
            return $result->result();
        }
        else
        {
            return FALSE;
        }
    }
    public function getSliderInfo($id)
    {
        $this->db->where("id",$id);
        $result=$this->db->get("slider");
        if($result->num_rows()==1)
        {
            return $result->row_object();
        }
        else
        {
            return false;
        }
    }
    public function UpdateSlider($id,$title,$subtitle,$link,$fimage,$bimage)
    {
        $data=array(
            "title"=>$title,
            "sub_title"=>$subtitle,
            "button_link"=>$link,
            "background_image"=>$bimage,
            "front_end_image"=>$fimage,
        );
        $this->db->where("id",$id);
        $this->db->update("slider",$data);
        if($this->db->affected_rows()>0)
        {
            return true;
        }
        else
        {
            return FALSE;
        }
    }
}

