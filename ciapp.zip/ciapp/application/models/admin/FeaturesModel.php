<?php

class FeaturesModel extends CI_Model
{
    public function insertFeature($data)
    {
        $this->db->insert("features",$data);
        if($this->db->affected_rows()>0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    public function getAllFeatures()
    {
        $this->db->order_by("id","RANDOM");
        $result=$this->db->get("features");
        if($result->num_rows()>0)
        {
            return $result->result();
        }
        else
        {
            return false;
        }
    }
    public function getFeature($id)
    {
        $this->db->where("id",$id);
        $result=$this->db->get("features");
        if($result->num_rows()==1)
        {
            return $result->row_object();
        }
        else
        {
            return false;
        }
    }
    public function updateFeature($data,$id)
    {
        $this->db->where("id",$id);
        $this->db->update("features",$data);
        if($this->db->affected_rows()>0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}