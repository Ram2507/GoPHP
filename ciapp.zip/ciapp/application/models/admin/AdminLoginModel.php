<?php 
class AdminLoginModel extends CI_Model
{
    public function login($data)
    {
        $this->db->where($data);
        $res=$this->db->get("admin");
        return $res->row_array();
    }
}
?>