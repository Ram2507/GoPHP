<?php

class AdminUserModel extends CI_Model
{
    public function getAllUsers($start,$end)
    {
        $this->db->order_by("id","desc");
        $this->db->limit($end,$start);
        $result=$this->db->get("register");
        return $result->result();
    }
}

