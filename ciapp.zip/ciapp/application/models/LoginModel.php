<?php
class LoginModel extends CI_Model
{
    public function checkCredentials($email,$pwd)
    {
        $result=$this->db->query("select *from register
                 where email=$email and password=$pwd");
        if($result->num_rows()==1)
        {
            return $result->row();
        }
        else
        {
            return false;
        }
    }
    public function checkEmail($email)
    {
        $result=$this->db->query("select *from register where email=$email");
        if($result->num_rows()==1)
        {
            return $result->row();
        }
        else
        {
            return false;
        }
    }
    public function updatePassword($pwd, $uid)
    {
        $this->db->query("update register set password=$pwd where email='$uid'");
        if($this->db->affected_rows()==1)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}

