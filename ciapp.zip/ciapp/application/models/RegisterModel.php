<?php
class RegisterModel extends CI_Model
{
    public function insertData($uname,$email,$password,$mobile,$gender,
            $addr,$city,$state,$terms,$date,$ip)
    {
        //echo $this->db->simple_query();
        $this->db->query("insert into register(username,email,password,
            mobile,gender,
                address,state,city,terms,date_of_reg,ip) values ($uname,$email,
                $password,$mobile,$gender,$addr,$state,$city,$terms,
                $date,$ip)");
        if($this->db->affected_rows()==1)
        {
            return $this->db->insert_id();
        }
        else
        {
            return false;
        }
    }
}