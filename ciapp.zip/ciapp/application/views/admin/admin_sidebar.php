<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo base_url()?>assets/images/avatar5.png" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?php echo $this->session->userdata('admin_login')['username']  ?></p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
     
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
        <li class="header">MAIN NAVIGATION</li>
        <li class="active treeview">
          <a href="<?php echo base_url()."admin/home"?>">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
        </li>
        <li>
          <a href="<?php echo base_url()."admin/users"?>">
            <i class="fa fa-th"></i> <span>Users</span>
            <span class="pull-right-container">
              <small class="label pull-right bg-green">new</small>
            </span>
          </a>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-files-o"></i>
            <span>Features</span>
            <span class="pull-right-container">
              <span class="label label-primary pull-right">4</span>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url()."admin/features/add";?>"><i class="fa fa-circle-o"></i>Add Feature</a></li>
            <li><a href="<?php echo base_url()."admin/features/view";?>"><i class="fa fa-circle-o"></i>View Fetures</a></li>
           
          </ul>
        </li>
        
        <li class="treeview">
          <a href="#">
            <i class="fa fa-files-o"></i>
            <span>Slider Section</span>
            <span class="pull-right-container">
              <span class="label label-primary pull-right">New</span>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url() ?>admin/slider/add"><i class="fa fa-circle-o"></i>Add Slider</a></li>
            <li><a href="<?php echo base_url() ?>admin/slider/view"><i class="fa fa-circle-o"></i>View Slider</a></li>
           
          </ul>
        </li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>