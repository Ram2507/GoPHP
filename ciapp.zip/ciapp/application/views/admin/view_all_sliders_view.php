
  <!-- Left side column. contains the logo and sidebar -->
  

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Slider
        <small>Dashboard</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Slider</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
       
          <div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">View Sliders Table</h3>
              <?php 
              if($this->session->tempdata("delete_error"))
              {
                  echo "<div class='alert alert-danger'>".$this->session->tempdata("delete_error")."</div>";
              }
            if($this->session->tempdata("delete_success"))
              {
                  echo "<div class='alert alert-success'>".$this->session->tempdata("delete_success")."</div>";
              }
            if($this->session->tempdata("hs_success"))
            {
                echo "<div class='alert alert-success'>".$this->session->tempdata("hs_success")."</div>";
            }
            if($this->session->tempdata("hs_error"))
              {
                  echo "<div class='alert alert-danger'>".$this->session->tempdata("hs_error")."</div>";
              }
              ?>
              
            </div>
            <!-- /.box-header -->
            <div class="box-body">
               
                <?php
               
                if(!is_bool($sliders))
                {
                    ?>
                    <table class="table">
                        <tr>
                            <th>Id</th>
                            <th>Title</th>
                            <th>Sub Title</th>
                            <th>Background Image</th>
                            <th>Front End Image</th>
                            <th>Link</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                        <?php 
                        foreach($sliders as $slider)
                        {
                            ?>
                        <tr>
                            <td><?php echo $slider->id; ?></td>
                            <td><?php echo $slider->title; ?></td>
                            <td><?php echo $slider->sub_title; ?></td>
                            <td>
                                <a href="<?php echo base_url()."assets/slider/".$slider->background_image; ?>" class="preview" rel="prettyPhoto">
                                    <img src="<?php echo base_url()."assets/slider/".$slider->background_image; ?>"class="img-responsive" />
                                </a>
                                
                            </td>
                                
                            <td><img src="<?php echo base_url()."assets/slider/".$slider->front_end_image; ?>"class="img-responsive"></td>
                            <td><?php echo $slider->button_link; ?></td>
                            <td><?php echo $slider->status; ?></td>
                            <td>
                                <a href='<?php echo base_url()."admin/slider/edit/".$slider->id; ?>'>Edit</a>
                                <a href='javascript:void(0)' onclick="deleteSlider('<?php echo base_url()."admin/slider/delete/".$slider->id; ?>')">Delete</a>
                                <?php 
                                if($slider->status==0)
                                {
                                    echo "<a href='".base_url()."admin/slider/hideShow/".$slider->id."'>Show</a>";
                                }
                                else
                                {
                                    echo "<a href='".base_url()."admin/slider/hideShow/".$slider->id."'>Hide</a>";
                                }
                                ?>
                            </td>
                        </tr>
                            
                        <?php
                        }
                        ?>
</table>
<?php
                }
                else
                {
                    echo "<p class='alert alert-success'>Sorry! Sliders Not Found. Please <a href='".base_url()."admin/slider/add'>Add Now</a> </p>";
                }
                ?>
            </div>
            <!-- /.box-body -->
            
           
            
            <div class="box-footer clearfix">
            
            </div>
          </div>
          <!-- /.box -->

          
          <!-- /.box -->
        </div>
       
      </div>
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        
      </div>
      

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <script>
  function deleteSlider(url) 
  {
    var c=confirm("Do you want to Delete ?");
    if(c==true)
    {
        window.location=url;
    }
  }
  </script>