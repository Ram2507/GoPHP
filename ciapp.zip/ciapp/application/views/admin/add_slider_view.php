
  <!-- Left side column. contains the logo and sidebar -->
  

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Slider
        <small>Dashboard</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Add Slider</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
       
          <div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Add Slider</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                
                <?php 
                if($this->session->tempdata("success"))
                {
                    echo "<div class='alert alert-success'>".$this->session->tempdata("success")."</div>";
                }
                ?>
                
                <?php echo form_open_multipart(base_url()."admin/slider/add") ?>
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" name="title" class="form-control" value="<?php echo set_value("title")?>">
                    <span class="text-danger"><?php echo form_error("title")?></span>
                </div>
                 <div class="form-group">
                    <label>Sub Title</label>
                    <input type="text" name="subtitle" class="form-control" value="<?php echo set_value("subtitle")?>">
                    <span class="text-danger"><?php echo form_error("subtitle")?></span>
                </div>
                <div class="form-group">
                    <label>Upload Background Image</label>
                    <input type="file" name="bimage" class="form-control">
                    <span class="text-danger"><?php echo form_error("bimage")?></span>
                    <span class="text-danger"><?php if(isset($berrors)){
                    echo $berrors;
                }?></span>
                </div>
                <div class="form-group">
                    <label>Upload Fornt End Image(400wx600h)</label>
                    <input type="file" name="fimage" class="form-control">
                    <span class="text-danger"><?php echo form_error("fimage")?></span>
                     <span class="text-danger"><?php if(isset($ferrors)){
                    echo $ferrors;
                }?></span>
                </div>
                 <div class="form-group">
                    <label>Enter Button Link</label>
                    <input type="text" name="link" class="form-control" value="<?php echo set_value("link")?>">
                    <span class="text-danger"><?php echo form_error("link")?></span>
                </div>
                 <div class="form-group">
                    <input type="submit" value="Add Slider" class="btn btn-success">
                </div>
                <?php echo form_close()?>
            </div>
           
            <div class="box-footer clearfix">
             
            </div>
          </div>
          <!-- /.box -->

          
          <!-- /.box -->
        </div>
       
      </div>
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        
      </div>
      

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  