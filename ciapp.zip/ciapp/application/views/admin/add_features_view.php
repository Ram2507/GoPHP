
  <!-- Left side column. contains the logo and sidebar -->
  

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Features
        <small>Dashboard</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Add Feature</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
       
          <div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Add Feature</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                
                <?php 
                if($this->session->tempdata("success"))
                {
                    echo "<div class='alert alert-success'>".$this->session->tempdata("success")."</div>";
                }
                ?>
                
                <?php echo form_open_multipart(base_url()."admin/features/add") ?>
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" name="title" class="form-control" value="<?php echo set_value("title");?>">
                    <span class="text-danger"><?php echo form_error("title") ?></span>
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="desc" class="form-control"><?php echo set_value("desc");?></textarea>
                    <span class="text-danger"><?php echo form_error("desc") ?></span>
                </div>
                <div class="form-group">
                    <label>Select Icon</label>
                    <select name="icon" class="form-control">
                        <option value="">--Select Icon--</option>
                        <option value="fa fa-bullhorn" <?php if(set_value("icon")=="fa fa-bullhorn") echo "selected" ?>>fa fa-bullhorn</option>
                        <option value="fa fa-comments" <?php if(set_value("icon")=="fa fa-comments") echo "selected" ?>>fa fa-comments</option>
                        <option value="fa fa-cloud-download" <?php if(set_value("icon")=="fa fa-cloud-download") echo "selected" ?>>fa fa-cloud-download</option>
                        <option value="fa fa-leaf" <?php if(set_value("icon")=="fa fa-leaf") echo "selected" ?>>fa fa-leaf</option>
                        <option value="fa fa-cogs" <?php if(set_value("icon")=="fa fa-cogs") echo "selected" ?>>fa fa-cogs</option>
                        <option value="fa fa-heart" <?php if(set_value("icon")=="fa fa-heart") echo "selected" ?>>fa fa-heart</option>
                        <option value="fa fa-trash" <?php if(set_value("icon")=="fa fa-trash") echo "selected" ?>>fa fa-trash</option>
                        <option value="fa fa-pencil" <?php if(set_value("icon")=="fa fa-pencil") echo "selected" ?>>fa fa-pencil</option>
                        
                    </select>
                    <span class="text-danger"><?php echo form_error("icon") ?></span>
                </div>
                <div class="form-group">
                    
                    <input type="submit" value="Add" class="btn btn-success">
                </div>
                <?php echo form_close()?>
            </div>
           
            <div class="box-footer clearfix">
             
            </div>
          </div>
          <!-- /.box -->

          
          <!-- /.box -->
        </div>
       
      </div>
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        
      </div>
      

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  