
  <!-- Left side column. contains the logo and sidebar -->
  

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Features
        <small>Dashboard</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Features</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
       
          <div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">View Features Table</h3>
            
              <?php
              if($this->session->tempdata("success"))
              {
                  echo "<p class='alert alert-success'>".$this->session->tempdata("success")."</p>";
              }
               if($this->session->tempdata("error"))
              {
                  echo "<p class='alert alert-danger'>".$this->session->tempdata("error")."</p>";
              }
              ?>
              
            </div>
            <!-- /.box-header -->
            <div class="box-body">
               
               <?php 
               if(count($features)>0)
               {
                   ?>
                <table class="table">
                    <tr>
                        <th>Id</th>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Icon</th>
                        <th>Action</th>
                    </tr>
                    <?php 
                        foreach($features as $feature)
                        {
                            ?>
                    <tr>
                        <td><?php echo $feature->id; ?></td>
                        <td><?php echo $feature->title; ?></td>
                        <td><?php echo $feature->description; ?></td>
                        <td><i class="<?php echo $feature->icon; ?>"></i></td>
                        <td><a href="<?php echo base_url() ?>admin/features/edit/<?php echo $feature->id;?>" title="edit"><i class="fa fa-pencil"></i></a> 
                            &nbsp;&nbsp;
                            <a href="javascript:void(0)" onclick="deleteFeature('<?php echo base_url() ?>admin/features/delete/<?php echo $feature->id;?>')" title="delete"><i class="fa fa-trash-o text-danger"></i></a></td>
                        
                    </tr>
                    <?php
                        }
                    ?>
                </table>
                <?php
               }
               else
               {
                   echo "<p class='text-danger'>Sorry! Features Not found please <a href='".base_url()."admin/features/add'>Add NoW</a></p>";
               }
               ?>
            </div>
            <!-- /.box-body -->
            
           
            
            <div class="box-footer clearfix">
            
            </div>
          </div>
          <!-- /.box -->

          
          <!-- /.box -->
        </div>
       
      </div>
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        
      </div>
      

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <script>
  function deleteFeature(url) 
  {
    var c=confirm("Do you want to Delete ?");
    if(c==true)
    {
        window.location=url;
    }
  }
  </script>