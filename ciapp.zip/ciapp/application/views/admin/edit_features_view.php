
  <!-- Left side column. contains the logo and sidebar -->
  

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Features
        <small>Dashboard</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Edit Feature</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
       
          <div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Edit Feature</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                
                <?php 
                if($this->session->tempdata("success"))
                {
                    echo "<div class='alert alert-success'>".$this->session->tempdata("success")."</div>";
                }
                ?>
                
                <?php echo form_open_multipart(base_url()."admin/features/edit/".$feature->id); ?>
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" name="title" class="form-control" value="<?php echo $feature->title;?>">
                    <span class="text-danger"><?php echo form_error("title") ?></span>
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="desc" class="form-control"><?php echo $feature->description;?></textarea>
                    <span class="text-danger"><?php echo form_error("desc") ?></span>
                </div>
                <div class="form-group">
                    <label>Select Icon</label>
                    <select name="icon" class="form-control">
                        <option value="">--Select Icon--</option>
                        <option value="fa fa-bullhorn" <?php if($feature->icon=="fa fa-bullhorn") echo "selected" ?>>fa fa-bullhorn</option>
                        <option value="fa fa-comments" <?php if($feature->icon=="fa fa-comments") echo "selected" ?>>fa fa-comments</option>
                        <option value="fa fa-cloud-download" <?php if($feature->icon=="fa fa-cloud-download") echo "selected" ?>>fa fa-cloud-download</option>
                        <option value="fa fa-leaf" <?php if($feature->icon=="fa fa-leaf") echo "selected" ?>>fa fa-leaf</option>
                        <option value="fa fa-cogs" <?php if($feature->icon=="fa fa-cogs") echo "selected" ?>>fa fa-cogs</option>
                        <option value="fa fa-heart" <?php if($feature->icon=="fa fa-heart") echo "selected" ?>>fa fa-heart</option>
                        <option value="fa fa-trash" <?php if($feature->icon=="fa fa-trash-o") echo "selected" ?>>fa fa-trash-o</option>
                        <option value="fa fa-pencil" <?php if($feature->icon=="fa fa-pencil") echo "selected" ?>>fa fa-pencil</option>
                        
                    </select>
                    <span class="text-danger"><?php echo form_error("icon") ?></span>
                </div>
                <div class="form-group">
                    
                    <input type="submit" value="Update" class="btn btn-success">
                </div>
                <?php echo form_close()?>
            </div>
           
            <div class="box-footer clearfix">
             
            </div>
          </div>
          <!-- /.box -->

          
          <!-- /.box -->
        </div>
       
      </div>
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        
      </div>
      

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  