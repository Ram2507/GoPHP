
  <!-- Left side column. contains the logo and sidebar -->
  

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Slider
        <small>Dashboard</small>
      </h1>
        
        <ul class="nav navbar-nav">
            <li><a href="<?php echo base_url() ?>admin/slider/add">Add Slider</a></li>
            <li><a href="<?php echo base_url() ?>admin/slider/view">View Slider</a></li>
        </ul>
        
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Edit Slider</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
       
          <div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Edit Slider</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                
                <?php 
                if($this->session->tempdata("success"))
                {
                    echo "<div class='alert alert-success'>".$this->session->tempdata("success")."</div>";
                }
                ?>
                
                <?php echo form_open_multipart(base_url()."admin/slider/edit/".$id) ?>
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" name="title" class="form-control" value="<?php echo $slider->title;?>">
                    <span class="text-danger"><?php echo form_error("title")?></span>
                </div>
                 <div class="form-group">
                    <label>Sub Title</label>
                    <input type="text" name="subtitle" class="form-control" value="<?php echo $slider->sub_title;?>">
                    <span class="text-danger"><?php echo form_error("subtitle")?></span>
                </div>
                <div class="form-group">
                    <label>Upload Background Image</label>
                    <input type="file" name="bimage" class="form-control">
                    <span class="text-danger"><?php echo form_error("bimage")?></span>
                    <span class="text-danger"><?php if(isset($berrors)){
                    echo $berrors;
                }?></span>
                     <img alt="TRy to upload New Image" src="<?php echo base_url()."assets/slider/".$slider->background_image;?>" height="50" width="50">
                </div>
                <div class="form-group">
                    <label>Upload Fornt End Image(400wx600h)</label>
                    <input type="file" name="fimage" class="form-control">
                    <span class="text-danger"><?php echo form_error("fimage")?></span>
                     <span class="text-danger"><?php if(isset($ferrors)){
                    echo $ferrors;
                }?></span>
                    <img src="<?php echo base_url()."assets/slider/".$slider->front_end_image;?>" height="50" width="50">
                </div>
                 <div class="form-group">
                    <label>Enter Button Link</label>
                    <input type="text" name="link" class="form-control" value="<?php echo $slider->button_link;?>">
                    <span class="text-danger"><?php echo form_error("link")?></span>
                </div>
                 <div class="form-group">
                    <input type="submit" value="Update" class="btn btn-success">
                </div>
                <?php echo form_close()?>
            </div>
           
            <div class="box-footer clearfix">
             
            </div>
          </div>
          <!-- /.box -->

          
          <!-- /.box -->
        </div>
       
      </div>
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        
      </div>
      

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  