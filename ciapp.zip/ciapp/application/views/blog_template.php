<html>
        <head>
                <title>{blog_title}</title>
        </head>
        <body>
                <h3>{blog_heading}</h3>

      
                <h1>{blog_title}</h1>
                
        </body>
</html>