
<section id="feature" class="transparent-bg">
        <div class="container">
           <div class="center wow fadeInDown">
               <h2>Edit</h2>
                <?php
        if($this->session->tempdata("message"))
        {
            echo "<p class='alert alert-success'>".$this->session->tempdata("message")."</p>";
        }
        
        ?>
        
       <?php echo form_open();?>
        <table class="table">
            <tr>
                <td>Username</td>
                <td><input value="<?php echo $user->username;?>"
                           type="text" name="uname" class="form-control"></td>
            </tr>
            <tr>
                <td>Mobile</td>
                <td><input value="<?php echo $user->mobile;?>" 
                           type="text" name="mobile" class="form-control"></td>
            </tr>
            <tr>
                <td>Address</td>
                <td><textarea name="address" class="form-control"><?php echo $user->address;?></textarea></td>
            </tr>
            <tr>
                <td>City</td>
                <td><input value="<?php echo $user->city;?>" 
                           type="text" name="city" class="form-control"></td>
            </tr>
            <tr>
                <td>State</td>
                <td><select name="state" class="form-control">
                        <option value="">--Select State--</option>
            <option value="Andhrapradesh" 
                <?php if($user->state=="Andhrapradesh") 
                    echo "selected"; ?>>Andhrapradesh</option>
                        <option value="Maharastra" 
                <?php if($user->state=="Maharastra") 
                    echo "selected"; ?>>Maharastra</option>
                        <option value="Telanagana" <?php if($user->state=="Telanagana") echo "selected"; ?>>Telanagana</option>
                        <option value="Uttarpradesh" <?php if($user->state=="Uttarpradesh") echo "selected"; ?>>Uttarpradesh</option>
                    </select>
                     
                </td>
            </tr>
            <tr>
                <td></td>
                <td>
                    <input name="update" type="submit"
                           
                           value="Update" class="btn btn-success">
                </td>
            </tr>
        </table>
       <?php echo form_close();?>
                </div><!--/.services-->
            </div><!--/.row--> 


            

            

            

        </div><!--/.container-->
    </section><!--/#feature-->


           