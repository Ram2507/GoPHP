
<section id="feature" class="transparent-bg">
        <div class="container">
           <div class="center wow fadeInDown">
               <h2>
                   <?php if($user->profile_pic =="")
                   {
                       echo ' <a href=""><img src="'.base_url().'assets/images/blog/avatar3.png" height="80" width="80" class="img-circle"></a>';
                   }
                   else
                   {
                       ?>
                    <a href=""><img src="<?php echo base_url() ?>assets/profiles/<?php echo $user->profile_pic;?>" height="80" width="80" class="img-circle"></a>
                   <?php
                   }
                       ?>
                   
                   
                &nbsp;&nbsp;Welcome to <?php echo $user->username;?></h2>
                <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut <br> et dolore magna aliqua. Ut enim ad minim veniam</p>
            </div>

            <div class="row">
                <div class="features">
                   <table class="table">
            <tr>
                <td>Username:</td>
                <td><?php echo $user->username;?></td>
            </tr>
            <tr>
                <td>Email:</td>
                <td><?php echo $user->email;?></td>
            </tr>
            <tr>
                <td>Mobile:</td>
                <td><?php echo $user->mobile;?></td>
            </tr>
            <tr>
                <td>Address:</td>
                <td><?php echo $user->address;?></td>
            </tr>
            <tr>
                <td>City:</td>
                <td><?php echo $user->city;?></td>
            </tr>
            
            <tr>
                <td>State:</td>
                <td><?php echo $user->state;?></td>
            </tr>
            <tr>
                <td>Date of Reg:</td>
                <td><?php echo date("l, dS M Y",$user->date_of_reg);?></td>
            </tr>
        </table>

                </div><!--/.services-->
            </div><!--/.row--> 


            

            

            

        </div><!--/.container-->
    </section><!--/#feature-->


           