<section id="feature" class="transparent-bg">
        <div class="container">
           <div class="center wow fadeInDown">
                <h2><?php echo $this->lang->line("reg_title"); ?></h2>
                <p class="lead"><?php echo $this->lang->line("reg_desc"); ?></p>
            </div>

            <div class="row">
                <div class="features">
                     <?php 
          
            
                        if($this->session->tempdata("success")==1)
                        {
                            ?>
                            <p class='alert alert-success'>Account Created Successfully
                            Please activate your account</p>
                            <?php
                        }

                        ?>


                    <?php echo form_open(base_url()."register")?>
                    
                    
                    <!--<div class="form-group">
                        <label>Username</label>
                         <input type="text" 
                            value="<?php echo set_value("uname")?>" 
                            name="uname" class="form-control">
                     <span class="text-danger"><?php echo form_error("uname")?></span>
                    </div>-->
                    
                    
                    <table class="table">
                        <tr>
                            <td width="25%"><?php echo $this->lang->line('username') ;?></td>
                            <td>
                                <input type="text" 
                                       value="<?php echo set_value("uname")?>" 
                                       name="uname" class="form-control">
                                <span class="text-danger"><?php echo form_error("uname")?></span>
                            </td>
                        </tr>
                        <tr>
                            <td><?php echo $this->lang->line('email') ;?></td>
                            <td>
                                <input type="text" 
                                       value="<?php echo set_value("email")?>" 
                                       name="email" class="form-control">
                                <span class="text-danger"><?php echo form_error("email")?></span>
                            </td>
                        </tr>
                        <tr>
                            <td><?php echo $this->lang->line('password') ;?></td>
                            <td>
                                <input type="password" name="pwd" class="form-control">
                                 <span class="text-danger"><?php echo form_error("pwd")?></span>
                            </td>
                        </tr>
                        <tr>
                            <td><?php echo $this->lang->line('cpassword') ;?></td>
                            <td>
                                <input type="password" name="cpwd" class="form-control">
                                 <span class="text-danger"><?php echo form_error("cpwd")?></span>
                            </td>
                        </tr>
                        <tr>
                            <td><?php echo $this->lang->line('mobile') ;?></td>
                            <td>
                                <input type="text" 
                                       value="<?php echo set_value("mobile")?>" 
                                       name="mobile" class="form-control">
                                 <span class="text-danger"><?php echo form_error("mobile")?></span>
                            </td>
                        </tr>
                        <tr>
                            <td><?php echo $this->lang->line('gender') ;?></td>
                            <td><input type="radio" 
                                       name="gender" 
                        value="Male" <?php if(set_value("gender")=="Male") 
                            echo "checked";?>>Male &nbsp;
                            <input type="radio" 
                                   name="gender" 
                        value="Female" <?php if(set_value("gender")=="Female") 
                            echo "checked";?>>Female
                                 <span class="text-danger"><?php echo form_error("gender")?></span>
                            </td>
                        </tr>
                        <tr>
                            <td><?php echo $this->lang->line('address') ;?></td>
                            <td>
                                <textarea name="address" class="form-control"><?php echo set_value("address")?></textarea>
                                 <span class="text-danger"><?php echo form_error("address")?></span>
                            </td>
                        </tr>
                        <tr>
                            <td><?php echo $this->lang->line('city') ;?></td>
                            <td>
                                <input type="text" name="city" 
                                       value="<?php echo set_value("city")?>" class="form-control">
                                 <span class="text-danger"><?php echo form_error("city")?></span>
                            </td>
                        </tr>
                        <tr>
                            <td><?php echo $this->lang->line('state') ;?></td>
                            <td><select name="state" class="form-control">
                                    <option value="">--Select State--</option>
                                    <option value="Andhrapradesh" 
                        <?php if(set_value("state")=="Andhrapradesh") 
                            echo "Selected";?>>Andhrapradesh</option>
                                    <option value="Maharastra" 
                                    <?php if(set_value("state")=="Maharastra") 
                                        echo "Selected";?>>Maharastra</option>
                                    <option value="Telanagana" <?php if(set_value("state")=="Telanagana") echo "Selected";?>>Telanagana</option>
                                    <option value="Uttarpradesh" <?php if(set_value("state")=="Uttarpradesh") echo "Selected";?>>Uttarpradesh</option>
                                </select>
                                 <span class="text-danger"><?php echo form_error("state")?></span>
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                            <td>
                                <input type="checkbox" 
                                       name="terms" value="1" 
                            <?php if(set_value("terms")=="1") echo "checked";?>>
                                <?php echo $this->lang->line('terms') ;?>
                                 <span class="text-danger"><?php echo form_error("terms")?></span>
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                            <td><input type="submit" name="submit" 
                                       value="Register" class="btn btn-primary"></td>
                        </tr>
                    </table>
                    <?php echo form_close(); ?>
                </div><!--/.services-->
            </div><!--/.row--> 


            

            

            

        </div><!--/.container-->
    </section><!--/#feature-->