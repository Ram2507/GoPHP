
<section id="feature" class="transparent-bg">
        <div class="container">
           <div class="center wow fadeInDown">
                <h2>Upload Profile Pic</h2>
                <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut <br> et dolore magna aliqua. Ut enim ad minim veniam</p>
            </div>

            <div class="row">
                <div class="features">
        <?php
       if( $this->session->tempdata("error"))
       {
           echo "<div class='alert alert-danger'>". $this->session->tempdata("error")."</div>";
       }
        if( $this->session->tempdata("success"))
       {
           echo "<div class='alert alert-success'>". $this->session->tempdata("success")."</div>";
       }
       ?>
        
       <?php echo form_open_multipart(base_url()."user/upload");?>
        <table class="table">
            <tr>
                <td>Select Image</td>
                <td><input type="file" name="image" ></td>
            </tr>
            <tr>
            
            <tr>
                <td></td>
                <td>
                    <input name="upload" type="submit"                          
                           value="Upload">
                </td>
            </tr>
        </table>
       <?php echo form_close();?>
                </div><!--/.services-->
            </div><!--/.row--> 


            

            

            

        </div><!--/.container-->
    </section><!--/#feature-->


           