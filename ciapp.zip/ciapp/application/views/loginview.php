
<section id="feature" class="transparent-bg">
        <div class="container">
           <div class="center wow fadeInDown">
                <h2><?php echo $this->lang->line("login_title"); ?></h2>
                <p class="lead"><?php echo $this->lang->line("login_desc"); ?></p>
            </div>

            <div class="row">
                <div class="features">
                    <?php 
                                //echo validation_errors();
                            if($this->session->tempdata("error"))
                            {
                                echo "<p>".$this->session->tempdata("error")."</p>";
                            }
                            if($this->session->tempdata("password_success"))
                            {
                                echo "<p class='alert alert-success'>".$this->session->tempdata("password_success")."</p>";
                            }
                            ?>
                            <?php echo form_open();?>
                            <table class="table">
                                <tr>
                                    <td width="25%"><?php echo $this->lang->line("email");?>:</td>
                                    <td><input type="text" name="email" 
                                        value="<?php echo set_value("email");?>" class="form-control">
                        <span><?php echo strip_tags(form_error("email"));?></span>
                                    </td>
                                </tr>
                                 <tr>
                                    <td><?php echo $this->lang->line("password");?>:</td>
                                    <td><input type="password" name="pwd" class="form-control">
                        <span><?php echo strip_tags(form_error("pwd"));?></span>
                                    </td>
                                </tr>
                                 <tr>
                                    <td></td>
                                    <td><input type="submit" name="login" 
                                               value="Login" class="btn btn-success">
                                        <a href="<?php echo base_url()?>login/forgot">Forgot password?</a>
                                    </td>
                                </tr>
                            </table>
                            <?php echo form_close();?>
                        </div>

                </div><!--/.services-->
            </div><!--/.row--> 


            

            

            

        </div><!--/.container-->
    </section><!--/#feature-->


           