
<section id="feature" class="transparent-bg">
        <div class="container">
           <div class="center wow fadeInDown">
                <h2>Change Password</h2>
                <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut <br> et dolore magna aliqua. Ut enim ad minim veniam</p>
            </div>

            <div class="row">
                <div class="features">
                    <?php
       if( $this->session->tempdata("pwd_error"))
       {
           echo "<p class='alert alert-success'>". $this->session->tempdata("pwd_error")."</p>";
       }
       ?>
        
       <?php echo form_open();?>
        <table class="table">
            <tr>
                <td>Enter Old Password</td>
                <td><input type="password" name="opwd" class="form-control"></td>
            </tr>
            <tr>
                <td>Enter New Password</td>
                <td><input type="password" name="npwd"  class="form-control"></td>
            </tr>
            <tr>
                <td>Confirm New Password</td>
                <td><input type="password" name="cnpwd"  class="form-control"></td>
            </tr>
              
            <tr>
                <td></td>
                <td>
                    <input name="update" type="submit"                          
                           value="Update">
                </td>
            </tr>
        </table>
       <?php echo form_close();?>
                </div><!--/.services-->
            </div><!--/.row--> 


            

            

            

        </div><!--/.container-->
    </section><!--/#feature-->


           