
<section id="feature" class="transparent-bg">
        <div class="container">
           <div class="center wow fadeInDown">
                <h2>Reset Password</h2>
                <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut <br> et dolore magna aliqua. Ut enim ad minim veniam</p>
            </div>

            <div class="row">
                <div class="features">
                    
        
       <?php 
       
       if($this->session->tempdata("error"))
       {
           echo "<div class='alert alert-danger'>".$this->session->tempdata("error")."</div>";
       }
       
       
       if(validation_errors())
       {
            echo "<div class='alert alert-danger'>".validation_errors()."</div>";
       }
       echo form_open(base_url()."login/resetPassword/".$this->uri->segment(3));?>
        <table class="table">
            <tr>
                <td>Enter New Password</td>
                <td><input type="password" name="npwd" class="form-control"></td>
            </tr>
            <tr>
                <td>Confirm  New Password</td>
                <td><input type="password" name="cnpwd" class="form-control"></td>
            </tr>
            
            <tr>
                <td></td>
                <td>
                    <input name="submit" type="submit"                          
                           value="Update">
                </td>
            </tr>
        </table>
       <?php echo form_close();?>
                </div><!--/.services-->
            </div><!--/.row--> 


            

            

            

        </div><!--/.container-->
    </section><!--/#feature-->


           