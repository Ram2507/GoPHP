<?php
class Slider extends CI_Controller
{
    public function __construct() {
        parent::__construct();
        $this->load->helper(array("form","security"));
        $this->load->library(array("form_validation"));
        $this->load->database();
        $this->load->model("admin/SliderModel");
    }
    public function add()
    {
        $data=array();
        $this->load->view("admin/admin_header");
        $this->load->view("admin/admin_sidebar");
        
        $this->form_validation->set_rules("title","Title","required|trim|max_length[250]|alpha_numeric_spaces");
        $this->form_validation->set_rules("subtitle","Sub Title","required|trim|max_length[350]|alpha_numeric_spaces");
        $this->form_validation->set_rules("link","Button Link","required|valid_url");
        
        if($this->form_validation->run()==TRUE)
        {
           $title=$this->input->post("title"); 
           $subtitle=$this->input->post("subtitle"); 
           $link=$this->input->post("link"); 
           
            $config['upload_path'] = './assets/slider/';
            $config['allowed_types'] = 'gif|jpg|png';
            $config['max_size']     = '3000';
            /*$config['max_width'] = '1024';
            $config['max_height'] = '768';*/
            $this->load->library("upload",$config);
            $bimage="";
            //upload background Image
            if($this->upload->do_upload("bimage"))
            {
                $data=$this->upload->data();
                $bimage=$data['file_name'];
            }
            else
            {
                $data['berrors']=$this->upload->display_errors();
                $this->load->view("admin/add_slider_view",$data);
            }
            //upload Fornmt End Image
            if($this->upload->do_upload("fimage"))
            {
                $data=$this->upload->data();
                $fimage=$data['file_name'];
            }
            else
            {
                $data['ferrors']=$this->upload->display_errors();
                $this->load->view("admin/add_slider_view",$data);
            }
            
            //sending data to model
            $status=$this->SliderModel->addSlider($title,$subtitle,$link,$fimage,$bimage);
            if($status==true)
            {
                $this->session->set_tempdata("success","Slider Added Succssfully",2);
                redirect(base_url()."admin/slider/add");
            }
           
        }
        else
        {
            $this->load->view("admin/add_slider_view",$data);
        }
        
        $this->load->view("admin/admin_footer");
    }
    public function view()
    {
        $this->load->view("admin/admin_header");
        $this->load->view("admin/admin_sidebar");
        
        $data['sliders']=$this->SliderModel->getAllSliders("admin");
        $this->load->view("admin/view_all_sliders_view",$data);
        $this->load->view("admin/admin_footer");
    }
    public function edit($id)
    {
        $data=array();
        $data['id']=$id;
        $this->load->view("admin/admin_header");
        $this->load->view("admin/admin_sidebar");
        $data['slider']=$this->SliderModel->getSliderInfo($id);
       print_r($data['slider']->background_image);
       print_r($data['slider']->front_end_image);
        $this->form_validation->set_rules("title","Title","required|trim|max_length[250]|alpha_numeric_spaces");
        $this->form_validation->set_rules("subtitle","Sub Title","required|trim|max_length[350]|alpha_numeric_spaces");
        $this->form_validation->set_rules("link","Button Link","required|valid_url");
        
        if($this->form_validation->run()==TRUE)
        {
           $title=$this->input->post("title"); 
           $subtitle=$this->input->post("subtitle"); 
           $link=$this->input->post("link"); 
           
            $config['upload_path'] = './assets/slider/';
            $config['allowed_types'] = 'gif|jpg|png';
            $config['max_size']     = '3000';
            /*$config['max_width'] = '1024';
            $config['max_height'] = '768';*/
            $this->load->library("upload",$config);
            $bimage="";
            //upload background Image
            if($this->upload->do_upload("bimage"))
            {
                $data=$this->upload->data();
                $bimage=$data['file_name'];
            }
            else
            {
                $bimage=$data['slider']->background_image;
            }
            //upload Fornmt End Image
            if($this->upload->do_upload("fimage"))
            {
                $data=$this->upload->data();
                $fimage=$data['file_name'];
            }
            else
            {
                
               $fimage=$data['slider']->front_end_image;
            }
            
            //sending data to model
            $status=$this->SliderModel->UpdateSlider($id,$title,$subtitle,$link,$fimage,$bimage);
            if($status==true)
            {
                $this->session->set_tempdata("success","SliderUpdated Succssfully",2);
                redirect(base_url()."admin/slider/edit/".$id);
            }
           
        }
        else
        {
             $this->load->view("admin/edit_slider_view",$data);
        }
        
       
        $this->load->view("admin/admin_footer");
    }
    public function delete($id)
    {
        $this->db->delete("slider",array("id"=>$id));
        if($this->db->affected_rows()>0)
        {
            $this->session->set_tempdata("delete_success","Slider Deleted Successfully",2);
            redirect(base_url()."admin/slider/view");
        }
        else
        {
            $this->session->set_tempdata("delete_error","Sorry Unable to Delete",2);
            redirect(base_url()."admin/slider/view");
        }
    }
    public function hideShow($id)
    {
        $data=$this->SliderModel->getSliderInfo($id);
        if($data->status==0)
        {
            $this->db->where("id",$id);
            $this->db->update("slider",array("status"=>"1"));
            if($this->db->affected_rows()>0)
            {
                $this->session->set_tempdata("hs_success","Slider is Visible Now",2);
                redirect(base_url()."admin/slider/view");
            }
        }
        else if($data==1)
        {
            $this->db->where("id",$id);
            $this->db->update("slider",array("status"=>"0"));
            if($this->db->affected_rows()>0)
            {
                $this->session->set_tempdata("hs_success","Slider is Hidden Now",2);
                redirect(base_url()."admin/slider/view");
            }
        }
        else
        {
            $this->session->set_tempdata("hs_error","Sorry! Unable to Process...",2);
            redirect(base_url()."admin/slider/view");
        }
    }
}
