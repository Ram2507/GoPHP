<?php
class Users Extends CI_Controller
{
    public function __construct() {
        parent::__construct();
        if(!$this->session->has_userdata('admin_login'))
        {
            $this->session->set_tempdata("error","Please Login",2);
            redirect(base_url()."admin/login");
        }
        else
        {
            $this->user=$this->session->userdata('admin_login');
            $this->load->database();
            $this->load->model("admin/AdminUserModel");
            $this->load->library("pagination");
        }
    }
    public function index()
    {
        
        $this->load->view("admin/admin_header");
        $this->load->view("admin/admin_sidebar");
        
        //pagination
        $config['base_url'] = base_url()."admin/users/index";
        $config['total_rows'] = $this->db->count_all("register");
        $config['per_page'] = 3;
        //customizing the page links
        
        $config["full_tag_open"] = '<ul class="pagination
                pagination-sm no-margin pull-right">';
        $config["full_tag_close"] = '</ul>';
        
        $config["first_link"]="First";
        $config["first_tag_open"] = '<li>';
        $config["first_tag_close"] = '</li>';
        
        $config["next_link"]="Next";
        $config["next_tag_open"] = '<li>';
        $config["next_tag_close"] = '</li>';
        
        $config["prev_link"]="First";
        $config["prev_tag_open"] = '<li>';
        $config["prev_tag_close"] = '</li>';
        
        $config["cur_tag_open"] = '<li class="active"><a href=""><b>';
        $config["cur_tag_close"] = '</b></a></li>';
        
        $config["num_tag_open"] = '<li>';
        $config["num_tag_close"] = '</li>';
        
        $this->pagination->initialize($config);
        if($this->uri->segment(4))
        {
            $start=$this->uri->segment(4);
        }
        else
        {
            $start=0;
        }
        
        $data['users']=$this->AdminUserModel->getAllUsers($start,
                $config['per_page']);
        $this->load->view("admin/admin_usersview",$data);
        
        $this->load->view("admin/admin_footer");
    }
}

