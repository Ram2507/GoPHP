<?php
class Features extends CI_Controller
{
    public function __construct() {
        parent::__construct();
        $this->load->helper(array("form"));
        $this->load->library("form_validation");
        $this->load->database();
        $this->load->model("admin/FeaturesModel");
    }
    public function add()
    {
        $this->load->view("admin/admin_header");
        $this->load->view("admin/admin_sidebar");
        
        $this->form_validation->set_rules("title","Title","required|trim");
        $this->form_validation->set_rules("desc","Description","required|trim");
        $this->form_validation->set_rules("icon","ICON","required|trim");
        if($this->form_validation->run()==true)
        {
            $title=$this->input->post("title");
            $desc=$this->input->post("desc");
            $icon=$this->input->post("icon");
            $data=array(
                "title"=>$title,
                "description"=>$desc,
                "icon"=>$icon,
            );
           $status= $this->FeaturesModel->insertFeature($data);
           if($status)
           {
               $this->session->set_tempdata("success","Feature Added Successfully",2);
               redirect(base_url()."admin/features/add");
           }
            
        }
        else
        {
            $this->load->view("admin/add_features_view");
        }
        
        $this->load->view("admin/admin_footer");
    }
    public function view()
    {
        $this->load->view("admin/admin_header");
        $this->load->view("admin/admin_sidebar");
        $data['features']=$this->FeaturesModel->getAllFeatures();
        $this->load->view("admin/view_features_view",$data);
        $this->load->view("admin/admin_footer");
    }
    public function edit($id)
    {
        $this->load->view("admin/admin_header");
        $this->load->view("admin/admin_sidebar");
        $data['feature']=$this->FeaturesModel->getFeature($id);
        
        $this->form_validation->set_rules("title","Title","required|trim");
        $this->form_validation->set_rules("desc","Description","required|trim");
        $this->form_validation->set_rules("icon","ICON","required|trim");
        if($this->form_validation->run()==true)
        {
            $title=$this->input->post("title");
            $desc=$this->input->post("desc");
            $icon=$this->input->post("icon");
            $data=array(
                "title"=>$title,
                "description"=>$desc,
                "icon"=>$icon,
            );
           $status= $this->FeaturesModel->updateFeature($data,$id);
           if($status)
           {
               $this->session->set_tempdata("success","Feature Updated Successfully",2);
               redirect(base_url()."admin/features/edit/".$id);
           }
            
        }
        else
        {
           $this->load->view("admin/edit_features_view",$data);
        }
        
        
        $this->load->view("admin/admin_footer");
    }
    public function delete($id)
    {
        $this->db->delete("features",array("id"=>$id));
        if($this->db->affected_rows()>0)
        {
            $this->session->set_tempdata("success","Feature Deleted Successfully",2);
            redirect(base_url()."admin/features/view");
        }
        else
        {
            $this->session->set_tempdata("error","Sorry! Unable to Delete",2);
            redirect(base_url()."admin/features/view");
        }
    }
}
