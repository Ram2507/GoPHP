<?php
class Login extends CI_Controller
{
    public function __construct() {
        parent::__construct();
        $this->load->helper(array("form","security"));
        $this->load->library("form_validation");
        $this->load->model("admin/AdminLoginModel");
        $this->load->database();
    }
    public function index()
    {
       $this->form_validation->set_rules("email","Email","required|trim|valid_email");
       $this->form_validation->set_rules("password","Password","required|trim");
       if($this->form_validation->run()==TRUE)
       {
           $email=$this->input->post("email");
           $pwd=md5($this->input->post("password"));
           $data=array("email"=>$email,"password"=>$pwd);
           $adminData=$this->AdminLoginModel->login($data);
           if($adminData)
           {
               $this->session->set_userdata("admin_login",$adminData);
               redirect(base_url()."admin/home");
           }
           else
           {
               $this->session->set_tempdata("error","Sorry! Wrong Credentials",2);
               redirect(base_url()."admin/login");
           }
           
           
       }
       else
       {
            $this->load->view("admin/loginview");
       }
    }
    public function logout()
    {
        if($this->session->has_userdata("admin_login"))
        {
            $this->session->unset_userdata("admin_login");
            redirect(base_url()."admin/login");
        }
        else
        {
            $this->session->set_tempdata("error","Please Login",2);
            redirect(base_url()."admin/login");
        }
    }
}

