<?php 
class Home extends CI_Controller
{
    public $user;
    public $data=array();
    public function __construct() {
        parent::__construct();
        
        if(!$this->session->has_userdata('admin_login'))
        {
            $this->session->set_tempdata("error","Please Login",2);
            redirect(base_url()."admin/login");
        }
        else
        {
            $this->user=$this->session->userdata('admin_login');
            $this->load->database();
        }
    }
    public function index()
    {
        $data['total']=$this->db->count_all("register");
        $this->load->view("admin/admin_header");
        $this->load->view("admin/admin_sidebar");
        $this->load->view("admin/admin_homeview",$data);
        $this->load->view("admin/admin_footer");
    }
}
?>