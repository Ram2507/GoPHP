<?php 
class Register extends CI_Controller
{
    public function __construct() {
        parent::__construct();
         $this->load->helper("form");
         $this->load->library(array("form_validation","email"));
         $this->load->database();
         $this->load->model("RegisterModel");
         if($this->input->cookie("language"))
        {
            $lang= $this->input->cookie("language");
        }
        else
        {
            $lang="english";
        }
        $this->lang->load('labels', $lang);
    }
    public function index()
    {
        
        
        $this->load->view("header");
        
        $this->form_validation->set_rules("uname","Username",
                'required|trim',
                array("required"=>"Username is Required"));
        $this->form_validation->set_rules("email","Email",
                'required|trim|valid_email|is_unique[register.email]',array(
	"required"=>"Email is Required",
	"trim"=>"Empty spaces are not allowed",
	"valid_email"=>"Valid Email id is Required",
         "is_unique"=>"This Email already Exists.Please choose another"
                    ));
        
        $this->form_validation->set_rules("pwd","password",
                'required|trim|min_length[6]');
        $this->form_validation->set_rules("cpwd",
"Confirm Password",'required|trim|min_length[6]|matches[pwd]');
        
        $this->form_validation->set_rules("mobile","Mobile",
                'required|trim|exact_length[10]|numeric');
        $this->form_validation->set_rules("gender","Gender",
                'required');
        $this->form_validation->set_rules("city","City",
                'required|trim|alpha');
        $this->form_validation->set_rules("state","State",
                'required');
        $this->form_validation->set_rules("terms","Accept T&C",
                'required');
        $this->form_validation->set_rules("address","Address",
                'required|trim');
        if($this->form_validation->run()== FALSE)
        {
            //validation Fail | Display same form with error
            $this->load->view("registerview");
        }
        else
        {
            //validation success|get the Form Data|insert data
            $uname=$this->db->escape($this->input->post("uname"));
            $email=$this->db->escape($this->input->post("email"));
            $password=$this->db->escape(md5($this->input->post("pwd")));
            $mobile=$this->db->escape($this->input->post("mobile"));
            $gender=$this->db->escape($this->input->post("gender"));
            $addr=$this->db->escape($this->input->post("address"));
            $city=$this->db->escape($this->input->post("city"));
            $state=$this->db->escape($this->input->post("state"));
            $terms=$this->db->escape($this->input->post("terms"));
            $date=$this->db->escape(time());
            $ip=$this->db->escape($_SERVER['REMOTE_ADDR']);
            
            $status=$this->RegisterModel->insertData($uname,$email,
                    $password,$mobile,$gender,$addr,$city,$state,
                    $terms,$date,$ip);
            if($status)
            {
               $subject="Activation Link-CodeIgniter";
               $message="Hi ".$uname.",<br><br>Thanks! Your "
                       . "account has created"
                       . "successfully.your account details are:<br>"
                       . "username:Yourmail<br>"
                       . "Password:".$this->input->post("pwd")."<br><br>"
                       . "Please click the below link to activate "
                       . "your account<br>"
                       . "<a href='".base_url()."register/activate/".$status."'>"
                       . "Activate Now</a>"
                       . "<br><br>Thanks<br>CodeIgniter Team";
               
                $this->email->from('info@codeigniter.com', 'CodeIgniter');
                $this->email->to($email);
                $this->email->subject($subject);
                $this->email->message($message);
                $this->email->set_header('Content-type', 'text/html');
                if($this->email->send())
                {
                    $this->session->set_tempdata("success","1",5);
                    redirect(base_url()."register/");
                }
                else
                {
                    $this->session->set_tempdata("success","1",5);
                    redirect(base_url()."register/");
                }
               
            }
            else
            {
                echo "Sorry! Unable to Register";
            }//status end
            
        }//run end
        
        $this->load->view("footer");
    }
}
?>