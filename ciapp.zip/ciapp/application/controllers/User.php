<?php 
class User extends CI_Controller
{
     public function __construct() {
        parent::__construct();
       
        $this->load->helper(array("form"));
        $this->load->model("UserModel");
        $this->load->database();
        if(!$this->session->has_userdata("user_login"))
        {
            redirect(base_url()."login");
        }
    }
    public function index()
    {
        $data['user']=$this->UserModel->getLoggedInUserData();
        $this->load->view("header",$data);
        $this->load->view("userview");       
        $this->load->view("footer");
    }
    public function change_password()
    {
        $data['user']=$this->UserModel->getLoggedInUserData();
        $this->load->view("header",$data);
        if($this->input->post("update"))
        {
            $opwd=md5($this->input->post("opwd"));
            $npwd=md5($this->input->post("npwd"));
            $cnpwd=md5($this->input->post("cnpwd"));
            if($npwd==$cnpwd)
            {
                if($opwd==$data['user']->password)
                {
                    $status=$this->UserModel->updatePassword($npwd);
                    if($status)
                    {
                        $this->session->set_tempdata("pwd_error",
                                "Password Changed Successfully",2);
                        redirect(base_url()."user/change_password");
                    }
                    else
                    {
                        $this->session->set_tempdata("pwd_error",
                                "Sorry! Unable to Update, Try Again",2);
                        redirect(base_url()."user/change_password");
                    }
                }
                else
                {
                    $this->session->set_tempdata("pwd_error",
                            "Old password Does not Match",2);
                    redirect(base_url()."user/change_password");
                }
            }
            else
            {
                $this->session->set_tempdata("pwd_error",
                        "New and Old Passwords Does not Match",2);
                redirect(base_url()."user/change_password");
            }
        }
        else
        {
            $this->load->view("changepwdview");
        }
        $this->load->view("footer");
    }
    public function edit()
    {
        $data['user']=$this->UserModel->getLoggedInUserData();
        $this->load->view("header",$data);
        if($this->input->post("update"))
        {
            $uname=$this->db->escape($this->input->post("uname"));
            $mobile=$this->db->escape($this->input->post("mobile"));
            $addr=$this->db->escape($this->input->post("address"));
            $city=$this->db->escape($this->input->post("city"));
            $state=$this->db->escape($this->input->post("state"));
           $status=$this->UserModel->updateUser($uname,$mobile,
                   $addr,$city,$state);
           if($status==1)
           {
              $this->session->set_tempdata("message",
                      "Updated Successfully",2); 
              redirect(base_url()."user/edit");
           }
           else
           {
               $this->session->set_tempdata("message",
                       "Sorry! Unable to update Tray Agaian!",2); 
               redirect(base_url()."user/edit");
           }
        }
        else
        {
            $this->load->view("editview");
        }
        $this->load->view("footer");
    }
    public function logout()
    {
        //session_destroy();
       // $this->session->unset_userdata("user_login");
        $this->session->sess_destroy();
        redirect(base_url()."login");
    }
    public function upload()
    {
        
        $data['user']=$this->UserModel->getLoggedInUserData();
        $this->load->view("header",$data);
        if($this->input->post("upload"))
        {
            $config['upload_path'] = './assets/profiles/';
            $config['allowed_types'] = 'gif|jpg|png';
            $config['max_size']     = '3000';
            $config['max_width'] = '1024';
            $config['max_height'] = '768';
            $this->load->library("upload",$config);
            if($this->upload->do_upload("image"))
            {
                $filename=$this->upload->data()['file_name'];
                //update the file name to DB
                $status=$this->UserModel->uploadProfile($filename);
                if($status==1)
                {
                    $this->session->set_tempdata("success","File Uploaded Successfully",2); 
                    redirect(base_url()."user/upload");
                }
                else
                {
                    $this->session->set_tempdata("error","Sorry! Unable to Upload",2); 
                    redirect(base_url()."user/upload");
                }
            }
            else
            {
               $data=$this->upload->display_errors(); 
               $this->session->set_tempdata("error",$data,2); 
               redirect(base_url()."user/upload");
            }
            
        }else{
            $this->load->view("uploadview");
        }
        
       
        $this->load->view("footer");
    }
}
?>