<?php

class Home extends CI_Controller
{
    public $data=array();
    public function __construct() {
        parent::__construct();
        $this->load->model(array("UserModel","admin/SliderModel","admin/FeaturesModel"));
        
        $this->load->database();
        if($this->session->has_userdata("user_login"))
        {
            $this->data['user']=$this->UserModel->getLoggedInUserData();
        }
        else
        {
            $this->data['user']="";
        }
       
    }
    public function index()
    {
        
        $this->load->view("header",$this->data);
        $this->data['sliders']=$this->SliderModel->getAllSliders("user");
        $this->data['features']=$this->FeaturesModel->getAllFeatures();
        $this->load->view("homeview",$this->data);
        $this->load->view("footer");
    }
    public function about()
    {
        $this->load->view("header",$this->data);
        $this->load->view("aboutview");
        $this->load->view("footer");
    }
    public function services()
    {
        $this->load->view("header",$this->data);
        $this->load->view("servicesview");
        $this->load->view("footer");
    }
    public function portfolio()
    {
        $this->load->view("header",$this->data);
        $this->load->view("portfolioview");
        $this->load->view("footer");
    }
    public function blog()
    {
        $this->load->view("header",$this->data);
        $this->load->view("blogview");
        $this->load->view("footer");
    }
    public function contact()
    {
        $this->load->view("header",$this->data);
        $this->load->view("contactview");
        $this->load->view("footer");
    }
}
