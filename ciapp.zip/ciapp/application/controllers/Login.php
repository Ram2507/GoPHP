<?php
class Login Extends CI_Controller
{
    public function __construct() {
        parent::__construct();
        $this->load->helper(array("form"));
        $this->load->library(array("form_validation","email"));
        $this->load->database();
        $this->load->model("LoginModel");
        
        if($this->input->cookie("language"))
        {
            $lang= $this->input->cookie("language");
        }
        else
        {
            $lang="english";
        }
        $this->lang->load('labels', $lang);
    }
    public function index()
    {
        $this->form_validation->set_rules("email","Email",
                "required|valid_email|trim");
        $this->form_validation->set_rules("pwd","Password",
                "required|trim");
        $this->load->view("header");
        if($this->form_validation->run()==FALSE)
        {
            
            $this->load->view("loginview");
        }
        else
        {
            $email=$this->db->escape($this->input->post("email"));
            $pwd=$this->db->escape(md5($this->input->post("pwd")));
            //we have to send the data to model
            $data=$this->LoginModel->checkCredentials($email,$pwd);
            if($data)
            {
                if($data->status==0)
                {
                    $this->session->set_tempdata("error",
                            "Please activate your account",2);
                    redirect(base_url()."login");
                }
                else
                {
                    $id=$data->id;
                    $this->session->set_userdata("user_login",$id);
                    redirect(base_url()."user");
                }
            }
            else
            {
                $this->session->set_tempdata("error",
                        "Sorry! Wrong Credentials",2);
                redirect(base_url()."login");
            }
        }
        $this->load->view("footer");
    }
    
    public function forgot()
    {
        
        $this->load->view("header");
        $this->form_validation->set_rules("email","Email","required|trim|valid_email");
        if($this->form_validation->run()==TRUE)
        {
            $email=$this->db->escape($this->input->post("email"));
            $response=$this->LoginModel->checkEmail($email);
            if($response)
            {
                $eid= base64_encode($response->email);
               $subject=$response->username."-Reset Password-GoPHP";
               $message="Hi ".$response->username.",<br><br>Your Reset password "
                       . "request has been received. Please click the below link"
                       . "to reset password<br><br><a target='_blank' href='".base_url()."login/resetPassword/".$eid."'>Forgot Password</a>"
                       . "<br><br>Thanks<br>GoPHP";
                $this->email->from('info@codeigniter.com', 'CodeIgniter');
                $this->email->to($response->email);
                $this->email->subject($subject);
                $this->email->message($message);
                $this->email->set_header('Content-type', 'text/html');
                if($this->email->send())
                {
                    $this->session->set_tempdata("email_success","Reset Password Link has sent to your Email. please check now",2);
                    redirect(base_url()."login/forgot");
                }
                else
                {
                    $this->session->set_tempdata("email_error","Sorry! Mail is not configured",2);
                    redirect(base_url()."login/forgot");
                }
            }
            else
            {
                $this->session->set_tempdata("error","Sorry! Email does not exists",2);
                redirect(base_url()."login/forgot");
            }
        }
        else
        {
            $this->load->view("forgotview");
        }
        $this->load->view("footer");
    }
    
    public function resetPassword($uid)
    {
        $this->load->view("header");
        $this->form_validation->set_rules("npwd","New Password","required|trim|min_length[6]");
        $this->form_validation->set_rules("cnpwd","Confirm Password","required|trim|matches[npwd]");
        if($this->form_validation->run()==true)
        {
            $pwd=$this->db->escape(md5($this->input->post("npwd")));
            $status=$this->LoginModel->updatePassword($pwd, base64_decode($uid));
            if($status==true)
            {
               $this->session->set_tempdata("password_success","Password Changed Successfully",2);
               redirect(base_url()."login"); 
            }
            else
            {
                $this->session->set_tempdata("error","Sorry! Unable To Update",2);
                redirect(base_url()."login/resetPassword/".$uid);
            }
        }
        else
        {
            $this->load->view("resetpasswordview");
        }
        
        $this->load->view("footer");
    }
}
