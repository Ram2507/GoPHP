<?php 
$lang['email'] = 'Email';
$lang['username'] = 'Username';
$lang['password'] = 'Password';
$lang['cpassword'] = 'Confirm Password';
$lang['mobile'] = 'Mobile';
$lang['gender'] = 'Gender';
$lang['address'] = 'Address';
$lang['city'] = 'City';
$lang['state'] = 'State';
$lang['terms'] = 'Please accept T&C';

$lang['reg_title']="Register";
$lang['reg_desc']="Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut 
et dolore magna aliqua. Ut enim ad minim veniam";

$lang['login_title']="Register";
$lang['login_desc']="Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut 
et dolore magna aliqua. Ut enim ad minim veniam";

/*Define lables for errors*/