-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 24, 2017 at 05:46 AM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 7.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `codeigniter`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `email`, `password`) VALUES
(1, 'Admin', 'admin@mail.com', 'e6e061838856bf47e1de730719fb2609'),
(2, 'ram', 'ram@mail.com', '3db66ceb605c1bcb779c63e180c4f2d0');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `city` varchar(50) NOT NULL,
  `messgae` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `mobile`, `email`, `city`, `messgae`) VALUES
(1, 'Ram', 3563534534, 'dgdfgdfg', 'dfgdfg', 'dgdfg');

-- --------------------------------------------------------

--
-- Table structure for table `features`
--

CREATE TABLE `features` (
  `id` int(11) NOT NULL,
  `title` varchar(250) NOT NULL,
  `description` text NOT NULL,
  `icon` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `features`
--

INSERT INTO `features` (`id`, `title`, `description`, `icon`) VALUES
(1, 'SEO Training', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit', 'fa fa-cloud-download'),
(2, 'PHP Training', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit', 'fa fa-bullhorn'),
(3, 'MySQL Training', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit', 'fa fa-comments'),
(5, 'DOTNET Training', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit', 'fa fa-pencil'),
(6, 'Wordpress Training', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit', 'fa fa-cogs'),
(7, 'COdeigniter training', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit', 'fa fa-leaf');

-- --------------------------------------------------------

--
-- Table structure for table `reg`
--

CREATE TABLE `reg` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reg`
--

INSERT INTO `reg` (`id`, `username`, `email`, `password`) VALUES
(1, 'Ram', 'ram@gmail.com', '123'),
(2, 'koti', 'koti123@gmail.com', '123'),
(3, 'naresh', 'naresh@institute.com', '123'),
(4, 'koti', 'sri@gmail.com', '123'),
(5, 'Ram', 'mani@gmail.com', '123'),
(8, '', '', ''),
(10, 'Ram', 'manwewer', 'werwerwe');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(32) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `address` text NOT NULL,
  `state` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `terms` int(11) NOT NULL,
  `date_of_reg` varchar(100) NOT NULL,
  `ip` varchar(30) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `profile_pic` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `username`, `email`, `password`, `mobile`, `gender`, `address`, `state`, `city`, `terms`, `date_of_reg`, `ip`, `status`, `profile_pic`) VALUES
(1, 'Ram', 'ram@gmail.com', 'fcea920f7412b5da7be0cf42b8c93759', '9885776740', 'Male', 'Maithrivanam', 'Andhrapradesh', 'Hyderabad', 1, '1503977520', '::1', 1, 'Lighthouse.jpg'),
(2, 'koti', 'koti@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '8446876117', 'Male', 'Maithrivanam', 'Andhrapradesh', 'Hyderabad', 1, '1503977520', '::1', 1, 'Lighthouse1.jpg'),
(3, 'naresh', 'naresh@mail.com', 'e10adc3949ba59abbe56e057f20f883e', '8446876117', 'Male', 'Maithrivanam', 'Andhrapradesh', 'Hyderabad', 1, '1503977640', '::1', 0, ''),
(4, 'Ram', 'ram1234@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '8446876117', 'Male', 'Maithrivanam', 'Maharastra', 'Hyderabad', 1, '1504838851', '::1', 0, ''),
(5, 'Ram', 'ramtrewtr@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '8446876117', 'Male', 'Maithrivanam', 'Andhrapradesh', 'Hyderabad', 1, '1504838920', '::1', 0, ''),
(6, 'Ram', 'mani123@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '8446876117', 'Male', 'Maithrivanam', 'Maharastra', 'Hyderabad', 1, '1504839086', '::1', 0, ''),
(7, 'bhaskar', 'bhaskar@mail.com', '9ce82af944211f9b8af4ccd8490e83bd', '7894561237', 'Male', 'Maithrivanam', 'Andhrapradesh', 'Hyderabad', 1, '', '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE `slider` (
  `id` int(11) NOT NULL,
  `title` varchar(250) NOT NULL,
  `sub_title` varchar(350) NOT NULL,
  `background_image` varchar(250) NOT NULL,
  `front_end_image` varchar(250) NOT NULL,
  `button_link` varchar(250) NOT NULL,
  `status` int(10) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`id`, `title`, `sub_title`, `background_image`, `front_end_image`, `button_link`, `status`, `date`) VALUES
(2, '''The PHP Source Editor is a full featured text editor that is integrated''', '''The top of the Source Editor has a tab for each open document Each tab shows the name of the document''', 'bg1.jpg', 'img12.png', '''http://example.com''', 1, '2017-09-18 05:26:32'),
(3, '''Technology''', '''The top of the Source Editor has a tab for each open document''', 'bg2.jpg', 'img2.png', '''http://example.com''', 1, '2017-09-18 08:59:41'),
(4, '''Sports''', '''The top of the Source Editor has a tab for each open document''', 'bg3.jpg', 'img3.png', '''http://example.com''', 1, '2017-09-18 09:01:15'),
(6, 'MERCHANTABILITY', 'The top of the Source Editor has a tab for each open document', 'gallery4.png', 'boy2.png', 'http://example.com', 1, '2017-09-19 08:38:29'),
(7, 'PHP Training', 'The top of the Source Editor has a tab for each open document', 'blog11.jpg', 'girl.png', 'http://example.com', 1, '2017-09-20 08:50:14');

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE `states` (
  `id` int(11) NOT NULL,
  `state` varchar(50) NOT NULL,
  `district` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`id`, `state`, `district`) VALUES
(1, 'Andhrapradesh', 'Prakasam'),
(2, 'Andhrapradesh', 'Nellore'),
(3, 'Andhrapradesh', 'Krishna'),
(4, 'Andhrapradesh', 'Guntur'),
(5, 'Andhrapradesh', 'WestGodavari'),
(6, 'Andhrapradesh', 'EastGodavari'),
(7, 'Telangana', 'Hyderabad'),
(8, 'Telangana', 'Warangal'),
(9, 'Telangana', 'KHammam'),
(10, 'Telangana', 'Nalgonda'),
(11, 'Telangana', 'Adilabad'),
(12, 'Telangana', 'Nizamabad'),
(13, 'Maharastra', 'Pune'),
(14, 'Maharastra', 'Nagapur'),
(15, 'Maharastra', 'Nanded'),
(16, 'Maharastra', 'Mumbai'),
(17, 'Madhyapradesh', 'Sajapur'),
(18, 'Madhyapradesh', 'Devarsh'),
(19, 'Madhyapradesh', 'Bhopal'),
(20, 'Madhyapradesh', 'indore'),
(21, 'Odidha', 'Bhuvaneswar'),
(22, 'Odidha', 'Bharampur'),
(23, 'Odidha', 'Ganjam'),
(24, 'Odidha', 'Cuttack'),
(25, 'Chattisgarh', 'Raipur'),
(26, 'Chattisgarh', 'Bilaspur');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `features`
--
ALTER TABLE `features`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reg`
--
ALTER TABLE `reg`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `features`
--
ALTER TABLE `features`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `reg`
--
ALTER TABLE `reg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `slider`
--
ALTER TABLE `slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `states`
--
ALTER TABLE `states`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
