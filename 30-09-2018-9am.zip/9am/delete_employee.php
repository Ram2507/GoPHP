<?php 
if(isset($_REQUEST['empid']))
{
	$id=$_REQUEST['empid'];
	include("connect.php");
	mysqli_query($con,"delete from employee where eid='$id'");
	if(mysqli_affected_rows($con)==1)
	{
		setcookie("success","$id deleted successfully",time()+2);
		header("Location:view_employees.php");
	}
	else
	{
		echo "<p>Sorry! Unable to delete a record</p>";
	}
}
else
{
	exit("Worng Window");
}

?>