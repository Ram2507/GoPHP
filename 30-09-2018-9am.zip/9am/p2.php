<html>
	<head>
		<title>Session And Cookie</title>
	</head>
	<body>
		<h1>Person 2</h1>
		<form method="POST" action="p3.php">
			No2:<input type="text" name="num2">
			<input type="submit" value="Go">
		</form>
	</body>
</html>
<?php 
session_start();
	$_SESSION["number1"]=$_POST['num1'];
?>