<?php 
if(isset($_REQUEST['empid']))
{
	include("connect.php");
	$id=$_REQUEST['empid'];
	
	$res=mysqli_query($con,"select *from employee where eid='$id'");
	if(mysqli_num_rows($res)>0)
	{
		$row=mysqli_fetch_assoc($res);
		//print_r($row);
	}
	else
	{
		exit("Sorry! Wrong Window");
	}
	
	?>
	<h1>Edit Employee</h1>
	<p><a href="add_employee.php">Add Employee</a>
	<a href="view_employees.php">View Employees</a></p>
	
	<?php 
	
	if(isset($_COOKIE['success']))
	{
		echo "<p>".$_COOKIE['success']."</p>";
	}
	
	if(isset($_POST['submit']))
	{
		$name=$_POST['name'];
		$email=$_POST['email'];
		$sal=$_POST['salary'];
		$doj=$_POST['doj'];
		$address=$_POST['address'];
		$desg=$_POST['desg'];
		mysqli_query($con,"update employee set name='$name',
		email='$email',salary='$sal',designation='$desg',
		address='$address',doj='$doj' where eid='$id'");
		if(mysqli_affected_rows($con)==1)
		{
			setcookie("success","$id update successfully",time()+2);
			header("Location:edit_employee.php?empid=$id");
		}
		else
		{
			echo "<p>Sorry! Unable to Update.Try Again</p>";
		}
	}
	?>
	
		<form method="POST" action="" onsubmit="return empValidation()">
			<table>
			<tr>
				<td>Name</td>
				<td><input value="<?php echo $row['name']?>" type="text" name="name" id="name"></td>
			</tr>
			<tr>
				<td>Email</td>
				<td><input value="<?php echo $row['email']?>"  type="text" name="email" id="email"></td>
			</tr>
			<tr>
				<td>Salary</td>
				<td><input value="<?php echo $row['salary']?>"  type="text" name="salary" id="salary"></td>
			</tr>
			<tr>
				<td>Designation</td>
				<td><input value="<?php echo $row['designation']?>"  type="text" name="desg" id="desg"></td>
			</tr>
			<tr>
				<td>Address</td>
				<td><textarea name="address" id="address"><?php echo $row['address']?></textarea></td>
			</tr>
			<tr>
				<td>Date of Join</td>
				<td><input value="<?php echo $row['doj']?>" type="text" name="doj" placeholder="yyyy-mm-dd" id="doj"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" name="submit" Value="Update Employee"></td>
			</tr>
		</table>
		</form>
		<script>
		function empValidation()
		{
			if(document.getElementById("email").value=="")
			{
				alert("Enter Email");
				return false;
			}
			else
			{
				var email=document.getElementById("email").value;
					var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
					if(!re.test(email))
					{
						alert("please enter valid email");
						return false;
					}
			}
		}
		
		</script>
	<?php
}
else
{
	exit("Wrong Woidow");
}

?>