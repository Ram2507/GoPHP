<?php 
header("content-disposition:attachment;filename=9am.zip");
readfile("9am.zip");
?>