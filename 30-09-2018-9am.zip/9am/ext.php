<pre><?php 
$f="welcome.jpg";
$arr=explode(".",$f);

print_r(end($arr));
?>