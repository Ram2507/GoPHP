<script>
	window.location="array.php";
</script>

<?php 
//header("Location:array.php");
//or
//header("Location:http://php.net");
?>