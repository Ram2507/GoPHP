<?php 
$arr=array(
	"city"=>"Hyderabad",
	"name"=>"Ram",
	"mobile"=>"988577",
);
echo json_encode($arr);

?>
