
<html>
	<head>
		<title>Users</title>
		<style>
			table{
				border-collapse:collapse;
			}
			table tr td{
				border:1px solid;
				padding:5px;
			}
		</style>
	</head>
	<body>
		<h1>All Users</h1>
		<?php 
		$con=mysqli_connect("localhost","root","","9am");
		$result=mysqli_query($con,
		"select *from contact");
		if(mysqli_num_rows($result)>0)
		{
			?>
			<table>
			<tr>
				<td>Id</td>
				<td>Name</td>
				<td>Email</td>
				<td>Mobile</td>
				<td>City</td>
				<td>Message</td>
			</tr>
			<?php 
			for(;$row=mysqli_fetch_row($result);)
			{
				?>
					<tr>
					<td><?php echo $row['0'];?></td>
					<td><?php echo $row['1'];?></td>
					<td><?php echo $row['2'];?></td>
					<td><?php echo $row['4'];?></td>
					<td><?php echo $row['5'];?></td>
					<td><?php echo $row['3'];?></td>
					
				</tr>
				<?php
			}
			
			?>
			
		</table>
			<?php
		}
		else
		{
			echo "<p>Sorry! NO records found</p>";
		}
		?>
		
	</body>
</html>