<?php include("connect.php");?>
<html>
	<head>
		<title>GoPHP-Add Employee</title>
	</head>
	<body>
		<h1>Add Employee</h1>
		<p><a href="view_employees.php">View Employee</a></p>
		
		<?php 
		if(isset($_COOKIE['success']))
		{
			echo "<p>".$_COOKIE['success']."</p>";
		}
		
		
		if(isset($_POST['submit']))
		{
			$name=$_POST['name'];
			$email=$_POST['email'];
			$sal=$_POST['salary'];
			$doj=$_POST['doj'];
			$address=$_POST['address'];
			$desg=$_POST['desg'];
		//insert data into employee
		$res=mysqli_query($con,"select max(eid) from employee");
		//echo mysqli_num_rows($res);
		$row=mysqli_fetch_row($res);
		if($row[0]=="")
		{
			$id="CnP-1";
		}
		else
		{
			$id=substr($row[0],4)+1;
			$id="CnP-".$id;
		}
		//echo $id;
		mysqli_query($con,"insert into employee(eid,name,email,salary,designation,address,doj) values('$id','$name','$email','$sal','$desg','$address','$doj')");
		if(mysqli_affected_rows($con)==1)
		{
			setcookie("success","Account Created Successfully",time()+2);
			header("Location:add_employee.php");
		}
		else
		{
			echo "<p>Sorry! Unable to INsert Tray Again</p>";
		}
		
		
		}
		?>
		
		<form method="POST" action="" onsubmit="return empValidation()">
			<table>
			<tr>
				<td>Name</td>
				<td><input type="text" name="name" id="name"></td>
			</tr>
			<tr>
				<td>Email</td>
				<td><input type="text" name="email" id="email"></td>
			</tr>
			<tr>
				<td>Salary</td>
				<td><input type="text" name="salary" id="salary"></td>
			</tr>
			<tr>
				<td>Designation</td>
				<td><input type="text" name="desg" id="desg"></td>
			</tr>
			<tr>
				<td>Address</td>
				<td><textarea name="address" id="address"></textarea></td>
			</tr>
			<tr>
				<td>Date of Jopn</td>
				<td><input type="text" name="doj" placeholder="yyyy-mm-dd" id="doj"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" name="submit" Value="Add Employee"></td>
			</tr>
		</table>
		</form>
		<script>
		function empValidation()
		{
			if(document.getElementById("email").value=="")
			{
				alert("Enter Email");
				return false;
			}
			else
			{
				var email=document.getElementById("email").value;
					var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
					if(!re.test(email))
					{
						alert("please enter valid email");
						return false;
					}
			}
		}
		
		</script>
		
	</body>
</html>