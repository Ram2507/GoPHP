<?php 
//echo time();
//from 1970 jan 1st midnight
//echo date("l,M-dS-Y h:i:s",1510000123);

//echo ;
echo date("l",strtotime("1996-07-21"));

//echo date("w");
//echo date("W");
//echo date("L");
//echo date("t");





//echo date("Y-m-d");//2018-08-23
//echo date("l,d-M-Y");//Thursday,23-Aug-2018
//echo date("F dS Y");
//echo date("m-d-Y");
//echo date("Y-m-d h:i:s a");
//date_default_timezone_set("Europe/London");
//date_default_timezone_set("Pacific/Auckland");
//date_default_timezone_set("Australia/Sydney");
//date_default_timezone_set("Asia/Singapore");
//echo date("l, dS M Y h:i:sa");
//echo date_default_timezone_get()

?>
<!--
August 24th 2018
Thursday, 23rd Aug 2018 10:25:00am
-->





