<?php 
if(isset($_REQUEST['id']))
{
	$id=$_REQUEST['id'];
	echo $id;
}

?>
