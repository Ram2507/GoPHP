<?php 
/*
echo $_GET['id'];
echo $_GET['name'];
echo $_GET['city'];
*/
if(isset($_GET['id']))
{
	echo $_GET['id'];
}
?>