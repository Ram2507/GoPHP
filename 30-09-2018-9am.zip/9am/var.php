<?php

echo 11/2;

/*$firstName="Ram";
echo $firstName;*/
//define("name","value");
/*
const city="Hyderabad";
const state="Telangana";

echo city;
echo "<br>";
echo state;
*/
/*define("city","Hyderabad");
define("state","Telangana");
echo city;
echo "<br>";
echo state;
*/

?>