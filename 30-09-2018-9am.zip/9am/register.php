<?php 
//5.Connecting to DB
include("connect.php");//$con
?>
<html>
	<head>
		<title>Register</title>
		<style>
			body{
				background:#efefef;
			}
		</style>
	</head>
	<body>
		<h1>Register Here</h1>
		<?php 
			if(isset($_POST['register']))
			{
				
				//4.collecting the data from Form
				$name=$_POST['uname'];
				$email=$_POST['email'];
				$pass=md5($_POST['pwd']);
				$state=$_POST['state'];
				$city=$_POST['city'];
				$gender=$_POST['gender'];
				$tnc=$_POST['tnc'];
				$ip=$_SERVER['REMOTE_ADDR'];
				//6.Insert data into register table
				mysqli_query($con,"insert into register
				(username,
				email,password,city,state,gender,terms,ip)
				values('$name','$email','$pass','$city',
				'$state','$gender','$tnc','$ip')");
				if(mysqli_affected_rows($con)==1)
				{
					//7. send email
					$to=$email;
					$uid=mysqli_insert_id($con);
					$subject="Account Activation-GoPHP";
					$message="Hi $name,<br><br>Thanks.your 
					account hasbeen 
					created successfully.Please click 
					the below link
					to activate your account.<br><br>
					<a target='_blank' 
					href='http://localhost/9am/activate.php
					?userid=$uid'>Activate Now</a>";
					//echo $message;
					$mheaders="Content-Type:text/html";
					if(mail($to,$subject,$message,$mheaders))
					{
						echo "<p>Account Created successfully. 
						Please activate your account</p>";
					}
					else
					{
						echo "Sorry! Unbale to Send an Mail";
					}
				}
				else
				{
					echo "Sorry! Unable to insert.Try Again";
				}
			}
		?>
		
		<form method="POST" action="" 
		onsubmit="return regValidate()">
			<table>
				<tr>
					<td>Username</td>
					<td>
						<input type="text" name="uname" 
						id="uname" 
						onblur="checkValue(this)">
						<span id="uname_error"></span>
					</td>
				</tr>
				<tr>
					<td>Email</td>
					<td>
						<input type="text" name="email" 
						id="email" 
						onblur="checkValue(this)">
						<span id="email_error"></span>
					</td>
				</tr>
				<tr>
					<td>Password</td>
					<td>
						<input type="password" name="pwd" 
						id="pwd" onblur="checkValue(this)">
						<span id="pwd_error"></span>
					</td>
				</tr>
				<tr>
					<td>Confirm Password</td>
					<td>
						<input type="password" name="cpwd" 
						id="cpwd" onblur="checkValue(this)">
						<span id="cpwd_error"></span>
					</td>
				</tr>
				<tr>
					<td>Gender</td>
					<td>
						<input type="radio" name="gender" 
						id="gender" value="male">Male
						<input type="radio" name="gender" 
						id="gender1" value="female">Female
					</td>
				</tr>
				<tr>
					<td>City</td>
					<td><input type="text" name="city" 
					id="city"></td>
				</tr>
				<tr>
					<td>State</td>
					<td>
						<select name="state" id="state">
							<option>--Select State--</option>
							<option value="Andhrapradesh">Andhrapradesh</option>
							<option value="Telangana">Telangana</option>
							<option value="Maharastra">Maharastra</option>
							<option value="Uttarapradesh">Uttarapradesh</option>
							<option value="Bihar">Bihar</option>
							<option value="Goa">Goa</option>
							<option value="Chattisgarh">Chattisgarh</option>
							<option value="Jharkhand">Jharkhand</option>
						</select>
					</td>
				</tr>
				<tr>
					<td></td>
					<td><input type="checkbox" name="tnc" 
					id='tnc' value="yes">Please accept terms 
					and conditions</td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" name="register" 
					value="Register"></td>
				</tr>
			</table>
		</form>
		<script>
			function regValidate()
			{
				if(document.getElementById("uname").value=="")
				{
					document.getElementById("uname_error")
					.innerHTML="Enter Username";
					document.getElementById("uname_error")
					.style.color="#f00";
					document.getElementById("uname").focus();
					return false;
				}
				//email checking
				if(document.getElementById("email").value=="")
				{
					document.getElementById("email_error").innerHTML="Enter Email";
					document.getElementById("email_error").style.color="#f00";
					document.getElementById("email").focus();
					return false;
				}
				else
				{
					var email=document.getElementById("email").value;
					var filter=/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;;
					if(!filter.test(email))
					{
						document.getElementById("email_error").innerHTML="Enter Valid Email";
						document.getElementById("email_error").style.color="#f00";
						document.getElementById("email").focus();
						return false;
					}
				}
				//password validation
				if(document.getElementById("pwd").value=="")
				{
					document.getElementById("pwd_error").innerHTML="Enter Password";
					document.getElementById("pwd_error").style.color="#f00";
					document.getElementById("pwd").focus();
					return false;
				}
				if(document.getElementById("cpwd").value=="")
				{
					document.getElementById("cpwd_error").innerHTML="Enter Confirm Password";
					document.getElementById("cpwd_error").style.color="#f00";
					document.getElementById("cpwd").focus();
					return false;
				}
				
				if(document.getElementById("pwd").value != 
				document.getElementById("cpwd").value)
				{
					document.getElementById("pwd_error").innerHTML="Passwords Does not matched";
					document.getElementById("pwd_error").style.color="#f00";
					document.getElementById("pwd").focus();
					return false;
				}
				
			}
			
			function checkValue(e)
			{
				if(e.value!="")
				{
					document.getElementById(e.id+"_error")
					.innerHTML="";
				}
			}
		</script>
	</body>
</html>