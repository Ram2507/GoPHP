<pre><?php 
//$arr=array(10,20,30,40);
//echo implode("#",$arr)//10#20#30#40

$pwd="ram@123";
echo base64_encode($pwd);

$pwd="cmFtQDEyMw==";
echo base64_decode($pwd);



/*$str="This program is free software;
 you can redistribute it and/or modify
 it under the terms of the GNU General 
 Public License as published by the 
 Free Software Foundation; 
 either version 2 of the License,
 or (at your option) any later version.";
echo substr($str,0,100)."....";
//from 0 to 100 characters


echo substr($str,20);
//from 20th position to remaining chars
*/
/*$email="rambabburi@gmail.com";
$l=strlen($email);
for($i=0;$i<$l;$i++)
{
	if($email{$i}=="a")
	{
		echo $i."<br>";
	}
}
*/
/*$str="Ram\'s";
echo stripslashes($str);*/
//$name="           Ram        ";
//echo rtrim($name);
//echo trim($name);

//echo trim($name);
?>