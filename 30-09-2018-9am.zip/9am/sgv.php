<?php 
//echo $_SERVER['PHP_SELF'];
//  /9am/sgv.php

//echo $_SERVER['SCRIPT_FILENAME'];
//echo $_SERVER['HTTP_USER_AGENT'];

//echo $_SERVER['REMOTE_ADDR'];//::1
//echo $_SERVER['SERVER_NAME'];
//echo $_SERVER['SERVER_PORT'];
echo $_SERVER['DOCUMENT_ROOT'];


?>