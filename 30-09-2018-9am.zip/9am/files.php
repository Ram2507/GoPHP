<style>
img{
	margin:5px;
	border:2px solid green;
	border-radius:10px;
	padding:2px;
}
</style>
<?php 
$fp=opendir("images");
while($f=readdir($fp))
{
	if(!($f=="." || $f==".."))
	{
		$arr=explode(".",$f);
		$ext=end($arr);
		if($ext=="jpg" || $ext=="png" || $ext=="gif")
		{
			echo "<img src='images/$f' height='100' 
			width='100'>";
	
		}
	}
	
}



//echo mkdir("images",0777);
/*$f="C:/Users/php/Desktop/dsfd";
if(file_exists($f))
{
	rmdir($f);
	echo "$f is Deleted....";
}
else
{
	echo "$f is not avaliable";
}*/
//echo rmdir("css");

/*
$file="hi.txt";
if(file_exists($file))
{
	unlink($file);
	echo "$file deleted...";
}
else
{
	echo "$file is not avaliable";
}
*/
//echo file_exists("hi.txt");//1
//echo is_file("hi.txt");//1



//$fp=fopen("http://fb.com","r");
//echo fread($fp,200000000000);
/*echo "<pre>";
$data=file_get_contents("http://localhost/9am/data.java");
$arr= json_decode($data);
print_r($arr);
*/


//fopen("path-of-the-file","file mode");
//$fp=fopen("hi.txt","r");
//echo fread($fp,200)
/*while($line=fgetss($fp))
{
	echo $line."<br>";
}*/





/*$fp=fopen("hi.txt","a");
echo fwrite($fp,"Hyderbaad");
*/

//echo fread($fp,100);
//echo $fp;

?>