<pre><?php 
//read Data from FORM
//print_r($_POST);

echo $_REUQEST['name'];
echo $_REUQEST['email'];





/*$name=$_POST['name'];
$e=$_POST['email'];
$m=$_POST['mobile'];*/
//connect to DB
//insert data into DB

?>
