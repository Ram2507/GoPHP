<?php 
include("connect.php");
?>
<html>
	<head>
		<title>GoPHP-View Employees</title>
	</head>
	<body>
		<h1>View Employees</h1>
		<p><a href="add_employee.php">Add Employee</a></p>
		
		
		<?php 
		if(isset($_COOKIE['success']))
		{
			echo "<p>".$_COOKIE['success']."</p>";
		}
		
		$res=mysqli_query($con,"select *from employee");
		if(mysqli_num_rows($res)>0)
		{
			?>
				<table border=1>
			<tr>
				<th>Emp_ID</th>
				<th>Name</th>
				<th>Email</th>
				<th>Salary</th>
				<th>Designation</th>
				<th>Address</th>
				<th>Date of Joining</th>
				<th>Creatd Time</th>
				<th>Action</th>
			</tr>
			<?php 
			while($row=mysqli_fetch_assoc($res))
			{
				?>
					<tr>
						<td><?php echo $row['eid'];?></td>
						<td><?php echo $row['name'];?></td>
						<td><?php echo $row['email'];?></td>
						<td><?php echo $row['salary'];?></td>
						<td><?php echo $row['designation'];?></td>
						<td><?php echo $row['address'];?></td>
						<td><?php echo $row['doj'];?></td>
						<td><?php echo $row['created_time'];?></td>
						<td><a href="edit_employee.php?empid=<?php echo $row['eid']?>">Edit</a>
						<a href="javascript:void(0)" onclick="deleteEmployee('<?php echo $row['eid'] ?>')">Delete</a>
						</td>
					</tr>
				<?php
			}
			?>
		</table>
			<?php
		}
		else
		{
			echo "<p>Sorry! No Employees FOund</p>";
		}
		?>
		<script>
			function deleteEmployee(id)
			{
				var c=confirm("Do You want to Delete?");
				if(c==true)
				{
					window.location="delete_employee.php?empid="+id;
				}
			}
		</script>
	</body>
</html>