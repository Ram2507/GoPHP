<html>
	<head>
		<title>Multiple File Uploading</title>
	</head>
	<body>
		<h1>Multiple File Uploading</h1>
		<?php 
		if(isset($_POST['upload']))
		{
			$c=count($_FILES['image']['name']);
			for($i=0;$i<$c;$i++)
			{
				if(is_uploaded_file($_FILES['image']['tmp_name'][$i]))
				{
					$filename=$_FILES['image']['name'][$i];
					$size=$_FILES['image']['size'][$i];
					$type=$_FILES['image']['type'][$i];
					$tpath=$_FILES['image']['tmp_name'][$i];
					$error=$_FILES['image']['error'][$i];
					
					$str="abcdefghijklmopqrstuvwxyz";
					$ext=substr(str_shuffle($str),5,15);
					$newname=$ext.$filename;
					
					
					if($type=="image/png" || $type=="image/gif" 
					|| $type=="image/jpg" || $type=="image/jpeg")
					{
						$status=move_uploaded_file($tpath,"uploads/$newname");
						if($status==1)
						{
							echo "<p>$filename  Uplaoded Successfully</p>";
						}
					}
					else
					{
						echo "<p>$filename is not a valid Image</p>";
					}
					
					
				}
				else
				{
					echo "<p>Please slect a file to upload</p>";
				}
			}
		}
		?>
		<form method="POST" action="" 
		enctype="multipart/form-data">
		
			Upload Profile Pic:
			<input type="file" name="image[]" multiple><br><br>
			<input type="submit" name="upload" 
			value="Submit">
		</form>
	</body>
</html>