<?php 
$x="200";

$x=(int)$x;
/*$x=(float)$x;
$x=(double)$x;
$x=(bool)$x;
$x=(string)$x;
$x=(array)$x;*/
$x=(object)$x;
echo is_object($x);


//echo is_string($x);


/*$x=200
is_int($x);//1
is_float($x);//
is_double($x);//
is_string($x);//
is_bool($x);//
is_array($x);//
is_object($x);//
*/


/*$x="hello";
$y=300;
var_dump($x);//string(5) "hello" 
*/

/*$x=200;
echo isset($x);//1
*/
/*$x=200;
unset($x);
echo $x;
*/

?>