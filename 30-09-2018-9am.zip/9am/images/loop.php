<?php
$i=11;
do{
	echo $i."<br>";
	$i++;
}
while($i<=10);



/*
$table=13;
$i=1;
while($i<=10)
{
	echo $table."*".$i."=".$table*$i."<br>";
	$i++;
}
*/






//2 to 20 tables prints

/*for($k=2;$k<=20;$k++)
{
	echo "<div>";
	$table=$k;
	for($i=1;$i<=10;$i++)
	{
		echo $table."*".$i."=".$table*$i."<br>";
	}
	echo "</div>";
}
*/


/*$x=200;
$y=300;
$z=$x+$y;

echo 'The Sum of '.$x. 'and' .$y. 'is'.$z;
*/


/*$table=13;
for($i=1;$i<=10;$i++)
{
	echo $table."*".$i."=".$table*$i."<br>";
}
*/


/*
for($i=1;$i<=10;$i=$i+2)
{
		echo $i;
		echo "<br>";
	
}
*/

//1 to 5
/*$i=1;
for(;;)
{
	echo $i;
	echo "<br>";
	if($i==10)
	{
		break;
	}
	$i++;
	
	
}
*/
?>