<?php 
for($i=2;$i<=20;$i++)
{
	for($k=2;$k<$i;$k++)
	{
		if($i%$k==0)
		{
			break;
		}
	}
	if($i==$k)
	{
		echo $k."<br>";
	}
}
?>