<?php 
include("connect.php");
if(isset($_REQUEST['userid']))
{
	$uid=$_REQUEST['userid'];
	mysqli_query($con,
	"update register set status='Active' 
	where id=$uid");
	if(mysqli_affected_rows($con)==1)
	{
		echo "<p>Account Activated Successfully. 
		please <a href='login.php'>Login Now</a>
		</p>";
	}
	else
	{
		echo "<p>Your account is already 
		activated. please 
		<a href='login.php'>Login Now</a></p>";
	}
}
?>