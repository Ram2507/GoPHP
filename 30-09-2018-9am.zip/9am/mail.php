<?php

$x=mail("rambabburi@gmail.com",
"test email","Hi Welcome")
echo $x;//1

