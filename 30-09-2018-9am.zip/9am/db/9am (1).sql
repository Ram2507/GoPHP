-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 30, 2018 at 07:04 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `9am`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `city` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `message`, `mobile`, `city`) VALUES
(1, 'ram', 'ram@mail.com', 'Hello How are our', 234234234, 'Hyderebad'),
(2, 'siva', 'siva@mail.com', 'hello', 2423642364, 'Chennai'),
(3, 'ravi', 'ravi@mail.com', 'Hello', 988568956, 'Hyderabad'),
(4, 'hello', 'hello@mail.com', 'Welcome to Hyd', 988568956, 'Mumbai');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `eid` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `salary` int(11) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `doj` date NOT NULL,
  `created_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`eid`, `name`, `email`, `salary`, `designation`, `address`, `doj`, `created_time`) VALUES
('CnP-2', 'naresh', 'admin@mail.com', 17000, 'Developer', 'dfgdf', '2016-02-25', '2018-09-30 10:25:11'),
('CnP-3', 'ravi', 'naresh@mail.com', 12500, 'Developer', 'fghfg', '2018-09-28', '2018-09-30 10:25:29');

-- --------------------------------------------------------

--
-- Table structure for table `enquiry`
--

CREATE TABLE `enquiry` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `message` text NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `enquiry`
--

INSERT INTO `enquiry` (`id`, `name`, `email`, `mobile`, `message`, `date`) VALUES
(1, 'ram', 'ram@mauil.com', 0, 'wdfsdf', '2018-09-11 10:33:04'),
(2, 'ravi', 'ram@mail.com', 12312312, 'adfasdsa', '2018-09-11 10:33:59'),
(3, 'naresh', 'naresh@mail.com', 1212121212, 'adasdasd', '2018-09-11 10:36:28'),
(4, 'hello', 'babburi@mail.com', 12312312, 'deasewq', '2018-09-11 10:37:17'),
(5, 'ramu', 'ramu@mail.com', 2312312, 'fdwf', '2018-09-11 10:39:10'),
(6, 'ram', 'ram@mauil.com', 12312312, 'AS', '2018-09-11 10:42:58'),
(7, 'ram', 'ram@mauil.com', 12312312, 'AS', '2018-09-11 10:43:31'),
(8, 'naresh', 'ram@mauil.com', 12312312, 'sdfgdfgd', '2018-09-11 10:45:15'),
(9, 'naresh', 'ram@mauil.com', 12312312, 'sdfgdfgd', '2018-09-11 10:45:41');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(32) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `terms` varchar(3) NOT NULL,
  `date_of_reg` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ip` varchar(30) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'InActive',
  `profile_pic` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `username`, `email`, `password`, `city`, `state`, `gender`, `terms`, `date_of_reg`, `ip`, `status`, `profile_pic`) VALUES
(1, 'ram', 'ram@mail.com', '202cb962ac59075b964b07152d234b70', 'Ongole', 'Maharastra', 'male', 'yes', '2018-09-17 10:25:06', '::1', 'Active', 'lwf8xht1cir2715udgknChrysanthemum.jpg'),
(2, 'naresh', 'naresh@mail.com', '202cb962ac59075b964b07152d234b70', 'Hyderabad', 'Telangana', 'male', 'yes', '2018-09-17 10:31:23', '::1', 'Active', 'tb8skip9f7y1x5ljzdu5Koala.jpg'),
(3, 'suresh', 'suresh@mail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'Hyderabad', 'Andhrapradesh', 'male', 'yes', '2018-09-17 10:39:19', '::1', 'Active', ''),
(4, 'Ramu', 'rambabburi@gmail.com', '202cb962ac59075b964b07152d234b70', 'Hyderabad', 'Andhrapradesh', 'male', 'yes', '2018-09-17 10:43:13', '::1', 'Active', 'qsouim5kwcpht1yz5rnxHydrangeas.jpg'),
(5, 'ram kumar', 'sanjusanjeevvv@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'Hyderabad', 'Telangana', 'male', 'yes', '2018-09-17 10:51:17', '::1', 'Active', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`eid`);

--
-- Indexes for table `enquiry`
--
ALTER TABLE `enquiry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `enquiry`
--
ALTER TABLE `enquiry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
