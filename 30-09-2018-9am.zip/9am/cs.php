<?php 
require("welcome.php");
require("welcome123.php");//FE
require("welcome.php");
require("welcome.php");
?>