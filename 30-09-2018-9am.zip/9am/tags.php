<?php 
	echo "I am Standard Tag";

?>

<?
	echo "I am Short Open Tag";
?>