<html>
	<head>
		<title>Session And Cookie</title>
	</head>
	<body>
		<h1>Person 3</h1>
		<form method="POST" action="p4.php">
			No3:<input type="text" name="num3">
			<input type="submit" value="Go">
		</form>
	</body>
	<?php 
	session_start();
	//setcookie("number2",$_POST['num2']);
	$_SESSION["number2"]=$_POST['num2'];
	?>
	
</html>