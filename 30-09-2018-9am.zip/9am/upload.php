<html>
	<head>
		<title>File Uploading</title>
	</head>
	<body>
		<h1>File Uploading</h1>
		
		<?php 
		if(isset($_POST['upload']))
		{ 	
			if(is_uploaded_file($_FILES['image']['tmp_name']))
			{
				$filename=$_FILES['image']['name'];
				$size=$_FILES['image']['size'];
				$type=$_FILES['image']['type'];
				$tpath=$_FILES['image']['tmp_name'];
				$error=$_FILES['image']['error'];
				
				$str="abcdefghijklmopqrstuvwxyz";
				$ext=substr(str_shuffle($str),5,15);
				$newname=$ext.$filename;
				
				
				if($type=="image/png" || $type=="image/gif" 
				|| $type=="image/jpg" || $type=="image/jpeg")
				{
					$status=move_uploaded_file($tpath,"uploads/$newname");
					if($status==1)
					{
						echo "<p>File Uplaoded Successfully</p>";
					}
				}
				else
				{
					echo "<p>PLease select a Valid Image Type</p>";
				}
				
				
			}
			else
			{
				echo "<p>Please slect a file to upload</p>";
			}
			
		}
		?>
		
		<form method="POST" action="" 
		enctype="multipart/form-data">
		
			Upload Profile Pic:
			<input type="file" name="image"><br><br>
			<input type="submit" name="upload" 
			value="Submit">
		</form>
	</body>
</html>