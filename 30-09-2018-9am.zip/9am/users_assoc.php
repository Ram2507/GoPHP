
<html>
	<head>
		<title>Users</title>
		<style>
			table{
				border-collapse:collapse;
			}
			table tr td{
				border:1px solid;
				padding:5px;
			}
		</style>
	</head>
	<body>
		<h1>All Users</h1>
		<?php 
		$con=mysqli_connect("localhost","root","","9am");
		$result=mysqli_query($con,
		"select *from contact");
		if(mysqli_num_rows($result)>0)
		{
			?>
			<table>
			<tr>
				<td>Id</td>
				<td>Name</td>
				<td>Email</td>
				<td>Mobile</td>
				<td>City</td>
				<td>Message</td>
				<td>Action</td>
			</tr>
			<?php 
			while($row=mysqli_fetch_object($result))
			{
				?>
					<tr>
					<td><?php echo $row->id;?></td>
					<td><?php echo $row->name;?></td>
					<td><?php echo $row->email;?></td>
					<td><?php echo $row->mobile;?></td>
					<td><?php echo $row->city;?></td>
					<td><?php echo $row->message;?></td>
					<td>
						<a href="edit.php">Edit</a>
						<a href="">Deleet</a>
					</td>
					
				</tr>
				<?php
			}
			
			?>
			
		</table>
			<?php
		}
		else
		{
			echo "<p>Sorry! NO records found</p>";
		}
		?>
		
	</body>
</html>