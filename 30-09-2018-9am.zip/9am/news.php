<P><a href="read.php?id=1">News Title1</a></P>
<P><a href="read.php?id=2">News Title2</a></P>
<P><a href="read.php?id=3">News Title3</a></P>
