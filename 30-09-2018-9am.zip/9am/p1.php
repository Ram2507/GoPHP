<html>
	<head>
		<title>Session And Cookie</title>
	</head>
	<body>
		<h1>Person 1</h1>
		<form method="POST" action="p2.php">
			No1:<input type="text" name="num1">
			<input type="submit" value="Go">
		</form>
	</body>
	
</html>