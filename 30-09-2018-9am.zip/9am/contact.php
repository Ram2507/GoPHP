<html>
	<head>
		<title>Contact Here</title>
		<style>
			table{
				border-collapse:collapse;
			}
			table tr{border-bottom:1px solid #d4d4d4;}
			table tr td{padding:5px;}
		</style>
	</head>
	<body>
		<h1>Contact Here</h1>
		
		<?php 
		if(isset($_POST['save']))
		{
			//4. collecting form data
			$name=$_POST['name'];
			$email=$_POST['email'];
			$mob=$_POST['mobile'];
			$msg=$_POST['msg'];
			//5.connect to DB
			$con=mysqli_connect("localhost","root","","9am");
			//6.Insert data into a table
			mysqli_query($con,"insert into enquiry(name,email,
			mobile,
			message) values('$name','$email','$mob',
			'$msg')");
			if(mysqli_affected_rows($con)==1)
			{
				//7. send email notofication 
				$to="admin@mail.com";
				$subject="Contact Form-datetime";
				$message="HI Admin,<br><br>Mr. $name has been 
				contacted
				below are the details:<br>
				Message:$msg<br>
				Email:$email <br>
				Mobile: $mob <br><br>
				
				Thanks<br>Team";
				$mheaders="Content-Type:text/html";
				if(mail($to,$subject,$message,$mheaders))
				{
					echo "<p>Thanks. We get back you soon</p>";
				}
				else
				{
					echo "Error";
				}
			}
			else
			{
				echo "<p>Sorry! Tray Again</p>";
			}
			
		}
		?>
		
		<form method="POST" action="" 
		onsubmit="return formValidate()">
			<table>
				<tr>
					<td>Name</td>
					<td><input type="text" name="name" id="name"></td>
				</tr>
				<tr>
					<td>Email</td>
					<td><input type="text" name="email" id="email"></td>
				</tr>
				<tr>
					<td>Mobile</td>
					<td><input type="text" name="mobile" id="mobile"></td>
				</tr>
				<tr>
					<td>Message</td>
					<td><textarea name="msg"></textarea></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" name="save" value="Send"></td>
				</tr>
			</table>
		</form>
		<script>
			function formValidate()
			{
				var name=document.getElementById("name").value
				if(name=="")
				{
					alert("Enter Name");
					return false;
				}
			}
		</script>
	</body>
</html>
