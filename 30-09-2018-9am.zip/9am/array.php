<pre><?php 

print_r($_COOKIE);

/*
$arr=array(10,20,30,40,50,60,70,80,90);
array_splice($arr,1,0,100);
print_r($arr);
*/

/*
$arr=array(10,20,30,40);
unset($arr[1]);
print_r($arr);*/
//$arr[2]=50;
//echo array_unshift($arr,50);
//print_r($arr);




/*$arr=array(
	"name"=>"Naresh",
	"city"=>"Hyderabad",
	"state"=>"TS",
	"pincode"=>500038,
);
$fa=array_values($arr);
print_r($fa);
*/

//echo array_key_exists("city",$arr);
//echo array_search(40,$arr);//3


/*$a2=array(100,200,300,400);
$a3=array("w","e","r","t");
$fa=array_merge($a2,$a1,$a3);
print_r($fa);
*/

//$arr=array(10,20,30,true,"Hi");
//print_r($arr);
//echo array_sum($arr);//61.5


//$arr=array("s","a","d","b");
/*$arr=array(
	"name"=>"Naresh",
	"city"=>"Hyderabad",
	"state"=>"TS",
	"pincode"=>500038,
);
krsort($arr);
print_r($arr);
*/

/*$arr=array(
	"name"=>"Naresh",
	"city"=>"Hyderabad",
	"state"=>"TS",
	"pincode"=>500038,
);
echo count($arr);
	*/
/*$arr=array(
	"name"=>"Naresh",
	"city"=>"Hyderabad",
	"state"=>"TS",
	"pincode"=>500038,
);
echo $arr["name"];
echo $arr["city"];
echo $arr["state"];
*/

/*$arr=array(
		array(10,30,40),
		array("ram","ravi","Naresh"),
		array("a","d","f","t"),
		array(100,200),
	);

print_R($arr);
*/
/*$arr=array(10,20,30,array(100,200));
//print_r($arr);
print_r($arr[3][1]);
*/
//$varibale=array('value1','value2',...);
//$a=array("Ram","Siva","Naresh");
//$b=array("PHP",50,true,10.12);
//$arr=array(10,20,30,40);

/*$arr=array(15=>200,300,16=>400);
print_R($arr);
*/
/*
$arr=array("1"=>"true",1=>1,true=>10);
print_r($arr);
*/








?>