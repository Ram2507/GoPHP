<?php
ini_set("max_file_uploads",50);

//echo ini_get("max_file_uploads");