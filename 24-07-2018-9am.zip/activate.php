<?php 
include("connect.php");
if(isset($_REQUEST['key']))
{
	$userid=$_REQUEST['key'];
	$result=mysqli_query($con,"select id,status from 
	register where id=$userid");
	if(mysqli_num_rows($result)==1)
	{
		mysqli_query($con,"update register set 
		status='Active' where id=$userid");
		if(mysqli_affected_rows($con)==1)
		{
			echo "Your account Activated Successfully";
		}
		else
		{
			echo "Your account already Activated";
		}
	}
	else
	{
		echo "We are unable to Update your account";
	}
}
else
{
	die("Sorry! Wrong window");
}
?>