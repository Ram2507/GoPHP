<html>
	<head>
		<title>Printing 2 to 20 tables</title>
		<style>
			.table{
				width:15%;
				display:inline-block;
				border:1px solid;
				padding:10px;
				
			}
			.color{
				background:green;
			}
		</style>
	</head>
	<body>
		<h1>Printing 2 to 20 tables</h1>
		<div class="container">
			<?php 
				for($j=2;$j<=20;$j++)
				{
					$table=$j;
					if($j%2==0)
					{
			echo "<div class='table color'>";
					}
					else
					{
			echo "<div class='table'>";
					}
					
					for($i=1;$i<=10;$i++)
					{
						ECho $table."*".$i."=".$table*$i;
						echo "<br>";
					}
					echo "</div>";
					
				}
				
			?>
		</div>
	</body>
</html>