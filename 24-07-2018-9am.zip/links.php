<a href="view.php?id=1">Movie title 1</a><br>
<a href="view.php?id=12">Movie title 2</a><br>
