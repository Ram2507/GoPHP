<?php require("header.php");?>
<div>
	<h1>Our Services</h1>
	<P>Software Developmnent</p>
	<P>Software Training</p>
	<P>Web Designing</p>
</div>
<?php include("footer.php");?>