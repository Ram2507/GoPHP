<?php session_start();?>
<html>
	<head>
		<title>SESSION and COOKIE</title>
	</head>
	<body>
		<h1>Person-3</h1>
		<form method="POST" action="p4.php">
			Number3:<input type="text" name="num3">
			<input type="submit" value="Go">
		</form>
	</body>
</html>
<?PHP 
//setcookie("number2",$_POST['num2']);
$_SESSION['number2']=$_POST['num2']

?>