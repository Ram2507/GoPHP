
<?php 
//echo $_SERVER['HTTP_HOST'];//localhost:100
//echo $_SERVER['SERVER_NAME']//localhost
//echo $_SERVER['SERVER_PORT'];//100
//echo $_SERVER['REMOTE_ADDR'];
//echo $_SERVER['SERVER_SOFTWARE'];
//echo $_SERVER['DOCUMENT_ROOT'];
//echo $_SERVER['HTTP_USER_AGENT'];
//echo $_SERVER['REQUEST_METHOD'];

?>




