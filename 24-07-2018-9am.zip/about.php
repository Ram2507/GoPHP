<?php include("header.php"); ?>
		<div>
			<h1>About</h1>
			<p>This program is free software;
			you can redistribute it </p>
		</div>
<?php include("footer.php"); ?>