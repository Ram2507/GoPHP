<?php include("header.php"); ?>
		<div>
			<h1>Contact</h1>
			
		</div>
<?php include("footer.php")?>
		