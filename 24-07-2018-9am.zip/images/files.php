<?php
$fold="images";
if(file_exists($fold))
{
	rmdir($fold);
	echo "Folder Deleted";
}
else
{
	echo "Folder Not Exists";
}



//echo file_exists("hello.php");//1
//echo is_file("hello.php");//1
/*
$file="home.txt";
if(file_exists($file))
{
	unlink($file);
	echo $file." is Deleted...";
}
else
{
	echo $file." is not Avaliable";
}
*/

//echo unlink("welcome.txt");



//echo file_get_contents("http://facecook.com");
//echo file_get_contents("welcome.txt");
//echo file_get_contents("php://input");

//echo file_put_contents("hi.txt","Hello WOrld");

//echo filectime("welcome.txt");
//echo date("l,dS F Y h:i:s a",filectime("hello.php"));
//date_default_timezone_set("Asia/Calcutta");
//echo date("l,dS F Y h:i:s a",filemtime("files.php"));


/*$fp=fopen("welcome.txt","r");
echo fgetss($fp);
*/
/*while($line=fgets($fp))
{
	echo $line."<br>";
}

var_dump($line);
*/



//$size=filesize("welcome.txt");
//echo fread($fp,$size);


//$fp=fopen("welcome.txt","r");


?>
