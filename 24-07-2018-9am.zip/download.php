<?php 
header('Content-Disposition:attachment;
filename=project.zip');
readfile("9am.zip");

?>

 
