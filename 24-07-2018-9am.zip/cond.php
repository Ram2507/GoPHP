<?php 
switch($x="Thu")
{
	case "Mon":
	echo "Monday";
	break;
	
	case "Tue":
	echo "Tuesday";
	break;
	
	case "Wed":
	echo "wednesday";
	break;
	
	default:
	echo "Sorry!";
}
/*$m=75;
if($m>=90)
{
	echo "Grade A";
}
else if($m>=80)
{
	echo "Grade B";
}
else if($m >=70)
{
	echo "Grade C";
}
else if($m>=60)
{
	echo "Grade D";
}
else{
	echo "Fail";
}*/
?>