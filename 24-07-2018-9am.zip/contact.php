<html>
	<head>
		<title>Contact Here</title>
	</head>
	<body>
		<h1>Contact Here</h1>
		<?php 
			if(isset($_POST['submit']))
			{
				$name=$_POST['uname'];
				$email=$_POST['email'];
				$mob=$_POST['mobile'];
				$msg=$_POST['msg'];
			$con=mysqli_connect("localhost","root","","9am");
				mysqli_query($con,"insert into contact
				(username,email,mobile,message) 
				values('$name','$email',$mob,'$msg')");
				echo mysqli_error($con);
				if(mysqli_affected_rows($con)==1)
				{
					echo "<p>Thanks. We will get back you soon</p>";
				}
				else
				{
	echo "Sorry! Try Agaian";
				}
			}
		?>
		
		<form action="" method="POST">
			<table>
			<tr>
				<td>Username</td>
				<td><input type="text" name="uname"></td>
			</tr>
			<tr>
				<td>Email</td>
				<td><input type="text" name="email"></td>
			</tr>
			<tr>
				<td>Mobile</td>
				<td><input type="text" name="mobile"></td>
			</tr>
			<tr>
				<td>Message</td>
				<td><textarea name="msg"></textarea></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" name="submit" 
				ZValue="Send"></td>
			</tr>
		</table>
		</form>
	</body>
</html>