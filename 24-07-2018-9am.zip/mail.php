<?php
$to="ram@mail.com,admin@mail.com";
$subject="Activation Link";

$message="Hi Ram,<br><br>
How are you?. 
account<br><br>
<a href=''>Activate Now</a><br><br>
Thanks
<br>Team";

$mheaders=array(
	"From"=>"info@company.com",
	"reply-to"=>"info@company.com",
	"Content-Type"=>"Text/html",
	"CC:"=>"other@mail.com",
);

if(mail($to,$subject,$message,$mheaders))
{
	echo "Mail Sent Success";
}

?>


