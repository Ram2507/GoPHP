<?php 
/*$x="200";
$x=(int)$x;
var_dump($x);//int(200)

(int)$x;//converts into int
(float)$x;//converts into float
(double)$x;//converts into double
(bool)$x;//converts into bool
(string)$x;//converts into string
*/
/*is_int();
is_float();
is_double();
is_string();
is_bool();
is_array();
is_object();
*/



/*$x=200;
unset($x);
echo $x;
*/
//$x="hi";
//echo is_int($x);

//echo isset($x);


?>
 
 