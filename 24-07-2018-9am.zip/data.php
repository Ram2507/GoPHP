<pre><?php 
$con=mysqli_connect("localhost","root","","7am");
$result=mysqli_query($con,"select *from register");
if(mysqli_num_rows($result))
{
	//echo mysqli_num_rows($result);
	//echo mysqli_num_fields($result);
	while($col=mysqli_fetch_field($result))
	{
		print_r($col->name."");
	}
}
else
{
	echo "No Records Found";
}
?>