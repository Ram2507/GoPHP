<?php
Declaration style tags in php



/*
$x=false;
var_dump($x);
*/
//$x=200;
//print_r($x);
//print($x);
//$arr=array(10,20,30);
//print_r($arr);



/*$x=100;
$y=200;

$z=echo $x;//error

//valid
$z=print $x;
echo $z;
*/
//echo $x;



//echo echo $x;



//print $x,$y,"hello";//Error
//echo $y,$x,"hello";

//echo $x,$y;
//print $y,$x;



/*print($x);
print("Hello");
*/

/*echo($x);
echo("Hello");
*/

?>