<html>
	<head>
		<title>Welcome to PHP</title>
		<style>
			h1{
				color:red;
			}
		</style>
		<script>
		alert("hello");
		</script>
	</head>
	<body>
		<h1>Hello World</h1>
		<p><?php echo "PHP Clas";?></p>
		<?php 
		echo "this is php";
		?>
	</body>
</html>