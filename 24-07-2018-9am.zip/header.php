<html>
	<head>
		<title>COntrol Structures</title>
	</head>
	<body>
		<div style="background:red">
			<ul>
				<li><a href="home.php">Home</a></li>
				<li><a href="about.php">About</a></li>
			<li><a href="contact.php">Contact</a></li>
			<li><a href="services.php">Services</a></li>
			</ul>
		</div>