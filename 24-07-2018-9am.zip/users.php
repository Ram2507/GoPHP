<html>
	<head>
		<title>Users Data</title>
		<style>
			table{
				border-collapse:collapse;
			}
			table tr td,th{padding:10px;
			border:2px solid #999;
			}
			h1{
				text-align:center;
			}
			table tr:nth-child(odd)
			{
				background:#efefef;
			}
			table tr:nth-child(even)
			{
				background:#d4d4d4;
			}
		</style>
	</head>
	<body>
		<H1>Users Data</h1>
		
		<?php 
		$con=mysqli_connect("localhost","root","","9am");
		$result=mysqli_query($con,"select *from contact");
		if(mysqli_num_rows($result)>0)
		{
			?>
			<table align="center">
			<tr>
				<th>Id</th>
				<th>Name</th>
				<th>Email</th>
				<th>Mobile</th>
				<th>Message</th>
			</tr>
			<?php while($row=mysqli_fetch_array($result))
			{
				?>
				<tr>
					<td><?php echo $row['id'];?></td>
					<td><?php echo $row['username']?></td>
					<td><?php echo $row['email']?></td>
					<td><?php echo $row['mobile']?></td>
					<td><?php echo $row['message']?></td>
					
				</tr>
				<?php
			}
			?>
			
		</table>
			<?php
		}
		else
		{
			echo "Sorry! No Records Found";
		}
		?>
	</body>
</html>