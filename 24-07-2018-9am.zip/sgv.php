<?php 
$x=200;
$y=200;
function add()
{
	$z=$GLOBALS['x']+$GLOBALS['y'];
	echo $z;
}
add();

?>