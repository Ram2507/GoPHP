<pre>
<?php 
echo $_COOKIE['number1'];
echo $_COOKIE['number2'];


/*$arr=array(
	array(10,20,30,40),
	array(200,300,400),
	array("Ravi","ram"),
	array("php","mysql","wordpress "),
);*/


/*$arr=array(
	"state"=>"TS",
	"city"=>"Hyd",
	"pin"=>"123123",
	"country"=>"IN",
);
foreach($arr as $k=>$v)
{
	echo $k."=".$v."<br>";
}
*/

/*$arr=array(10,20,30,40,50,60,70,80,90);
$c=count($arr);
for($i=0;$i<$c;$i++)
{
	echo $arr[$i]."<br>";
}
*/



//array_splice($arr,0,0,array(array(100,200)));
//print_r($arr);


//$a1=array_slice($arr,0,3);
//slice an array from 0 position to 3 elems

//$a1=array_slice($arr,5);
//slice an array from 5 position to all elems
//print_r($a1);




//$arr=array(40,50,70,20,30);
//echo next($arr);
//echo current($arr);
//echo end($arr);//30
//echo prev($arr);//20
//echo current($arr);
//echo current($arr);


/*$arr=array(
	"state"=>"TS",
	"city"=>"Hyd",
	"pin"=>"123123",
	"country"=>"IN",
	);
$ar=array_keys($arr);
print_r($ar);*/
/*$arr=array(10,10,10,40,50,70,20,30,10,70);
$ar=array_unique($arr);
print_r($ar);
*/

//$str="hello"


/*
$arr=array("ravi","ram","ravi","rak","ravi");
//echo array_search("ravi",$arr)

echo $arr[1];
echo "<br>";
echo $arr[2];
echo "<br>";
echo $arr[3];
*/


/*$arr=array(10,20,30,40);
$arr[2]=60;

print_r($arr);
*/
/*$arr[]=30;
$arr[]=40;
print_r($arr);
*/





/*$arr=array(10,20,30,40);
array_unshift($arr,25);
print_r($arr);
*/
//$arr=array(3=>10,5=>2,1=>45,7=>23);
//echo array_key_exists(7,$arr)




//$arr=array("ram","ravi","suresh","krish");
//echo array_search("ravi",$arr);
//echo in_array("krish",$arr);




/*$a1=array(10,20,30);
$a2=array(100,200,300);
$fa=array_merge($a1,$a2);
print_r($fa);
*/
//$arr=array(5,10,false);
//echo array_product($arr);//0
//echo array_sum($arr);//16



//$arr=array(10,20,30,array(100,200,300));
//echo count($arr,true);//7

/*$arr=array(3=>10,5=>2,1=>45,7=>23);
krsort($arr);
print_r($arr);
*/

/*$arr=array(
	"state"=>"TS",
	"city"=>"Hyderabad",
	"pincode"=>500038
);
print_r($arr);
echo $arr['city'];
*/
//echo $arr['State'];
//undefined index State error

/*$arr=array(
	"key1"=>"value1",
	"key2"=>"value2",
	"key3"=>"value3",
	...........
	...........
	)
*/


/*$arr=array(
		array(10,20,30),
		array(100,200,300),
		array("a","b","v")
	);
print_r($arr[2][1]);
*/
/*$arr=array(10,20,30,array(100,200,300));
echo $arr[3][1];
*/

//$arr=array(10,20,30,40,50);
//$arr=array(true,false,"Ram","Sam",30);
//$arr=array(10,5=>20,8=>30,40,60);

/*$arr=array(
	1=>1,
	true=>1,
	1=>true,
	"1"=>1
);
print_r($arr);
*/



/*echo $arr[2];//30
echo $arr[3];//40

echo $arr[10];//undefined offset 10
*/
?>
