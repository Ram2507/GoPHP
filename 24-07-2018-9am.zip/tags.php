<?php 
	echo "Standard Tag";
?>
<? 
	echo "short Open tag";
?>

<script language="PHP">
echo "I am Script";
</script>

<%
echo "Welcome to ASP";

%>
