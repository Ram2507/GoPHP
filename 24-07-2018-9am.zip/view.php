<?php 
echo "In View Page";

echo $_GET['id'];

?>