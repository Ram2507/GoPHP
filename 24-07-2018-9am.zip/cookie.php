<?php 
setcookie("city","Hyderabad",time()+60);
setcookie("number1","20",time()+60);