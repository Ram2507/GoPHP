<div style="background:green">
			<p>All Copy Rights reserved</p>
		</div>
	</body>
</html>