<pre>
<?php 
print_r($_REQUEST);
echo "<br>";
$name=$_REQUEST['uname'];
$e=$_REQUEST['email'];
$p=$_REQUEST['pwd'];

echo $name,$e,$p;

//connect to Db
//Insert data into Table

?>