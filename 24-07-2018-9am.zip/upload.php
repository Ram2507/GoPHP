<html>
	<head>
		<title>File Uploading</title>
	</head>
	<body>
		<h1>File Uploading</h1>
		<?php 
		if(isset($_POST['submit']))
		{
			if(is_uploaded_file($_FILES['image']['tmp_name']))
			{
				$filename=$_FILES['image']['name'];
				$size=$_FILES['image']['size'];
				$type=$_FILES['image']['type'];
				$path=$_FILES['image']['tmp_name'];
				
				$types=array(
					"image/jpeg",
					"image/jpg",
					"image/png",
					"image/gif",
				);
				if(in_array($type,$types))
				{
					$status=move_uploaded_file($path,
					"uploads/$filename");
					if($status==1)
					{
						echo "File Uploaded Successfully";
					}
					else
					{
						echo "sorry! Unable to upload try again";
					}
				}
				else
				{
					echo "Please slect a Valid image";
				}
				
				/*echo "Filename:".$filename."<br>";
				echo "File Size:".($size/1024)."<br>";
				echo "File Type:".$type."<br>";
				echo "File Path:".$path."<br>";*/
			}
			else
			{
				echo "Please select File";
			}
		}
		
		
		?>
		
		<form action="" method="POST" 
		enctype="multipart/form-data">
			<table>
			<tr>
				<td>Select File to Upload</td>
				<td><input type="file" name="image"></td>
			</tr>
			
			<tr>
				<td></td>
				<td><input name="submit" type="submit"  
				value="Upload"></td>
			</tr>
		</table>
		</form>
	</body>
<html>