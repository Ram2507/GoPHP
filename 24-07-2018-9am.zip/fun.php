<?php 
function birthday($dno,$area,$lm)
{
	echo "Happy Birthday<br>";
	echo "Address".$dno.",".$area.
	",".$lm."<br>";
	echo "<br>Food<br>=======<br>";
	echo "<br>1.Biriyani<br>";	
}
birthday("27/D","S.R.Nagar",
"Nalanda School");
birthday("29/D","S.R.Nagar",
"Nalanda School");





?>