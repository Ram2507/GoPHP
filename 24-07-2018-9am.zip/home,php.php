<html>
	<head>
		<title>COntrol Structures</title>
	</head>
	<body>
		<div style="background:red">
			<ul>
				<li><a href="home.php">Home</a></li>
				<li><a href="about.php">About</a></li>
				<li><a href="contact.php">Contact</a></li>
			</ul>
		</div>
		<div>
			<h1>About</h1>
			<p>This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.</p>
		</div>
		<div style="background:green">
			<p>All Copy Rights reserved</p>
		</div>
	</body>
</html>