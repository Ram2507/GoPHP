<?php 
$arr=array(10,15.5,"hello");
echo in_array("test",$arr);
//date_default_timezone_set("Asia/Kolkata");
//echo date("h:i:s");
//echo date("Y");//Y returns current Year
//echo date("y");
//y returns current Year with two digits(18)
//echo date("d-m-Y");//26-06-2018
//echo date("Y-m-d");//26-06-2018
//echo date("h:i:s a");
//26th June 2018
//echo date_default_timezone_get();
//Europe/Berlin
//date_default_timezone_set("Asia/Kolkata");
//date_default_timezone_set("Asia/Dubai");
//date_default_timezone_set("Asia/Singapore");
//date_default_timezone_set("Pacific/Auckland");
//date_default_timezone_set("America/new_york");
//date_default_timezone_set("Europe/London");
//echo date("d-m-Y h:i:s a");
//echo date("l,dS F Y h:i:s a");

//echo date("L")
//echo time();
//echo time();
/*echo date("l,dS F Y",1520071958);
echo "<br>";
echo date("Y-m-d h:i:s a",1520071958);
echo "<br>";
echo date("d/m/Y",1520071958);
*/
//echo strtotime("1 day 2 weeks");
//echo date("l",strtotime("1947-08-15"));

/*$arr=array(
	array(100,200,300),
	array(10,20,30,40,50,60),
	1000,2000,3000,
	array("a","c"),
);
$c=count($arr);
for($i=0;$i<$c;$i++)
{
	if(is_array($arr[$i]))
	{
		for($j=0;$j<count($arr[$i]);$j++)
		{
			echo $arr[$i][$j];
			echo "<br>";
		}
	}
	else
	{
		echo $arr[$i]."<br>";
	}
	
}








?>


