<html>
	<head>
		<title>Multiple File Uploading</title>
	</head>
	<body>
		<h1>Multiple File Uploading</h1>
		<?php 
		if(isset($_POST['upload']))
		{
			$c=count($_FILES['image']['name']);
			
			for($i=0;$i<$c;$i++)
			{
				if(is_uploaded_file($_FILES['image']['tmp_name'][$i]))
				{
					$filename=$_FILES['image']['name'][$i];
					$size=$_FILES['image']['size'][$i];
					$type=$_FILES['image']['type'][$i];
					$path=$_FILES['image']['tmp_name'][$i];
					
					$str="abcdefghijklmonpqrstuwxyzABCDEFGHIJKLMONPQRSTUVWXYZ1234567890";
					$x=str_shuffle($str);
					$fname=substr($x,10,26)."_".time();
					
					$ext=explode("/",$type);
					$ext=$ext[1];					
					$filename=$fname.".".$ext;
					
					$types=array(
						"image/jpeg",
						"image/jpg",
						"image/png",
						"image/gif",
					);
					if(in_array($type,$types))
					{
						$status=move_uploaded_file($path,
						"uploads/$filename");
						if($status==1)
						{
							echo "<p>".$_FILES['image']['name'][$i]." Uploaded 
							Successfully</p>";
						}
						else
						{
							echo "sorry! Unable to upload try
							again";
						}
					}
					else
					{
						echo "Please slect a Valid image";
					}
					
					
				}
				else
				{
					echo "Please select File";
				}
			}
		}
		
		
		?>
		
		<form method="POST" enctype="multipart/form-data">
			Select Files To Upload:
			<input multiple type="file" name="image[]">
			<br><br>
			<input type="submit" name="upload" 
			Value="Upload">
		</form>
	</body>
</html>