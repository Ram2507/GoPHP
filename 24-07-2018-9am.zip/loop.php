<?php 
/*$i=1;
do
{
	echo $i."<br>";
	$i++;
}
while($i<=10);
*/
/*initilization
do
{
	some statements
	incrementation
}
while(condition);
*/

$i=30;
while($i<=10)
{
	echo $i."<br>";
	$i=$i+3;
}




/*
for($i=2;$i<=20;$i++)
{
	for($j=2;$j<=$i;$j++)
	{
		if($i%$j==0)
		{
			break;
		}
	}
	if($j==$i)
	{
		echo $i."<br>";
	}
}
*/
// 0 1 1 2 3 5 8 13 21.......
/*$f1=0;
$f2=1;
echo $f1," ".$f2." ";
for($i=0;$i<=10;$i++)
{
	$f3=$f1+$f2;
	echo $f3." ";
	$f1=$f2;
	$f2=$f3;
}*/




// 2 and 20;

/*for($i=1;$i<=20;$i++)
{
	echo $i;
	break;
}*/

/*for($i=2;$i<=20;$i++)
{
	for($j=2;$j<=$i;$j++)
	{
		if($i%$j==0)
		{
			break;
		}
	}
	if($j==$i)
	{
		echo $i."<br>";
	}
}
*/
/*for($j=2;$j<=20;$j++)
{
	$table=$j;
	for($i=1;$i<=10;$i++)
	{
		ECho $table."*".$i."=".$table*$i;
		echo "<br>";
	}
	echo "<br>=================<br>";
}
*/

/*$table=99;
for($i=1;$i<=10;$i++)
{
	ECho $table."*".$i."=".$table*$i;
	echo "<br>";
}
*/


/*$x=5;
$n= $x-- + --$x;
echo $n;//8
*/

/*for($i=1;$i<=5;)
{
	
	echo $i;
	++$i;
}
*/







/*for($j=1;$j<=10;$j++)
{
	if($j%2==0)
	{
		echo $j;
		echo "<br>";
	}
}

for($i=2;$i<=10;$i=$i+2)
{
	echo $i."<br>";
}
*/


?>