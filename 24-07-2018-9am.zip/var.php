<?php 
//$x;
//echo $x;//notice Error

$x="bar";
$bar="welcome";




?>