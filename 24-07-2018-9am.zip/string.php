
	<!--<script>
	document.addEventListener("keyup",function(e){
		alert(e.key+" "+e.which);
	});	
	</script>
	-->

	<?php
	
	//echo stristr("Hello World rter ter ter tert ","D");
	//echo substr("Hello World",0,10);
	
	
	
	/*$pwd="ram@123";
	echo crc32($pwd);
	*/
	/*$pwd="ram@123";
	echo base64_encode($pwd);
	
	
	$pwd="cmFtQDEyMw==";
	echo base64_decode($pwd);
	*/
	
	/*
	$fp=fopen("html.txt","r");
	$data=fread($fp,filesize("html.txt"));
	echo html_entity_decode($data);*/
	
	
	
	/*$name="Ram's";
	echo addslashes($name);
	*/
	/*$str="<h1><P>Hello Worlds</P></h1>";
	$fp=fopen("html.txt","w");
	echo fwrite($fp,htmlspecialchars($str));
	*/
	
	
	
	
	/*$arr=array(10,20,30,40,array(100,200,300));
	$data=array();
	for($i=0;$i<count($arr);$i++)
	{
		if(is_array($arr[$i]))
		{
			for($k=0;$k<count($arr[$i]);$k++)
			{
				$data[]=$arr[$i][$k];
			}
		}
		else
		{
			$data[]=$arr[$i];
		}
		
	}
	print_r($data);
	print_r(@implode("#",$data));
*/
	/*$data="This program is free software; 
	you can redistribute it and/or 
	modify it under the terms of 
	the GNU General Public License 
	as published by the Free Software 
	Foundation; either version 2 of the 
	License, or (at your option) any 
	later version.";
	$d=explode("",$data);
	print_r(count($d));
	//echo str_word_count($data);
	*/

	//$str="10#20#30#40#50";
	//$data=explode("#",$str);
	//print_r($data);


	/*$data="This program is free software; 
	you can redistribute it and/or 
	modify it under the terms of 
	the GNU General Public License 
	as published by the Free Software 
	Foundation; either version 2 of the 
	License, or (at your option) any 
	later version.";*/
	//echo substr($data,100);
	//echo substr($data,0,50);
	//$email="rambabburi@gmail.com";
	//echo strpos($email,"M");//10
	//echo STRIPOS($email,"M");//10



	//$str="1234567890";
	//echo strrev($str);
	//echo str_shuffle($str);


	//$name="<h1 style='color:red'>Ram Babburi</h1>";
	//echo strip_tags($name);
	 
	//$str="ram babburi hello";

	//echo chr(97);
	//echo ord("");

	//echo ucwords($str);
	//echo ucfirst($str);

	//echo strtoupper($str);
	//echo strtolower($str);


	//echo strlen($str);



	/*$x=200+300;
	$str= <<<HTML
	<ul>
		<li><a href="">$x</a></li>
		<li><a href="">Home</a></li>
	</ul>
	HTML;
	echo $str
	*/
	?>