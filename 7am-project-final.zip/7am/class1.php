<?php 
class test
{
	function __destruct()
	{
		echo "<p>I am Destroy</p>";
	}
	function getusers()
	{
		echo "<p>I am users</p>";
	}
	function insertUser()
	{
		echo "<p>Insert Record</p>";
	}
	function __construct()
	{
		echo "<p>I am Default</p>";
	}
	
}
$obj=new test();

$obj->insertUser();
$obj->getusers();


