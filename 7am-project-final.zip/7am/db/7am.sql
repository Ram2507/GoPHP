-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 09, 2018 at 06:08 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `7am`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `msg` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `mobile`, `msg`) VALUES
(1, 'ram kumar', 'ram@mail.com', 1212121212, 'Hello How are you'),
(2, 'ravi kumar', 'ravi@mail.com', 2434233423, 'welcome to php'),
(3, 'naresh m', 'naresh@mail.com', 32482323423, 'Hello'),
(4, 'suresh', 'suresh@mail.com', 988568956, 'welcome'),
(5, 'koti', 'koti@mail.com', 2423423, 'werwe'),
(6, 'naresh@mail.com', 'naresh', 12312312, 'Hello'),
(7, 'hello', 'hello@mail.com', 231, 'adea'),
(8, 'ram', 'ram@mauil.com', 12312312, 'asd'),
(9, 'naresh', 'ram@mauil.com', 12312312, 'sad'),
(10, 'naresh', 'ram@mauil.com', 12312312, 'sad'),
(13, 'lakshmi', 'lakshmi@mail.com', 12312132, 'hello');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(32) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `state` varchar(50) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `city` varchar(50) NOT NULL,
  `terms` int(11) NOT NULL,
  `date_of_reg` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ip` varchar(30) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `profile_pic` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `username`, `email`, `password`, `gender`, `state`, `mobile`, `city`, `terms`, `date_of_reg`, `ip`, `status`, `profile_pic`) VALUES
(1, 'ram kumar', 'ram@mail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'Male', 'Telangana', '12312312', 'Hyderabad', 1, '2018-09-03 08:09:02', '::1', 1, 'luhgitwmjbapsorKoala.jpg'),
(2, 'naresh', 'naresh@mail.com', '202cb962ac59075b964b07152d234b70', 'Male', 'Andhrapradesh', '12312312', '', 1, '2018-09-03 08:21:13', '::1', 1, 'kcihmqvbjnoyepdDesert.jpg'),
(3, 'suresh', 'suresh@mail.com', '202cb962ac59075b964b07152d234b70', 'Male', 'Telangana', '0', '', 1, '2018-09-03 08:24:12', '::1', 0, ''),
(4, 'babburi', 'babburi@mail.com', '202cb962ac59075b964b07152d234b70', 'Male', 'Telangana', '0', '', 1, '2018-09-03 08:27:29', '::1', 0, ''),
(6, 'Ramu', 'rambabburi@gmail.com', '202cb962ac59075b964b07152d234b70', 'Male', 'Uttarapradesh', '0', '', 1, '2018-09-03 08:29:38', '::1', 1, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
