<?php 
if(isset($_REQUEST['id']))
{
	$id=$_REQUEST['id'];
}
else
{
	echo "Wrong Window go to 
	<a href=''>Home</a>";
}


?>