<html>
	<head>
		<title>Contact Here</title>
	</head>
	<body>
		<h1>Contact Here</h1>
		<form action="save.php" method="GET">
			Name:<br>
			<input type="text" name="uname">
			<br><br>
			Email:<br>
			<input type="text" name="email">
			
			<br><br>
			Mobile:<br>
			<input type="text" name="mobile">
			
			<br><br>
			Message:<br>
			<textarea name="msg"></textarea>
			
			<br><br>
			<input type="submit" value="Send">
		</form>
	</body>
</html>