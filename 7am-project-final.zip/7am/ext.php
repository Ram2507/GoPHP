
<?php 
$filename="hello.jpg";
$pos=stripos($filename,".");
echo substr($filename,$pos);

?>