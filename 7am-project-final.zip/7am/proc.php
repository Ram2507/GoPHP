<?php 
include("connect.php");
$res=mysqli_query($con,"call getUser(4)");
$row=mysqli_fetch_assoc($res);
print_r($row);
?>