<pre>
<?php 
//echo $_SERVER['SERVER_PROTOCOL'];
print_r($_SERVER);

?>