<html>
	<head>
		<title>Display All USers By Ram</title>
		  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	</head>
	<body>
		
		<div class="container">
		
			
		
		
			<h1>Display Users by Ram</h1>
			<?php 
			include("users.php");
			$obj=new Users();
			$obj->getAllUsers();
			if($obj->getAllUsers())
			{
				$data=$obj->getAllUsers();
				while($row=mysqli_fetch_assoc($data))
				{
					?>
		<div class="card bg-primary">
		  <h5 class="card-header"><?php echo $row['name']?></h5>
		  <div class="card-body">
			<p class="card-text">Email: <?php echo $row['email']?></p>
			<p class="card-text">Mobile: <?php echo $row['mobile']?></p>
			<p class="card-text">Message: <?php echo $row['msg']?></p>
		  </div>
		</div>
		<p></p>
					<?php
				}
			}
			else
			{
				echo "<p>No Records Found to Display</p>";
			}
			?>
			
			<h1>Latest Users</h1>
			<?php 
			if($obj->getLatestUser())
			{
				$data=$obj->getLatestUser();
				$row=mysqli_fetch_assoc($data);
				?>
					<div class="card bg-danger">
		  <h5 class="card-header"><?php echo $row['name']?></h5>
		  <div class="card-body">
			<p class="card-text">Email: <?php echo $row['email']?></p>
			<p class="card-text">Mobile: <?php echo $row['mobile']?></p>
			<p class="card-text">Message: <?php echo $row['msg']?></p>
		  </div>
		</div>
				<?php
			}
			else
			{
				echo "<p>No Records Founsd</p>";
			}
			?>
		</div>
	</body>
</html>