<html>
	<head>
		<title>View Employees</title>
	</head>
	<body>
		<h1>View Employees</h1>
		<a href="add_employee.php">Add Employee</a>
		<?php 
		if(isset($_COOKIE['success']))
		{
			echo "<p>".$_COOKIE['success']."</p>";
		}
		?>
		<?php 
		include("connect.php");//$con
		$result=mysqli_query($con,"select *from employee");
		if(mysqli_num_rows($result)>0)
		{
			?>
				<table border=1>
				<tr>
					<th>Emp Id</th>
					<th>Name</th>
					<th>Email</th>
					<th>Mobile</th>
					<th>City</th>
					<th>Salary</th>
					<th>Status</th>
					<th>DOJ</th>
					<th>Action</th>
				</tr>
				<?php 
				while($row=mysqli_fetch_assoc($result))
				{
					?>
					<tr>
						<td><?php echo $row['eid']; ?></td>
						<td><?php echo $row['name']; ?></td>
						<td><?php echo $row['email']; ?></td>
						<td><?php echo $row['mobile']; ?></td>
						<td><?php echo $row['city']; ?></td>
						<td><?php echo $row['salary']; ?></td>
						<td><?php echo $row['status']; ?></td>
						<td><?php echo $row['date']; ?></td>
						<td>
							<a href="edit_employee.php?eid=<?php echo $row['eid'];?>">Edit</a>
							<a onclick="deleteRecord(<?php echo $row['eid']?>)" href="javascript:void(0)">Delete</a>
						</td>
					</tr>
					<?php
				}
				?>
			</table>
			<?php
		}
		else
		{
			echo "<p>No Records Found</p>";
		}
		?>
		<script>
			function deleteRecord(id)
			{
				var c=confirm("do you want to delete?");
				if(c==true)
				{
					window.location="delete_employee.php?did="+id;
				}
			}
		</script>
	</body>
</html>