<h1>Welcome to php</h1>
<?php 
$n1=$_COOKIE['num1'];
$n2=$_COOKIE['num2'];
echo $n1,$n2
?>