<?php
//header("Location:home.php");

header("content-disposition:attachment;filename=video.wmv");
readfile("C:/Users/Public/Videos/Sample Videos/Wildlife.wmv");








