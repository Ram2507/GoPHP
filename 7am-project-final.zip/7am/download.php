<h1><a href="head.php">Download here
</a></h1>