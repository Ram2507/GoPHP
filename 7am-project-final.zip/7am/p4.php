<?php 
$n1=$_COOKIE['num1'];
$n2=$_COOKIE['num2'];
$n3=$_POST['p3'];
$sum=$n1+$n2+$n3;
echo "The Sum is:".$sum;


?>