<?php 
session_start();
$_SESSION['city']="Hyderabad";
$_SESSION['state']="TS";

?>
PHPSESSID
ni97kbt0klq33lqs600scj7ot6