<?php 
include("connect.php");
if(isset($_REQUEST['eid']))
{
	
	$id=$_REQUEST['eid'];
	$res=mysqli_query($con,"select *from employee where eid=$id");
	if(mysqli_num_rows($res)==1)
	{
		$row=mysqli_fetch_assoc($res);
	}
	else
	{
		exit("Sorry! Wromg Window");
	}
}
else
{
	exit("Sorry");
}
?>
<html>
	<head>
		<title>Edit Employee</title>
	</head>
	<body>
		<h1>Edit Employee</h1>
		<a href="add_employee.php">Add Employee</a>
		<a href="view_employees.php">View Employees</a>
		<br><br><br>
		
		<?php 
		if(isset($_POST['update']))
		{
			$name=$_POST['ename'];
			$email=$_POST['eemail'];
			$mobile=$_POST['emobile'];
			$city=$_POST['ecity'];
			$sal=$_POST['esalary'];
			mysqli_query($con,"update employee
			set name='$name',email='$email',
			mobile='$mobile',city='$city',
			salary='$sal' where eid=$id");
			if(mysqli_affected_rows($con)==1)
			{
				setcookie("success","Employee($id) Updated Successfully",time()+2);
				header("Location:view_employees.php");
			}
			else
			{
				echo "<p>Sorry! Unable to update. Try again</p>";
			}
		}
		?>
		
		<form method="POST" action="" onsubmit="return validate()">
			<table>
				<tr>
					<td>Employee Name</td>
					<td><input value="<?php echo $row['name'];?>" type="text" name="ename" id="ename"></td>
				</tr>
				<tr>
					<td>Mobile</td>
					<td><input value="<?php echo $row['mobile'];?>" type="text" name="emobile" id="emobile"></td>
				</tr>
				<tr>
					<td>Email</td>
					<td><input value="<?php echo $row['email'];?>" type="text" name="eemail" id="eemail"></td>
				</tr>
				<tr>
					<td>Salary</td>
					<td><input value="<?php echo $row['salary'];?>" type="text" name="esalary" id="esalary"></td>
				</tr>
				<tr>
					<td>City</td>
					<td><input value="<?php echo $row['city'];?>" type="text" name="ecity" id="ecity"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" name="update" value="Update"></td>
				</tr>
			</table>
		</form>
	</body>
</html>