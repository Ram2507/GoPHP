<pre><?php 
print_r($_REQUEST);
$name=$_REQUEST['uname'];
$e=$_REQUEST['email'];
//$mob=$_POST['mobile'];
//$msg=$_POST['msg'];


//if the form method is POST we have to 
//read the Data using $_POST[] variable





//print_r($_GET);
/*$name=$_GET['uname'];
$e=$_GET['email'];
$mob=$_GET['mobile'];
$msg=$_GET['msg'];*/
?>