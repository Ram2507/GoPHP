<P><a href="read.php?id=1">
News Title1</a></p>
<P><a href="read.php?id=2">
News Title2</a></p>
