<html>
	<head>
		<title>Display All USers</title>
	</head>
	<body>
		<h1>Display Users</h1>
		<?php include("users.php");
		$obj=new Users();
		if($obj->getAllUsers())
		{
			$data=$obj->getAllUsers();
			while($row=mysqli_fetch_assoc($data))
			{
				print_r($row);
				echo "<br>";
			}
		}
		else
		{
			echo "<p>No Records</p>";
		}
		
		?>
		<h1>Latest Users Information</h1>
		<?php 
		if($obj->getLatestUser())
		{
			$data=$obj->getLatestUser();
			$row=mysqli_fetch_assoc($data);
			print_r($row);
		}
		else
		{
			echo "<p>No recorss Found</p>";
		}
		?>
	</body>
</html>