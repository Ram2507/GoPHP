<?php
$str="Ram Teaching java and java is good";
echo str_ireplace("JaVa","php",$str);
//echo str_replace("Java","php",$str);
//echo strrev($pwd);

//echo base64_encode($pwd);

//echo base64_decode("cmFtYmFiYnVyaQ==");


//echo crc32($pwd);
//echo sha1($pwd);
//echo md5($pwd);


/*$pwd="1234567890".time();
$x=str_shuffle($pwd);
echo substr($x,6,6);
*/
/*$str="Welcome to php welcome to hyd";
echo substr($str,0,10);
echo substr($str,15);*/
//echo strpos($str,"@");
//echo stripos($str,"COM");//17


/*$name="ram php training";
echo str_shuffle($name);
*/

/*$str=array(10,20,30,40,50);
echo implode("#",$str);
*/



/*$name="Ram's";
echo stripslashes("Ram\'s");//Ram's
*/


 ?>

