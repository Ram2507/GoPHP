<?php 
class Users
{
	public $con;
	function __construct()
	{
		$this->con=mysqli_connect("localhost","root","","7am");
	}
	function __destruct()
	{
		mysqli_close($this->con);
	}
	function getAllUsers()
	{
		
		$result=mysqli_query($this->con,"select *from contact");
		if(mysqli_num_rows($result)>0)
		{
			return $result;
		}
		else
		{
			return false;
		}
	}
	//get latest users
	function getLatestUser()
	{
		
		$result=mysqli_query($this->con,"select *from contact order by id desc limit 1");
		if(mysqli_num_rows($result)>0)
		{
			return $result;
		}
		else
		{
			return false;
		}
	}
}

?>