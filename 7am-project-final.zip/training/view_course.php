<style>
.vmenu{
	margin:0px;padding:0px;
}
.vmenu li{
	list-style-type:none;
	margin:8px 0px 8px 0px;
	padding:0px 0px 4px 0px;
	border-bottom:1px solid #d4d4d4;
}
.vmenu li a{
	text-decoration:none;
}
.vmenu li:hover{
	background-color:#efefef;
}
</style>
<?php 
session_start();
include("header.php");
include("connect.php");
if(isset($_REQUEST['cid']))
{
	$id=$_REQUEST['cid'];
	$result=mysqli_query($con,"select *from courses where cid=$id and status='Active'");
	if(mysqli_num_rows($result)>0)
	{
		$row=mysqli_fetch_assoc($result);
	}
	else
	{
		exit("Sorry!");
	}
}

?>
	<div class='container'>
		<h1 class="mt-4 mb-3"><?php echo $row['title']?></h1>
		<ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.php">Home</a>
        </li>
        <li class="breadcrumb-item active"><?php echo $row['title']?></li>
      </ol>
	  <div class="row">
		<div class="col-lg-9">
			<div class="row">
				<div class="col-lg-6">
				<img src="admin/courses/<?php echo $row['filename']?>">
				</div>
				<div class="col-lg-3">
					<p><b>Faculty Name</b>:<?php echo $row['faculty_name']?></p>
					<p><b>Start Date:</b><?php echo $row['start_date']?></p>
					<p><b>Timimng:</b><?php echo $row['timing']?></p>
				</div>
			</div>
			<p><?php echo $row['description'];?></p>
		</div>
		<div class="col-lg-3">
			<h3>Related Courses</h3>
			<?php 
			$links=mysqli_query($con,"select title,cid from courses where cid!=$id and status='Active' order by cid desc");
			if(mysqli_num_rows($links))
			{
				echo "<ul class='vmenu'>";
				while($lrow=mysqli_fetch_assoc($links))
				{
					?>
						<li><a href="view_course.php?cid=<?php echo $lrow['cid'] ?>"><?php echo $lrow['title'];?></a></li>
					<?php
				}
				echo "</ul>";
			}
			else
			{
				echo "<p>Sorry! No courses found</p>";
			}
			?>
			
			<h3>Latest Courses</h3>
			<ul class='vmenu'>
				<li><a href="">Link1</a></li>
				<li><a href="">Link1</a></li>
				<li><a href="">Link1</a></li>
				<li><a href="">Link1</a></li>
				<li><a href="">Link1</a></li>
			</ul>
		</div>
	</div>
	<div class="row">
		
	</div>
	</div>
<?php
include("footer.php");
?>