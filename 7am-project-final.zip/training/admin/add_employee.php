<?php
session_start();
if(isset($_SESSION['adminlogin']))
{

	include("../connect.php");
	include("header.php");
?>
	<div id="page-wrapper">
		<h2>Add Employee</h2>
		
		<?php 
		if(isset($_COOKIE['success']))
		{
			echo "<p>".$_COOKIE['success']."</p>";
		}
		
		if(isset($_POST['add']))
		{
			$name=mysqli_real_escape_string($con,$_POST['ename']);
			$email=$_POST['eemail'];
			$mobile=$_POST['emobile'];
			$city=$_POST['ecity'];
			$sal=$_POST['esalary'];
			mysqli_query($con,"insert into
			employee(name,email,mobile,city,
			salary) values('$name','$email',
			'$mobile','$city','$sal')");
			if(mysqli_affected_rows($con)==1)
			{
				setcookie("success","Employee added successfully",time()+2);
				header("Location:add_employee.php");
			}
			else
			{
				echo "<p>Sorry! Unable to Insert try again</p>";
			}
		}
		?>
		
		<form method="POST" action="" onsubmit="return validate()">
			<table class='table'>
				<tr>
					<td>Employee Name</td>
					<td><input class='form-control' type="text" name="ename" id="ename"></td>
				</tr>
				<tr>
					<td>Mobile</td>
					<td><input class='form-control' type="text" name="emobile" id="emobile"></td>
				</tr>
				<tr>
					<td>Email</td>
					<td><input class='form-control' type="text" name="eemail" id="eemail"></td>
				</tr>
				<tr>
					<td>Salary</td>
					<td><input class='form-control' type="text" name="esalary" id="esalary"></td>
				</tr>
				<tr>
					<td>City</td>
					<td><input class='form-control' type="text" name="ecity" id="ecity"></td>
				</tr>
				<tr>
					<td></td>
					<td><input class='btn btn-primary' type="submit" name="add" value="Save"></td>
				</tr>
			</table>
		</form>
		<script>
			function validate()
			{
				if(document.getElementById("ename").value=="")
				{
					alert("Enter Employee Name");
					return false;
				}
				//email validation
				if(document.getElementById("eemail").value=="")
				{
					alert("Enter Email");
					return false
				}
				else
				{
					var email=document.getElementById("eemail").value;
					var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
					if(!re.test(email))
					{
						alert("please enter valid email");
						return false;
					}
				}
				//Mobile Validation
				if(document.getElementById("emobile").value=="")
				{
					alert("Enter Mobile");
					return false;
				}
				else
				{
					var IndNum = /^[0]?[789]\d{9}$/;
					var mob=document.getElementById("emobile").value;
					if(!IndNum.test(mob))
					{
						alert("Enter valid 10 digit mobile number");
						return false;
					}
				}
			}
		</script>
	</div>
	<?php
	include("footer.php");
}
else
{
	header("Location:index.php");
}
?>