<?php session_start();
if(isset($_SESSION['adminlogin']))
{
	include("../connect.php");
	include("header.php");
	?>
	<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
		<div id="page-wrapper">
			<h2>Add Course</h2>
			<?php 
			if(isset($_REQUEST['status']))
			{
				echo "<p class='alert alert-success'>Course Addedd Successfully</p>";
			}
			?>
			<?php 
			if(isset($_POST['add']))
			{
				//3.collecting form data
				$title=$_POST['ctitle'];
				$desc=$_POST['cdesc'];
				$rating=$_POST['crating'];
				$fname=$_POST['fname'];
				$timing=$_POST['timings'];
				$sdate=$_POST['sdate'];
				if(is_uploaded_file($_FILES['cimage']['tmp_name']))
				{
					$filename=$_FILES['cimage']['name'];
					$tpath=$_FILES['cimage']['tmp_name'];
					move_uploaded_file($tpath,"courses/$filename");
				}
				else
				{
					$filename="";
				}
				//insert data into tables
				mysqli_query($con,"insert into courses(title,
				description,filename,start_date,timing,rating,
				faculty_name) values('$title','$desc',
				'$filename','$sdate','$timing',$rating,'$fname')");
				if(mysqli_affected_rows($con)==1)
				{
					//setcookie("success","Course added successfully",time()+2);
					//header("Location:add_course.php");
					?>
						<script>
							window.location="add_course.php?status=true";
						</script>
					<?php
				}
			}
			?>
			
			<form onsubmit="return courseValidate()" method="POST" action="" enctype="multipart/form-data">
				<div class='form-group'>
					<label>Course Title</label>
					<input class='form-control' onblur="checkvalue(this)" type="text" name="ctitle" id="ctitle">
				</div>
				<div class='form-group'>
					<label>Course Description</label>
					<textarea class='form-control' name="cdesc" id="cdesc"></textarea>
				</div>
				<div class='form-group'>
					<label>Course Image</label>
					<input class='form-control' type="file" name="cimage" id="cimage">
				</div>
				<div class='form-group'>
					<label>Course Rating</label>
					<input class='form-control' type="number" name="crating" id="crating" max="5" min="1">
				</div>
				<div class='form-group'>
					<label>Faculty Name</label>
					<input class='form-control' type="text" name="fname" id="fname">
				</div>
				<div class='form-group'>
					<label>Start Date</label>
					<input class='form-control' type="text" name="sdate" id="sdate">
				</div>
				<div class='form-group'>
					<label>Timings</label>
					<input class='form-control' placeholder="Example:9am-11am" type="text" name="timings" id="timings">
				</div>
				<div class='form-group'>
					
					<input class='btn btn-success' type="submit" name="add" value="Add Course">
				</div>
			</form>
		</div>
		<script>
			function courseValidate()
			{
				if($("#ctitle").val()=="")
				{
					$("#ctitle").css("border","1px solid red");
					$("#ctitle").focus();
					return false;
				}
			}
			function checkvalue(e)
			{
				if(e.value!="")
				{
					$("#ctitle").css("border","1px solid #999");
				}
			}
		</script>
		
	<?php
	include("footer.php");
}
else
{
	//header("Location:index.php");
	?>
		<script>
			window.location="index.php";
		</script>
	<?php
}
?>
<script>
		  $( function() {
			$( "#sdate" ).datepicker({
				dateFormat: "yy-mm-dd",
				maxDate: "+2m",
				minDate: "0",
			});
		  } );
	  </script>