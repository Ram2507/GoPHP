<style>
.checked {
    color: orange;
}
</style>
<?php session_start();
if(isset($_SESSION['adminlogin']))
{
	include("../connect.php");
	include("header.php");
	
	$courses=mysqli_query($con,"select *from courses order by cid desc");
	
	?>
		<div id="page-wrapper">
			<h2>View Courses</h2>
			<?php 
			if(isset($_COOKIE['success']))
			{
				echo "<p class='alert alert-success'>".$_COOKIE['success']."</p>";
			}
			if(mysqli_num_rows($courses)>0)
			{
				?>
					<table class='table'>
				<tr>
					<th>Id</th>
					<th>Title</th>
					
					<th>Image</th>
					<th>Faculty Name</th>
					<th>Start Date</th>
					<th>Timing</th>
					<th>Rating</th>
					<th>Status</th>
					<th>Action</th>
				</tr>
				<?php 
				while($row=mysqli_fetch_assoc($courses))
				{
					?>
						<tr>
							<td><?php echo $row['cid']?></td>
							<td><?php echo $row['title']?></td>
							
							<td><img src="courses/<?php echo $row['filename']?>" height="50" width="50"></td>
							<td><?php echo $row['faculty_name']?></td>
							<td><?php echo $row['start_date']?></td>
							<td><?php echo $row['timing']?></td>
							<td>
								<?php displayRating($row['rating'])?>
							</td>
							<td><?php echo $row['status']?></td>
							<td>
								<a href="edit_course.php?cid=<?php echo $row['cid']?>"><i class='fa fa-pencil'></i></a>
								<a onclick="deleteRecord(<?php echo $row['cid']?>)" href="javascript:void(0)"><i class='fa fa-trash text-danger' ></i></a>
								<?php 
								if($row['status']=="Active")
								{
									?>
										<a href="course_status.php?cid=<?php echo $row['cid']?>"><i class="fa fa-eye-slash"></i></a>
									<?php
								}
								else
								{
									?>
										<a href="course_status.php?cid=<?php echo $row['cid']?>"><i class="fa fa-eye text-warning"></i></a>
									<?php
								}
								?>
								
								
							</td>
						</tr>
					<?php
				}
				?>
			</table>
				<?php
			}
			else
			{
				echo "<p>Sorry! No records found. please add a course <a href='add_course.php'>Add Now</a></p>";
			}
			?>
		</div>
	<?php
	include("footer.php");
}
else
{
	header("Location:index.php");
}

function displayRating($id)
{
	echo $id;
	for($i=0;$i<5;$i++)
	{
		
		if($i>=$id)
		{
			$class="";
		}
		else
		{
			$class="checked";
		}
		?>
			<i class='fa fa-star <?php echo $class;?>'></i>
		<?php
	}
	
}

 ?>
 <script>
 function deleteRecord(id)
 {
	 var c=confirm("Do you want to Delete");
	 if(c==true)
	 {
		 window.location="delete_course.php?cid="+id;
	 }
 }
 </script>