<?php 
session_start();
if(isset($_SESSION['adminlogin']))
{
	include("../connect.php");
	$id=$_REQUEST['cid'];
	$result=mysqli_query($con,"select status from courses where cid=$id");
	if(mysqli_num_rows($result)==1)
	{
		$row=mysqli_fetch_assoc($result);
		if($row['status']=="Active")
		{
			mysqli_query($con,"update courses set status='InActive' where cid=$id");
		}
		else
		{
			mysqli_query($con,"update courses set status='Active' where cid=$id");
		}
		if(mysqli_affected_rows($con)>0)
		{
			setcookie("success","Status updated successfully",time()+2);
			header("Location:view_courses.php");
		}
	}
	else
	{
		exit("Wrong Window");
	}
}
else
{
	header("Location:index.php");
}
?>