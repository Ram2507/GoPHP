<?php 
session_start();
if(isset($_SESSION['adminlogin']))
{
	include("../connect.php");
	$id=$_REQUEST['cid'];
	mysqli_query($con,"delete from courses where cid=$id");
	
	if(mysqli_affected_rows($con)>0)
	{
		setcookie("success","Course Deleted successfully",time()+2);
		header("Location:view_courses.php");
	}
	
}
else
{
	header("Location:index.php");
}
?>