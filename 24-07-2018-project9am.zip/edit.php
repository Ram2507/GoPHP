<?php 
session_start();
if(isset($_SESSION['login_true']))
{
	$logid=$_SESSION['login_true'];
	include("connect.php");
	$result=mysqli_query($con,"select id,username,mobile,state,city 
	from register where id=$logid");
	$row=mysqli_fetch_assoc($result);
	
	include("header.php");
	?>
		<div class='container'>
			<h1 class='my-4'>Edit Profile</h1>
			<?php 
				if(isset($_COOKIE['success']))
				{
					echo $_COOKIE['success'];
				}
			?>
			<?php 
			if(isset($_POST['edit']))
			{
				$name=$_POST['uname'];
				$mobile=$_POST['mobile'];
				$city=$_POST['city'];
				$state=$_POST['state'];
				mysqli_query($con,"update register set
				username='$name',
				mobile='$mobile',
				city='$city',
				state='$state' where id=$logid");
				if(mysqli_affected_rows($con)==1)
				{
					setcookie("success","<p class='alert alert-success'>Profile Updated Successfully</p>",time()+2);
					header("location:edit.phpss");
				}
				else
				{
					echo "Sorry! Unable to Update. Try again";
				}
			}
			?>
			
			<div class="row">
				<div class='col-lg-3 mb-4'>
					<?php 
						include("sidemenu.php");
					?>
				</div>
				<div class='col-lg-9 mb-4'>
					
					<form method="POST" action="">
						<div class="form-group">
							<label>Username</label>
							<input type="text" name="uname" class="form-control" value="<?php echo $row['username'];?>">
						</div>
						<div class="form-group">
							<label>Mobile</label>
							<input type="text" name="mobile" class="form-control" value="<?php echo $row['mobile'];?>">
						</div>
						<div class="form-group">
							<label>City</label>
							<input type="text" name="city" class="form-control" value="<?php echo $row['city'];?>">
						</div>
						<div class="form-group">
							<label>State</label>
							<select name="state" class="form-control">
								<option value="">--Select State--</option>
								<option value="Andhrapradesh" <?php if($row['state']=="Andhrapradesh") echo "selected"?>>Andhrapradesh</option>
								<option value="Telangana" <?php if($row['state']=="Telangana") echo "selected"?>>Telangana</option>
								<option value="Maharastra" <?php if($row['state']=="Maharastra") echo "selected"?>>Maharastra</option>
								<option value="Uttarapradesh" <?php if($row['state']=="Uttarapradesh") echo "selected"?>>Uttarapradesh</option>
							</select>
						</div>
						<div class="form-group">
							<input type="submit" name="edit" class="btn btn-primary" value="Update">
						</div>
					</form>
				</div>
			</div>
		</div>
	<?php
	include("footer.php");
}
else
{
	header("Location:login.php");
}
?>