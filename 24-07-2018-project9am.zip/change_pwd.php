<?php 
session_start();
if(isset($_SESSION['login_true']))
{
	$logid=$_SESSION['login_true'];
	include("connect.php");
	$result=mysqli_query($con,"select id,password from register where id=$logid");
	$row=mysqli_fetch_assoc($result);
	include("header.php");
	?>
		<div class="container">
			<h1 class='my-4'>Change Password</h1>
			<?php 
			if(isset($_POST['update']))
			{
				$opwd=md5($_POST['opwd']);
				$npwd=md5($_POST['npwd']);
				$cnpwd=md5($_POST['cnpwd']);
				if($npwd==$cnpwd)
				{
					if($opwd==$row['password'])
					{
						mysqli_query($con,"update register set password='$npwd' where id=$logid");
						if(mysqli_affected_rows($con)>0)
						{
							echo "<p class='alert alert-success'>Password Chnaged successfully</p>";
						}
					}
					else
					{
						echo "<p class='alert alert-danger'>Old Password is wrong</p>";
					}
				}
				else
				{
					echo "<p class='alert alert-danger'>Passwords does not match</p>";
				}
			}
			?>
			
			<div class="row">
				<div class='col-lg-3 mb-4'>
					<?php include("sidemenu.php");?>
				</div>
				<div class='col-lg-9 mb-4'>
					<form action="" method="POST">
						<div class='form-group'>
						<label>Enter Old Password</label>
						<input type="password" name="opwd" class='form-control'>
					</div>
					<div class='form-group'>
						<label>Enter New Password</label>
						<input type="password" name="npwd" class='form-control'>
					</div>
					<div class='form-group'>
						<label>Confirm New Password</label>
						<input type="password" name="cnpwd" class='form-control'>
					</div>
					<div class='form-group'>
						<input type="submit" name="update" class='btn btn-primary' value="Update">
					</div>
					</form>
				</div>
			</div>
		</div>
	<?php
	include("footer.php");
}
else
{
	header("Location:login.php");
}
?>