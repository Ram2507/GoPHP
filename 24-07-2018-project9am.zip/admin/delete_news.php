<?php 
session_start();
if(isset($_SESSION['admin_login_true']))
{
	if(isset($_REQUEST['did']))
	{
		$did=$_REQUEST['did'];
		include("../connect.php");
		mysqli_query($con,"delete from news where id=$did");
		if(mysqli_affected_rows($con)>0)
		{
			setcookie("success","Deleted Successfully",time()+2);
			header("Location:view_news.php");
		}
		else
		{
			echo "Sorry! Unable to Delete. Try Again";
		}
	}
}
else
{
	header("Location:index.php");
}
?>