<?php 
session_start();
if(isset($_SESSION['admin_login_true']))
{
	include("../connect.php");
	
	include("admin_header.php");
	
	?>
		<div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="#">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">View News</li>
      </ol>
      <!-- Icon Cards-->
      <div class="row">
        
       <div class="col-md-12">
			<h1>View News</h1>
			<?php 
			if(isset($_COOKIE['success']))
			{
				echo "<p class='alert alert-success'>".$_COOKIE['success']."</p>";
			}
			?>
			
			<?php
				$result=mysqli_query($con,"select *from news");
				if(mysqli_num_rows($result)>0)
				{
			?>
			<table class="table">
					<tr>
						<th>ID</th>
						<th>Category</th>
						<th>Title</th>
						<th>Description</th>
						<th>Image</th>
						<th>Posted date</th>
						<th>Status</th>
						<th>Action</th>
						
					</tr>
					<?php 
					while($row=mysqli_fetch_assoc($result))
					{
						?>
							<tr>
								<td><?php echo $row['id']?></td>
								<td><?php echo $row['category']?></td>
								<td><?php echo $row['title']?></td>
								<td><?php echo substr($row['description'],0,100)?></td>
								<td><img src="news/<?php echo $row['image']?>" height="50" width="50"></td>
								<td><?php echo $row['posted_date']?></td>
								<td><?php echo $row['status']?></td>
								<td>
									<a href="edit_news.php?nid=<?php echo $row['id']?>"><i class='fa fa-pencil'></i></a>
									<a href="javascript:void(0)" onclick="deleteRecord(<?php echo $row['id'];?>)"><i class='fa fa-trash text-danger'></i></a>
									<!--<a href="" title='visible'><i class='fa fa-eye text-success'></i></a>-->
								</td>
							</tr>
						<?php
					}
					?>
			</table>
			<?php 
				}
				else
				{
					echo "<p class='alert alert-info'>No Artciles Found.Please <a href='add_news.php'>Add Now</a></p>";
				}
			?>
        </div>
        
        
        
      </div>
      <!-- Area Chart Example-->
      
      
      <!-- Example DataTables Card-->
      
    </div>
	<script>
		function deleteRecord(id)
		{
			var x=confirm("Do You want to Delete");
			if(x==true)
			{
				window.location="delete_news.php?did="+id;
			}
		}
	</script>
	<?php
	include("admin_footer.php");
}
else
{
	header("Location:index.php");
}
?>