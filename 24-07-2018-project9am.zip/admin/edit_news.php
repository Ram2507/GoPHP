<?php session_start();
if(isset($_SESSION['admin_login_true']))
{
	include("../connect.php");
	if(isset($_REQUEST['nid']))
	{
		$nid=$_REQUEST['nid'];
		$nresult=mysqli_query($con,"select *from news where id=$nid");
		$row=mysqli_fetch_assoc($nresult);
	}
	include("admin_header.php");
	?>
	<div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="#">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Edit News</li>
      </ol>
      <!-- Icon Cards-->
      <div class="row">
        
        <div class="col-md-9">
			<h1>Edit News</h1>
			
			<?php 
			if(isset($_REQUEST['status']))
			{
				echo "<p class='alert alert-success'>Updated Successfully</p>";
			}
			?>
			
			<?php 
			if(isset($_POST['update']))
			{
				$title=$_POST['title'];
				$desc=$_POST['desc'];
				$cat=$_POST['cat'];
				if(is_uploaded_file($_FILES['image']['tmp_name']))
				{
					$filename=$_FILES['image']['name'];
					$tmp=$_FILES['image']['tmp_name'];
					move_uploaded_file($tmp,"news/$filename");
				}
				else
				{
					$filename=$row['image'];
				}
				mysqli_query($con,"update news
				set title='$title',
				description='$desc',
				category='$cat',
				image='$filename' where id=$nid");
				if(mysqli_affected_rows($con)>0)
				{
					?>
						<script>
							window.location="edit_news.php?nid=<?php echo $nid?>&status=true";
						</script>
					<?php
				}
			}
			?>
			
			<form method="post" action="" enctype="multipart/form-data" onsubmit="return NewsValidate()">
					<div class='form-group'>
						<label>Category</label>
						<select name="cat" class="form-control" id="cat">
							<option value="">--select category--</option>
							<option <?php if($row['category']=="Movies") echo "selected"?> value="Movies">Movies</option>
							<option <?php if($row['category']=="Politics") echo "selected"?> value="Politics">Politics</option>
							<option <?php if($row['category']=="Sports") echo "selected"?> value="Sports">Sports</option>
						</select>
					</div>
					<div class='form-group'>
						<label>News Title</label>
						<input value="<?php echo $row['title']?>" type="text" name="title" id="title" class='form-control'>
					</div>
					<div class='form-group'>
						<label>News Description</label>
						<textarea name="desc" id="desc" class='form-control'><?php echo $row['description']?></textarea>
					</div>
					<div class='form-group'>
						<label>Upload news image</label>
						<input type="file" name="image"  class='form-control'>
						<?php 
						if($row['image']!="")
						{
							?>
								<img src="news/<?php echo $row['image']?>" height="50" width="50">
							<?php
						}
						?>
					</div>
					<div class='form-group'>
						<input type="submit" name="update" value="Update News" class='btn btn-primary'>
					</div>
				</form>	
        </div>
        
      </div>
      <!-- Area Chart Example-->
      
      
      <!-- Example DataTables Card-->
      
    </div>	
	<?php
	include("admin_footer.php");
}
else
{
	header("Location:index.php");
}
?>