<?php session_start();
if(isset($_SESSION['admin_login_true']))
{
	include("../connect.php");
	include("admin_header.php");
	?>
		<div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="#">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Users</li>
      </ol>
      <?php 
	  $result=mysqli_query($con,"select *from register");
	  ?>
      <div class="row">
        <div class="col-xl-9 mb-3">
			<h1>Users</h1>
			<?php 
			if(mysqli_num_rows($result)>0)
			{
				?>
					<table class="table">
						<tr>
							<th>ID</th>
							<th>Username</th>
							<th>Email</th>
							<th>City</th>
							<th>State</th>
							<th>IP</th>
							<th>Date of Reg.</th>
							<th>Status</th>
						</tr>
						<?php 
						while($row=mysqli_fetch_assoc($result))
						{
							?>
								<tr>
									<td><?php echo $row['id']?></td>
									<td><?php echo $row['username']?></td>
									<td><?php echo $row['email']?></td>
									<td><?php echo $row['city']?></td>
									<td><?php echo $row['state']?></td>
									<td><?php echo $row['ip']?></td>
									<td><?php echo $row['date_of_reg']?></td>
									<td><?php echo $row['status']?></td>
									
								</tr>
							<?php
						}
						?>
				</table>
				<?php
			}
			else
			{
				echo "<P class='alert alert-info'>No Users Found</p>";
			}
			?>
        </div>        
      </div>
      <!-- Area Chart Example-->
      
      
      <!-- Example DataTables Card-->
      
    </div>
	<?php
	include("admin_footer.php");
}
else
{
	header("Location:index.php");
}
?>