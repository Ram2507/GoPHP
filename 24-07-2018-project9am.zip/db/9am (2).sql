-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 24, 2018 at 07:16 AM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 7.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `9am`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `email`, `password`, `status`) VALUES
(1, 'admin', 'admin@mail.com', '202cb962ac59075b964b07152d234b70', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `category` varchar(250) NOT NULL,
  `title` varchar(250) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(250) NOT NULL,
  `posted_date` datetime NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `category`, `title`, `description`, `image`, `posted_date`, `status`) VALUES
(4, 'Sports', 'Ashwin to return to county after Tests', 'India off-spinner R. Ashwin has signed up for Worcestershire and will stay back in England after the Test series to take part in the final two rounds of the County Championship.\r\n\r\nAshwin has joined Worcestershire for the final two Specsavers County Championship matches against Essex at Chelmsford and Yorkshire at Blackfinch New Road.\r\n\r\nAccording to a statement issued by Worcestershire, the 31-year-old, who has had a stint in Worcestershire, will replace Wayne Parnell as the countyâ€™s overseas player.\r\n\r\nAshwin made a massive impact on and off the field after being signed for the final four Championship matches last summer, helping the county to gain promotion to Division One.', 'TH24ASH.jpg', '2018-07-24 10:15:16', 1),
(5, 'Sports', 'Chandra was devastating and tremendous: G.R. Viswanath', 'India travelled to England in the summer of 1971 on the back of a poor record in the country. It had never won a Test match there, and had lost 15 of 19.\r\n\r\nAjit Wadekarâ€™s side, though, was a confident one, having earlier that year achieved a historic series victory in the West Indies. The first two Tests, at Lordâ€™s and Old Trafford, were drawn. In the third Test at the Oval, the visitor was behind on first innings when B.S. Chandrasekhar produced a spell for the ages. The leg-spinnerâ€™s six for 38 set up Indiaâ€™s maiden Test match â€” and series â€” victory in England.', 'TH24CHANDRA.jpg', '2018-07-24 10:16:10', 1),
(6, 'Sports', 'Sri Lanka on their way to a massive win against South Africa', 'Sri Lanka closed in on a series whitewash against South Africa on Sunday, leaving the visitors five down and with a mountain to climb after the third day of the second Test.\r\n\r\nBy stumps the spinners had ripped their way through the South African batsmen yet again to leave them reeling on 139 for five in pursuit of an impossible-looking 490 victory target in Colombo.\r\n\r\nAgainst batsmen who clearly decided that attack was the best form of defence, off-spinner Akila Dananjaya and left-arm spinner Rangana Herath took two wickets apiece, with off-spinner Dilruwan Perera dismissing Dean Elgar.', 'TH23LANKA.jpg', '2018-07-24 10:17:06', 1),
(7, 'Politics', 'India extends $200 million credit lines to Rwanda; Modi holds talks with Kagame', 'After the one-on-one talks with President Kagame, Mr. Modi, the first Indian Prime Minister to visit the East African country, announced that India will soon open its mission in Rwanda.\r\n\r\nWe are going to open a High Commission in Rwanda. This will not only establish communication between our respective governments but also enable facilities for consular, passport, visa, Mr. Modi said at a joint press statement.\r\n\r\nHe noted that India and Rwanda relationships have stood the test of time.\r\n\r\nIt is a matter of honour for us that India has stood with Rwanda in their economic development journey, Mr. Modi said, adding that India will be continue to back Rwandaâ€™s development.\r\n\r\nThe two countries signed agreements on leather and allied areas and agricultural research.', 'VBK-MODI-PTI-1.jpg', '2018-07-24 10:18:16', 1),
(8, 'Politics', 'Venkaiah irate over TDP disruption', 'to all the members of the Telugu Desam Party and the YSR Congress to go to their respective places, cooperate and help the House function so that the people get justice. This is not the way. I have admitted the motion. The government is ready for a discussion. If you make noise, the voice of members who are raising questions is not heard. Live telecast is not there, why are you wasting your energy?â€ Rajya Sabha Chairman M. Venkaiah Naidu said.\r\n\r\nThe TDP had earlier in the day forced a pre-noon adjournment of proceedings. Party members were up on their feet as soon as listed papers were laid on the table of the House.\r\n\r\nMr. Naidu said their notice has been converted into a short-duration discussion which would be taken up on Tuesday.', '24THSIVAPRASADTDP.jpg', '2018-07-24 10:19:36', 1),
(9, 'Politics', 'Chinese leaders order probe over vaccine scandal', 'Chinese leaders are scrambling to shore up public confidence and oversight of the pharmaceutical industry after a rabies vaccine maker was found faking records, the latest in a slew of public health and safety scandals that have outraged Chinese parents.\r\n\r\nPremier Li Keqiang said in a statement on Sunday that Changchun Changsheng Life Sciences Ltd., which is accused of fabricating production and inspection records, â€œviolated a moral bottom line.â€ He pledged an immediate investigation of the company and to â€œresolutely crack downâ€ on violations that endanger public safety.', 'CHINAVACCINESCANDAL.jpg', '2018-07-24 10:20:18', 1),
(10, 'Sports', 'Ex-cricketers bat for â€˜skipper Imranâ€™', 'â€œYou have got what it takes Skipper @ImranKhanPTI but it will take everything you have... No one can doubt your Honesty and thatâ€™s what is require in our country... An honest LEADER,â€ tweeted former captain Waqar Younis.\r\n\r\n#BehindYouSkipper became one of the countryâ€™s top trending hashtags as celebrities and former cricketers came to Mr. Khanâ€™s support. Former Australian star Dean Jones also lent his support. â€œI am not a political person... but @ImranKhanPTI I would have loved to play under.... great leader and would do well for Pakistan if given the opportunity,â€ he tweeted.\r\n\r\nMr. Khanâ€™s chances of becoming Prime Minister are believed to be his best since entering politics two decades ago. But critics allege the electoral playing field is being fixed for him by the military.', 'TH23-PAKISTAN-IMRANSSUPPORTERS.jpg', '2018-07-24 10:38:34', 1);

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(32) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `dob` date NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `terms` int(11) NOT NULL,
  `date_of_reg` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ip` varchar(30) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Inactive',
  `profile_pic` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `username`, `email`, `password`, `mobile`, `gender`, `dob`, `city`, `state`, `terms`, `date_of_reg`, `ip`, `status`, `profile_pic`) VALUES
(1, 'ram', 'ram@mail.com', '202cb962ac59075b964b07152d234b70', 1212121212, 'Male', '0000-00-00', 'Hyderabad', 'Telangana', 1, '2018-07-17 09:42:01', '::1', 'Inactive', ''),
(2, 'naresh', 'naresh@mail.com', '202cb962ac59075b964b07152d234b70', 7897897894, 'Male', '1987-12-12', 'Hyderabad', 'Telangana', 1, '2018-07-17 09:48:51', '::1', 'Active', 'Jellyfish.jpg'),
(3, 'suresh', 'suresh@mail.com', '827ccb0eea8a706c4c34a16891f84e7b', 1212121212, 'Male', '1970-01-01', 'Hyderabad', 'Telangana', 1, '2018-07-17 10:03:21', '::1', 'Inactive', ''),
(4, 'Ravi Kumar', 'ravi@mail.com', 'e10adc3949ba59abbe56e057f20f883e', 98857767740, 'Male', '1987-12-12', 'Pune', 'Uttarapradesh', 1, '2018-07-17 10:08:20', '::1', 'Active', 'Lighthouse.jpg'),
(5, '', '', 'd41d8cd98f00b204e9800998ecf8427e', 0, '', '1970-01-01', '', '', 0, '2018-07-19 10:13:12', '::1', 'Inactive', ''),
(6, 'ram', 'rambabburi123@gmail.com', '202cb962ac59075b964b07152d234b70', 1212121212, 'Male', '1987-12-12', 'Hyderabad', 'Maharastra', 1, '2018-07-19 10:14:42', '::1', 'Inactive', ''),
(7, 'test', 'test@mail.com', '202cb962ac59075b964b07152d234b70', 1212121212, 'Male', '1987-12-12', 'Hyderabad', 'Telangana', 1, '2018-07-24 07:53:35', '::1', 'Inactive', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
