<?php 
include("connect.php");
include("header.php");

if(isset($_REQUEST['key']))
{
	$key=base64_decode($_REQUEST['key']);
	
}

?>
<div class="container">
	<h1 class='my-4'>Reset Password</h1>
	<div class="row">
		<div class="col-md-12">
			
			<?php 
			if(isset($_POST['update']))
			{
				$pwd=md5($_POST['pwd']);
				$cpwd=md5($_POST['cpwd']);
				if($pwd==$cpwd)
				{
					mysqli_query($con,"update register set password='$pwd' where email='$key'");
					if(mysqli_affected_rows($con)==1)
					{
						echo "<p class='alert alert-success'>Password Updated Successfully</p>";
					}
				}
				else
				{
					echo "<p class='alert alert-danger'>Passwords Does not matched</p>";
				}
			}
			?>
		
			<form action="" method="POST">
				<table class="table">
					<tr>
						<td>New Password</td>
						<td><input type="password" name="pwd" class='form-control'></td>
					</tr>
					<tr>
						<td>Confirm New Password</td>
						<td><input type="password" name="cpwd" class='form-control'></td>
					</tr>
					<tr>
						<td></td>
						<td><input type="submit" name="update" value="Update" class='btn btn-primary'></td>
					</tr>
				</table>
			</form>
		</div>
	</div>
</div>

<?php 
include("footer.php");
?>