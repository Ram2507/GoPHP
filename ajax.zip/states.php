<html>
	<head>
		<title>AJAX With Example</title>
		<script>
		function getDistricts(state)
		{
			var obj;
			if(window.XMLHttpRequest)
			{
				obj=new XMLHttpRequest();
			}
			else
			{
				obj=new ActiveXObject("Microsoft.XMLHTTP");
			}
			
			obj.onreadystatechange=function(){
				if(obj.readyState==4 && obj.status==200)
				{
					document.getElementById("dist")
					.innerHTML=obj.responseText;
				}
			}
			
			obj.open("GET","dist.php?s="+state,true);
			obj.send();
		}
			
		</script>
	</head>
	<body>
	<?php 
	include("connect.php");
	$res=mysqli_query($con,"select distinct state from 
	states");
	?>
		<h1>State and District Example</h1>
		select State:<select  id="state" 
		onchange="getDistricts(this.value)">
			<option value="">--Select State--</option>
			<?php 
			while($row=mysqli_fetch_assoc($res))
			{
				?>
	<option value="<?php echo $row['state']; ?>">
	<?php echo $row['state']; ?></option>
				<?php
			}
			?>
		</select>
		
		select District:<select  id="dist">
			<option value="">--Select District--</option>
		</select>
	</body>
</html>