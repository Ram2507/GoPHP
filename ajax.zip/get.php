<h3>Score:240/6</h3>
<p><b>Batmans</b></p>
<p>Sharma:80(30)</p>
<p>Shikar:27(30)</p>

<p><b>Bowling</b></p>
<p>Nile:3-0-23-0</p>
<p>Milane:3-1-10-0</p>



