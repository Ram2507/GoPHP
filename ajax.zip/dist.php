<?php 
if(isset($_REQUEST['s']))
{
	include("connect.php");
	$state=$_REQUEST['s'];
	$res=mysqli_query($con,"select district from states
	where state='$state'");
	if(mysqli_num_rows($res))
	{
		echo "<option value=''>--Select District--</option>";
		while($row=mysqli_fetch_assoc($res))
		{
			?>
				<option value="<?php echo $row['district']?>">
				<?php echo $row['district']?></option>
			<?php
		}
	}
	
}
?>