-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 20, 2018 at 05:27 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `7am`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(32) NOT NULL,
  `role` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `email`, `password`, `role`) VALUES
(1, 'admin@mail.com', '21232f297a57a5a743894a0e4a801fc3', 'admin'),
(2, 'hr@mail.com', '202cb962ac59075b964b07152d234b70', 'hr');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `msg` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `mobile`, `msg`) VALUES
(1, 'ram kumar', 'ram@mail.com', 1212121212, 'Hello How are you'),
(2, 'ravi kumar', 'ravi@mail.com', 2434233423, 'welcome to php'),
(3, 'naresh m', 'naresh@mail.com', 32482323423, 'Hello'),
(4, 'suresh', 'suresh@mail.com', 988568956, 'welcome'),
(5, 'koti', 'koti@mail.com', 2423423, 'werwe'),
(6, 'naresh@mail.com', 'naresh', 12312312, 'Hello'),
(7, 'hello', 'hello@mail.com', 231, 'adea'),
(8, 'ram', 'ram@mauil.com', 12312312, 'asd'),
(9, 'naresh', 'ram@mauil.com', 12312312, 'sad'),
(10, 'naresh', 'ram@mauil.com', 12312312, 'sad'),
(13, 'lakshmi', 'lakshmi@mail.com', 12312132, 'hello');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `cid` int(11) NOT NULL,
  `title` varchar(250) NOT NULL,
  `description` text NOT NULL,
  `filename` varchar(250) NOT NULL,
  `start_date` date NOT NULL,
  `timing` varchar(50) NOT NULL,
  `rating` int(11) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Active',
  `posted_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `faculty_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`cid`, `title`, `description`, `filename`, `start_date`, `timing`, `rating`, `status`, `posted_date`, `faculty_name`) VALUES
(2, 'Java Training', 'Java technology allows you to work and play in a secure computing environment. Upgrading to the latest Java version improves the security of your system, as older versions do not include the latest security updates.\r\n\r\nJava allows you to play online games, chat with people around the world, calculate your mortgage interest, and view images in 3D, just to name a few.', 'Java.jpg', '2018-10-25', '7am-9am', 5, 'Active', '2018-09-18 08:42:29', 'Hari Krishna'),
(3, '.Net Training', 'Java technology allows you to work and play in a secure computing environment. Upgrading to the latest Java version improves the security of your system, as older versions do not include the latest security updates.\r\n\r\nJava allows you to play online games, chat with people around the world, calculate your mortgage interest, and view images in 3D, just to name a few.', 'Net.png', '2018-09-26', '7am-9am', 4, 'Active', '2018-09-18 08:45:16', 'Srinivas'),
(4, 'Python Training', 'he core of extensible programming is defining functions. Python allows mandatory and optional arguments, keyword arguments, and even arbitrary argument lists', 'python-logo-andrew-zeutzius.jpg', '2018-09-26', '7am-9am', 5, 'Active', '2018-09-18 08:48:01', 'Subbaraju'),
(5, 'UI/UX Training', 'This HTML tutorial contains hundreds of HTML examples. With our online HTML editor, you can edit the HTML, and click on a button to view the result.', 'WebProgrammingLogo.png', '2018-09-26', '7am-9am', 5, 'Active', '2018-09-18 08:49:29', 'Naveen Saggam');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `eid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `city` varchar(100) NOT NULL,
  `salary` float NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(50) NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`eid`, `name`, `email`, `mobile`, `city`, `salary`, `date`, `status`) VALUES
(7, 'ram', 'ram@mail.com', '7894561263', 'Hyderabad', 13000, '2018-09-11 08:53:34', 'Active'),
(8, 'siva', 'siva@mail.com', '9634545454', 'Hyderabad', 12000, '2018-09-18 10:17:50', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(32) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `state` varchar(50) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `city` varchar(50) NOT NULL,
  `terms` int(11) NOT NULL,
  `date_of_reg` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ip` varchar(30) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `profile_pic` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `username`, `email`, `password`, `gender`, `state`, `mobile`, `city`, `terms`, `date_of_reg`, `ip`, `status`, `profile_pic`) VALUES
(1, 'ram kumar', 'ram@mail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'Male', 'Telangana', '12312312', 'Hyderabad', 1, '2018-09-03 08:09:02', '::1', 1, 'luhgitwmjbapsorKoala.jpg'),
(2, 'naresh', 'naresh@mail.com', '202cb962ac59075b964b07152d234b70', 'Male', 'Andhrapradesh', '12312312', '', 1, '2018-09-03 08:21:13', '::1', 1, 'kcihmqvbjnoyepdDesert.jpg'),
(3, 'suresh', 'suresh@mail.com', '202cb962ac59075b964b07152d234b70', 'Male', 'Telangana', '0', '', 1, '2018-09-03 08:24:12', '::1', 0, ''),
(4, 'babburi', 'babburi@mail.com', '202cb962ac59075b964b07152d234b70', 'Male', 'Telangana', '0', '', 1, '2018-09-03 08:27:29', '::1', 0, ''),
(7, 'babburi', 'rambabburi@gmail.com', '202cb962ac59075b964b07152d234b70', 'Male', 'Andhrapradesh', '', '', 1, '2018-09-10 07:47:04', '::1', 1, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`eid`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `eid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
