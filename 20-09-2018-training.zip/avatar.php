<?php 
session_start();
if(isset($_SESSION['loggedin']))
{
	include("connect.php");
	include("header.php");
	
	$uid=$_SESSION['loggedin'];
	$res=mysqli_query($con,"select *from register where id=$uid");
	$row=mysqli_fetch_assoc($res);
	?>
		<div class="container">

      <!-- Page Heading/Breadcrumbs -->
      <h1 class="mt-4 mb-3">Dashboard
        <small>[Welcome to <?php echo ucfirst($row['username']);?>]</small>
      </h1>

      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">dashbaord</a>
        </li>
        <li class="breadcrumb-item active">upload avatar</li>
      </ol>

      <!-- Content Row -->
      <div class="row">
        <!-- Sidebar Column -->
        <?php include("leftmenu.php");?>
        <!-- Content Column -->
        <div class="col-lg-9 mb-4">
          <h2>Upload Avatar</h2>
		 <?php 
		 if(isset($_POST['submit']))
		 {
			 if(is_uploaded_file($_FILES['image']['tmp_name']))
			 {
				 $filename=$_FILES['image']['name'];
				 $tpath=$_FILES['image']['tmp_name'];
				 $type=$_FILES['image']['type'];
				 $size=$_FILES['image']['size'];
				 
				 $str=str_shuffle("abcdefghijklmnopqrstuvwxyz");
				 $ext=substr($str,5,15);
				 $newfile=$ext.$filename;
				 $arr=array(
					"image/png",
					"image/jpg",
					"image/jpeg",
					"image/gif",
					);
				 if(in_array($type,$arr))
				 {
					 $status=move_uploaded_file($tpath,"profiles/$newfile");
					 if($status==1)
					 {
						 mysqli_query($con,"update register set profile_pic='$newfile' where id=$uid");
						 if(mysqli_affected_rows($con)==1)
						 {
							 //header("Location:dasboard.php");
							 ?>
								<script>
									window.location="dashboard.php";
								</script>
							 <?php
						 }
						 else
						 {
							 echo "Sorry! Unable to upload. try again";
						 }
					 }
						 
				 }
				 else
				 {
					 echo "<p class='alert alert-danger'>Please select a valid image type</p>";
				 }
				 
			 }
			 else
			 {
				 echo "<p class='alert alert-danger'>Please select a file</p>";
			 }
		 }
		 ?>
			<form method="POST" action="" enctype='multipart/form-data'>
				<div class='form-group'>
					<label>Select Profile Pic</label>
					<input type="file" name="image">
				</div>
				
				<div class='form-group'>
					<input type="submit" name="submit" value="Upload" class='btn btn-primary'>
				</div>
			</form>
        </div>
      </div>
      <!-- /.row -->

    </div>
	<?php
	include("footer.php");
}
else
{
	header("Location:login.php");
}
?>