<?php session_start();
if(isset($_SESSION['adminlogin']))
{
	include("../connect.php");
	include("header.php");
	?>
		<div id="page-wrapper">
			<h2>Add Course</h2>
			-------
			----------
			-------
		</div>
	<?php
	include("footer.php");
}
else
{
	header("Location:index.php");
}
?>