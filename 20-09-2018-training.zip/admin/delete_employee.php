<?php 
include("../connect.php");
if(isset($_REQUEST['did']))
{
	$id=$_REQUEST['did'];
	mysqli_query($con,"delete from employee where eid=$id");
	if(mysqli_affected_rows($con)==1)
	{
		setcookie("success","Employee($id) deleted successfully",time()+2);
		header("location:view_employees.php");
	}
	else
	{
		echo "<p>Unable to delete. Try again</p>";
	}
}
else
{
	exit("Wrong Window");
}
?>

