<?php 
session_start();
if(isset($_SESSION['adminlogin']))
{
	include("../connect.php");
	include("header.php");
	$id=$_REQUEST['cid'];
	$res=mysqli_query($con,"select *from courses where cid=$id");
	$row=mysqli_fetch_assoc($res);
	?>
	<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
		<div id="page-wrapper">
			<h2>Edit Course</h2>
			
			<?php 
			if(isset($_REQUEST['status']))
			{
				echo "<p class='alert alert-success'>Course Updated Successfully</p>";
			}
			
			if(isset($_POST['update']))
			{
				//3.collecting form data
				$title=$_POST['ctitle'];
				$desc=$_POST['cdesc'];
				$rating=$_POST['crating'];
				$fname=$_POST['fname'];
				$timing=$_POST['timings'];
				$sdate=$_POST['sdate'];
				if(is_uploaded_file($_FILES['cimage']['tmp_name']))
				{
					$filename=$_FILES['cimage']['name'];
					$tpath=$_FILES['cimage']['tmp_name'];
					move_uploaded_file($tpath,"courses/$filename");
				}
				else
				{
					$filename=$row['filename'];
				}
				mysqli_query($con,"update courses
				set title='$title',
				description='$desc',
				rating='$rating',
				start_date='$sdate',
				timing='$timing',
				filename='$filename',
				faculty_name='$fname' where cid=$id");
				if(mysqli_affected_rows($con)==1)
				{
					

					?>
					<script>
						window.location="edit_course.php?cid=<?php echo $id;?>&status=true";
					</script>
					<?php
				}
			}
			?>
			
			<form onsubmit="return courseValidate()" method="POST" action="" enctype="multipart/form-data">
				<div class='form-group'>
					<label>Course Title</label>
					<input value="<?php echo $row['title']?>" class='form-control' onblur="checkvalue(this)" type="text" name="ctitle" id="ctitle">
				</div>
				<div class='form-group'>
					<label>Course Description</label>
					<textarea class='form-control' name="cdesc" id="cdesc"><?php echo $row['description']?></textarea>
				</div>
				<div class='form-group'>
					<label>Course Image</label>
					<input class='form-control' type="file" name="cimage" id="cimage">
					<?php
						if($row['filename']!="")
						{
							?>
								<img src="courses/<?php echo $row['filename'];?>" height="50" width="50">
							<?php
						}
					?>
				</div>
				<div class='form-group'>
					<label>Course Rating</label>
					<input value="<?php echo $row['rating']?>" class='form-control' type="number" name="crating" id="crating" max="5" min="1">
				</div>
				<div class='form-group'>
					<label>Faculty Name</label>
					<input value="<?php echo $row['faculty_name']?>" class='form-control' type="text" name="fname" id="fname">
				</div>
				<div class='form-group'>
					<label>Start Date</label>
					<input  value="<?php echo $row['start_date']?>" class='form-control' type="text" name="sdate" id="sdate">
				</div>
				<div class='form-group'>
					<label>Timings</label>
					<input value="<?php echo $row['timing']?>" class='form-control' placeholder="Example:9am-11am" type="text" name="timings" id="timings">
				</div>
				<div class='form-group'>
					
					<input class='btn btn-primary' type="submit" name="update" value="Update Course">
				</div>
			</form>
		</div>
	<?php
	include("footer.php");
}
else
{
	?>
		<script>
			window.location="index.php";
		</script>
	<?php
}
?>
<script>
		  $( function() {
			$( "#sdate" ).datepicker({
				dateFormat: "yy-mm-dd",
				maxDate: "+2m",
				minDate: "0",
			});
		  } );
	  </script>