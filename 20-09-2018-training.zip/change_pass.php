<?php 
session_start();
if(isset($_SESSION['loggedin']))
{
	include("connect.php");
	include("header.php");
	
	$uid=$_SESSION['loggedin'];
	$res=mysqli_query($con,"select *from register where id=$uid");
	$row=mysqli_fetch_assoc($res);
	
	?>
	<div class="container">

      <!-- Page Heading/Breadcrumbs -->
      <h1 class="mt-4 mb-3">Dashboard
        <small>[Welcome to <?php echo ucfirst($row['username']);?>]</small>
      </h1>

      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">dashbaord</a>
        </li>
        <li class="breadcrumb-item active">Change Password</li>
      </ol>

      <!-- Content Row -->
      <div class="row">
        <!-- Sidebar Column -->
        <?php include("leftmenu.php");?>
        <!-- Content Column -->
        <div class="col-lg-9 mb-4">
          <h2>Change Password</h2>
		 <?php 
		 if(isset($_POST['update']))
		 {
			 $opwd=md5($_POST['opwd']);
			 $npwd=md5($_POST['npwd']);
			 $cnpwd=md5($_POST['cnpwd']);
			 if($opwd==$row['password'])
			 {
				 if($npwd==$cnpwd)
				 {
					 mysqli_query($con,"update register set password='$npwd' where id=$uid");
					 if(mysqli_affected_rows($con)==1)
					 {
						echo "<p class='alert alert-success'>Password Changed Successfully</p>";
					 }
				 }
				 else
				 {
					 echo "<p class='alert alert-danger'>Passwords Does not matched</p>";
				 }
			 }
			 else
			 {
				 echo "<p class='alert alert-danger'>Old password does not matched</p>";
			 }
		 }
		 ?>
			<form method="POST" action="">
				<div class='form-group'>
					<label>Old Password</label>
					<input type="password" name="opwd" class='form-control'>
				</div>
				<div class='form-group'>
					<label>New Password</label>
					<input type="password" name="npwd" class='form-control'>
				</div>
				<div class='form-group'>
					<label>Confirm new Password</label>
					<input type="password" name="cnpwd" class='form-control'>
				</div>
				<div class='form-group'>
					<input type="submit" name="update" class='btn btn-primary' value="Update">
				</div>
			</form>
        </div>
      </div>
      <!-- /.row -->

    </div>
	<?php
	include("footer.php");
}
else
{
	header("Location:login.php");
}

?>