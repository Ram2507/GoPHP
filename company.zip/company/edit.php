<?php 
session_start();
if(isset($_SESSION['userlogin']))
{	include("connect.php");
	$uid=$_SESSION['userlogin'];
	$res=mysqli_query($con,"select username,state,city,id,profile_pic from register where id=$uid");
	$row=mysqli_fetch_assoc($res);
	
	include("header.php");
	?>
		<div class="container">

      <!-- Page Heading/Breadcrumbs -->
      <h1 class="mt-4 mb-3">Edit
        <small>profile</small>
      </h1>

      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="home.php">Home</a>
        </li>
        <li class="breadcrumb-item active">Edit</li>
      </ol>
	  
	  <div class="row">
			<div class='col-lg-3'>
				<?php include("left-menu.php");?>
			</div>
			<div class='col-lg-9'>
				
				<?php 
					if(isset($_COOKIE['msg']))
					{
						echo "<p class='alert alert-success'>Profile Updated Successfully</p>";
					}
				
					if(isset($_POST['update']))
					{
						$name=$_POST['uname'];
						$state=$_POST['state'];
						$city=$_POST['city'];
						
						mysqli_query($con,"update register set username='$name',
						state='$state',city='$city' where id=$uid");
						if(mysqli_affected_rows($con)==1)
						{
							setcookie("msg","success",time()+2);
							header("Location:edit.php");
						}
						else
						{
							echo "<p class='alert alert-danger'>Sorry! try Again</p>";
						}
					}
				?>
			
			
				<form action="" method="POST">
					<div class='form-group'>
						<label>User Name</label>
						<input value="<?php echo $row['username'] ?>" type="text" name="uname" id="uname" class='form-control'>
					</div>
					<div class='form-group'>
						<label>State</label>
<select class="form-control" name="state" id="state">
	<option>--Select State--</option>
	<option <?php if($row['state']=="Andhrapradesh") echo "selected";?> value="Andhrapradesh">Andhrapradesh</option>
	<option <?php if($row['state']=="Telangana") echo "selected";?> value="Telangana">Telangana</option>
	<option <?php if($row['state']=="Maharastra") echo "selected";?> value="Maharastra">Maharastra</option>
	<option <?php if($row['state']=="Uttarapradesh") echo "selected";?> value="Uttarapradesh">Uttarapradesh</option>
	<option <?php if($row['state']=="Bihar") echo "selected";?> value="Bihar">Bihar</option>
	<option <?php if($row['state']=="Goa") echo "selected";?> value="Goa">Goa</option>
	<option <?php if($row['state']=="Chattisgarh") echo "selected";?> value="Chattisgarh">Chattisgarh</option>
	<option <?php if($row['state']=="Jharkhand") echo "selected";?> value="Jharkhand">Jharkhand</option>
</select>
					</div>
					<div class='form-group'>
						<label>City</label>
						<input  value="<?php echo $row['city'] ?>"type="text" name="city" id="city" class='form-control'>
					</div>
					<div class='form-group'>
						
						<input type="submit" name="update" value="Update" class='btn btn-success'>
					</div>
				</form>
			</div>
			
	  </div>
	  
	  </div>
	<?php
	include("footer.php");
}
else
{
	header("Location:login.php");
}
?>