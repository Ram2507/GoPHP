<?php 
session_start();
if(isset($_SESSION['userlogin']))
{
	include("connect.php");
	$uid=$_SESSION['userlogin'];
	$res=mysqli_query($con,"select password,profile_pic from register where id=$uid");
	$row=mysqli_fetch_assoc($res);
	include("header.php");
	?>
		<div class="container">
			<h1 class="mt-4 mb-3">Change
				<small>password</small>
			</h1>

		  <ol class="breadcrumb">
			<li class="breadcrumb-item">
			  <a href="home.php">Home</a>
			</li>
			<li class="breadcrumb-item active">chnage password</li>
		  </ol>
	  
			<div class="row">
				<div class="col-lg-3">
					<?php include("left-menu.php");?>
				</div>
				<div class="col-lg-9">
				
					<?php 
					if(isset($_POST['update']))
					{
						$opwd=md5($_POST['opwd']);
						$npwd=md5($_POST['npwd']);
						$cnpwd=md5($_POST['cnpwd']);
						if($npwd==$cnpwd)
						{
							if($opwd==$row['password'])
							{
								mysqli_query($con,"update register set password='$npwd' where id=$uid");
								if(mysqli_affected_rows($con)==1)
								{
									echo "<p class='alert alert-success'>Password changed successfully</p>";
								}
							}
							else
							{
								echo "<p class='alert alert-danger'>Old Passwords does not matched with DB</p>";
							}
						}
						else
						{
							echo "<p class='alert alert-danger'>Passwords does not matched</p>";
						}
					}
					?>
				
					<form action="" method="POST">
						<div class="form-group">
							<label>Enter Old Password</label>
							<input type="password"
							name="opwd"
							class="form-control">
						</div>
						<div class="form-group">
							<label>New Password</label>
							<input type="password"
							name="npwd"
							class="form-control">
						</div>
						<div class="form-group">
							<label>Confirm New Password</label>
							<input type="password"
							name="cnpwd"
							class="form-control">
						</div>
						<div class="form-group">
							<input type="submit"
							name="update"
							class="btn btn-success"
							value="Update">
						</div>
					</form>
				</div>
			</div>
		</div>
	<?php
	include("footer.php");
}
else
{
	header("Location:login.php");
}
?>