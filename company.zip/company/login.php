<?php 
session_start();
include("header.php");
include("connect.php");
?>
	<div class="container">
		<!-- Page Heading/Breadcrumbs -->
      <h1 class="mt-4 mb-3">Login
        <small>Subheading</small>
      </h1>

      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.php">Home</a>
        </li>
        <li class="breadcrumb-item active">Login</li>
      </ol>
	  <div class="">
	  
	  <?php 
	  if(isset($_POST['login']))
	  {
		  $email=$_POST['email'];
		  $pass=md5($_POST['pwd']);
		  $result=mysqli_query($con,"select *from 
		  register where email='$email'");
		  if(mysqli_num_rows($result)==1)
		  {
			  $row=mysqli_fetch_assoc($result);
			  //print_r($row);
			  //password checking
			  if($pass==$row['password'])
			  {
				  if($row['status']=="Active")
				  {
					  //redirect to home page
					  $_SESSION['userlogin']=$row['id'];
					  header("Location:home.php");
				  }
				  else
				  {
					  echo "<p class='alert alert-warning'>
					  Please activate your account</p>";
				  }
			  }
			  else
			  {
				  echo "<p class='alert alert-danger'>
				  Wrong password entered</p>";
			  }
		  }
		  else
		  {
			  echo "<p class='alert alert-danger'>
			  Sorry! Email does not exits</p>";
		  }
	  }
	  ?>
	  
		<form method="POST" action="" 
		onsubmit="return validate()">
			<table class="table">
				<tr>
					<td>Email</td>
					<td><input class="form-control" 
					type="text" name="email" id="email"></td>
				</tr>
				<tr>
					<td>Passowrd</td>
					<td><input class="form-control" 
					type="password" name="pwd" id="pwd"></td>
				</tr>
				<tr>
					<td></td>
					<td>
						<input class="btn btn-danger" 
						type="submit" name="login" 
						value="Login">
							<a href="">Forgot Password?</a>
						</td>
				</tr>
			</table>
		</form>
	  </div>
	</div>
	<script>
		function validate(){
			if(document.getElementById("email").value=="")
			{
				alert("Enter Email");
				return false;
			}
			if(document.getElementById("pwd").value=="")
			{
				alert("Enter Password");
				return false;
			}
		}
	</script>
<?php 
include("footer.php");
?>