<?php 
session_start();
if(isset($_SESSION['userlogin']))
{
	include("connect.php");
	$uid=$_SESSION['userlogin'];
	$res=mysqli_query($con,"select profile_pic from register where id=$uid");
	$row=mysqli_fetch_assoc($res);
	include("header.php");
	?>
		<div class='container'>
			<h1 class="mt-4 mb-3">Upload
				<small>avatar</small>
			</h1>

		  <ol class="breadcrumb">
			<li class="breadcrumb-item">
			  <a href="home.php">Home</a>
			</li>
			<li class="breadcrumb-item active">upload avatar</li>
		  </ol>
		  <div class='row'>
			<div class='col-lg-3'>
				<?php include("left-menu.php");?>
			</div>
			<div class='col-lg-9'>
			
				<?php 
				if(isset($_POST['upload']))
				{
					if(is_uploaded_file($_FILES['image']['tmp_name']))
					{
						$filename=$_FILES['image']['name'];
						$tpath=$_FILES['image']['tmp_name'];
						$type=$_FILES['image']['type'];
						
						$new=str_shuffle("abcdefghijklmonpqrstuwxtzy".time());
						$ext=substr($new,5,20);
						$newfilename=$ext.$filename;
						$arr=array(
							"image/jpg",
							"image/png",
							"image/gif",
							"image/jpeg",
						);
						if(in_array($type,$arr))
						{
							move_uploaded_file($tpath,"profiles/$newfilename");
							mysqli_query($con,"update register set profile_pic='$newfilename' where id=$uid");
							if(mysqli_affected_rows($con)==1)
							{
								header("Location:home.php");
							}
							else
							{
								echo "<p>Sorry! Unable to update tray again</p>";
							}
						}
						else
						{
							echo "<p class='alert alert-danger'>Please select a valid file to upload</p>";
						}
					}
					else
					{
						echo "<p class='alert alert-danger'>Please select a file to upload</p>";
					}
				}
				?>
			
				<form method="POST" action="" enctype="multipart/form-data">
					<div class='form-group'>
						<label>Image to upload</label>
						<input type="file" name="image" class='form-control'>
					</div>
					<div class='form-group'>
						<input type="submit" name="upload" value="Upload" class='btn btn-success'>
					</div>
				</form>
			</div>
		  </div>
		</div>
	<?php
	include("footer.php");
}
else
{
	header("Location:login.php");
}
?>