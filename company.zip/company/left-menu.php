
          <div class="list-group">
			<?php 
				if($row['profile_pic']!="")
				{
					?>
						<a href="" class="list-group-item">
				<img src="profiles/<?php echo $row['profile_pic'];?>" height="50" width="50">
			</a>
					<?php
				}
			?>
            <a href="home.php" class="list-group-item">Dashboard</a>
            <a href="edit.php" class="list-group-item">Edit Profie</a>
			<a href="avatar.php" class="list-group-item">Upload Avatar</a>
            <a href="change_pwd.php" class="list-group-item">Change Password</a>
			<a href="logout.php" class="list-group-item">Logout</a>
          </div>
