<?php 
session_start();
if(isset($_SESSION['userlogin']))
{
	include("connect.php");
	$uid=$_SESSION['userlogin'];
	
	//get the data of loggedin user
	$result=mysqli_query($con,"select *from register where id=$uid");
	$row=mysqli_fetch_assoc($result);
	
	include("header.php");
	?>
		<div class="container">
			<h1 class="mt-4 mb-3">Welcome to
			<small><?php echo ucfirst($row['username']);?>!</small>
		  </h1>
		  <ol class="breadcrumb">
			<li class="breadcrumb-item">
			  <a href="home.php">Dashboard</a>
			</li>
			<li class="breadcrumb-item active"><?php echo ucfirst($row['username']);?>!</li>
      </ol>
	  <div class="row">
        <!-- Sidebar Column -->
		<div class="col-lg-3 mb-4">
        <?php 
			include("left-menu.php");
		?>
		</div>
        <!-- Content Column -->
        <div class="col-lg-9 mb-4">
          <h2>Profile Information</h2>
			<table class='table'>
				<tr>
					<td>Name</td>
					<td><?php echo $row['username'];?></td>
				</tr>
				<tr>
					<td>Email</td>
					<td><?php echo $row['email'];?></td>
				</tr>
				<tr>
					<td>Gender</td>
					<td><?php echo $row['gender'];?></td>
				</tr>
				<tr>
					<td>State</td>
					<td><?php echo $row['state'];?></td>
				</tr>
				<tr>
					<td>Date of Reg</td>
					<td><?php echo $row['date_of_reg'];?></td>
				</tr>
				<tr>
					<td>City</td>
					<td><?php echo $row['city'];?></td>
				</tr>
			</table>
        </div>
      </div>
	  
		</div>
	<?php
	include("footer.php");
}
else
{
	header("Location:login.php");
}

?>