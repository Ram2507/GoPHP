<?php session_start();
if(isset($_SESSION['admin_login_true']))
{
	include("admin_header.php");
	?>
		<div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="#">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Users</li>
      </ol>
      <!-- Icon Cards-->
      <div class="row">
        
        <h1>Display Users</h1>
        
        
      </div>
      <!-- Area Chart Example-->
      
      
      <!-- Example DataTables Card-->
      
    </div>
	<?php
	include("admin_footer.php");
}
else
{
	header("Location:index.php");
}
?>