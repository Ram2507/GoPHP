<?php 
include("connect.php");
include("header.php");
?>
<div class="container">
	<h1 class='my-4'>Forgot Password</h1>
	<div class="row">
	<div class='col-md-12'>
	<?php 
	if(isset($_POST['submit']))
	{
		$email=$_POST['email'];
		$result=mysqli_query($con,"select id,email,username from register 
		where email='$email'");
		if(mysqli_num_rows($result)==1)
		{
			$row=mysqli_fetch_assoc($result);
			$id=base64_encode($row['email']);
			$to=$email;
			$subject="Reset Password Link-GoPHP";
			$message="Hi ".$row['username'].",<br><br>
			Thanks, your reset password request has been received
			.please click below link to reset your password<br><br>
			<a href='http://localhost:100/project9am/reset_pwd.php?key=$id'>Reset Password</a><br><br>Thanks<br>Team";
			$mheaders="Content-Type:text/html";
			if(@mail($to,$subject,$message,$mheaders))
			{
				echo "<p class='alert alert-success'>Please check your Email. Reset Password link sent</p>";
			}
			else
			{
				echo "<p class='alert alert-success'>Please check your Email. Reset Password link sent</p>";
			}
		}
		else
		{
			echo "<p class='alert alert-danger'>Sorry! Email does not exists</p>";
		}
	}
	?>
	</div>
	
		<div class="col-md-12">
			<form method="post" action="" onsubmit="return validate()">
				<div class="form-group">
					<label>Enter Email</label>
					<input id="email" class="form-control" type="text" name="email">
				</div>
				
				<div class="form-group">
					<input class="btn btn-primary" type="submit" name="submit" value="Submit">
				</div>
				
			</form>
		</div>
	</div>
</div>
<script>
	function validate()
	{
		if(document.getElementById("email").value=="")
		{
			alert("Enter Email");
			return false;
		}
			
	}
</script>
<?php
include("footer.php");
?>