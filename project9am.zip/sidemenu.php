<div class="list-group">
            <a href="home.php" class="list-group-item">Home</a>
            <a href="edit.php" class="list-group-item">Edit Profile</a>
            <a href="avatar.php" class="list-group-item">Upload Avatar</a>
            <a href="change_pwd.php" class="list-group-item">Change Password</a>
            <a href="logout.php" class="list-group-item">Logout</a>
            
          </div>