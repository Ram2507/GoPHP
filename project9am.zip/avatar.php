<?php 
session_start();
if(isset($_SESSION['login_true']))
{
	$logid=$_SESSION['login_true'];
	include("connect.php");
	include("header.php");
	?>
		<div class='container'>
		<h1 class='my-4'>Upload Avatar</h1>
		
		<?php 
		if(isset($_POST['upload']))
		{
			if(is_uploaded_file($_FILES['image']['tmp_name']))
			{
				$filename=$_FILES['image']['name'];
				$type=$_FILES['image']['type'];
				$tmp=$_FILES['image']['tmp_name'];
				$types=array(
					"image/jpeg",
					"image/jpg",
					"image/png",
					"image/gif",
				);
				if(in_array($type,$types))
				{
					if(move_uploaded_file($tmp,"avatars/$filename"))
					{
						mysqli_query($con,"update register set profile_pic='$filename' where id=$logid");
						if(mysqli_affected_rows($con)>0)
						{
							header("Location:home.php");
						}
						else
						{
							echo "<p class='alert alert-danger'>Sorry! Unable to Update Try again</p>";
						}
					}
					else
					{
						echo "Sorry! Unable to move Try again";
					}
				}
				else
				{
					echo "<p class='alert alert-danger'>Please select valid  File</p>";
				}
			}
			else
			{
				echo "<p class='alert alert-danger'>Please select a File</p>";
			}
		}
		?>
		
			<div class="row">
				<div class='col-lg-3 mb-4'>
					<?php include("sidemenu.php");?>
				</div>
				<div class='col-lg-9 mb-4'>
					<form method="POST" action="" enctype="multipart/form-data">
						<div class='form-group'>
							<label>Upload Image</label>
							<input type="file" name="image" class='form-control'>
						</div>
						<div class='form-group'>
							<input type="submit" name="upload" class='btn btn-primary' value="Upload">
						</div>
					</form>
				</div>
				
			</div>
		</div>
	<?php
	include("footer.php");
}
else
{
	header("Location:login.php");
}
?>