<?php 
include("header.php");
?>
<div class="container">
			<h1 class="my-4">Register Here</h1>
			
			<?php 
			include("connect.php");
			if(isset($_POST['register']))
			{
				$name=$_POST['uname'];
				$email=$_POST['email'];
				$pwd=md5($_POST['pwd']);
				$mobile=$_POST['mobile'];
				$gender=(isset($_POST['gender'])) ? $_POST['gender']:"";
				$terms=(isset($_POST['terms'])) ? $_POST['terms']:"";
				$city=$_POST['city'];
				$state=$_POST['state'];
				$dob=date("Y-m-d",strtotime($_POST['dob']));
				$ip=$_SERVER['REMOTE_ADDR'];
				
				mysqli_query($con,"insert into register(username,email,
				password,
				mobile,gender,dob,city,state,terms,
				ip) values('$name','$email','$pwd','$mobile',
				'$gender','$dob','$city','$state','$terms',
				'$ip')");
				if(mysqli_affected_rows($con)==1)
				{
					//echo "Thanks.Account Created";
					$uid=mysqli_insert_id($con);
					$to=$email;
					$subject="Activation Link-GoPHP";
					$message="Hello ".$name.",<br><br>
					Thanks, For crteating an account with us.
					your account details are:
					username:your email<br>Password:".$_POST['pwd']."<br>
					<br>
					Please click the below link to activate your account
					<a target='_blank' 
					href='http://localhost:100/9am/activate.php?key=$uid'>
					Activate Now</a><br><br>
					Thnaks
					<br>Team";
					//echo $message;
					$mheadres="Content-Type:text/html";
					if(mail($to,$subject,$message,$mheadres))
					{
						echo "<P>Thanks, Account Created Successfully. 
						Please activate your account</p>";
					}
					else
					{
						echo "<p>Sorry! Unable to Send . 
						Please contact Admin</p>";
					}
				}
				else
				{
					echo "Sorry! Unable to create an account. 
					Try again";
				}
			}
			?>
			
			<form method="POST" action="" onsubmit="return validate()">
				<table class="table table-striped table-hover">
				<tr>
					<td>Username*</td>
					<td><input class="form-control" id="uname" type="text" name="uname"></td>
				</tr>
				<tr>
					<td>Email*</td>
					<td><input class="form-control" id="email" type="text" name="email"></td>
				</tr>
				<tr>
					<td>Password*</td>
					<td><input class="form-control" id="pwd" type="password" name="pwd"></td>
				</tr>
				<tr>
					<td>Confirm Password*</td>
					<td><input class="form-control" id="cpwd" type="password" name="cpwd"></td>
				</tr>
				<tr>
					<td>Mobile*</td>
					<td><input class="form-control" id="mobile" type="text" name="mobile"></td>
				</tr>
				<tr>
					<td>Gender</td>
					<td>
						<input type="radio" value="Male" name="gender"> Male
						<input type="radio" value="Female" name="gender"> Female
					</td>
				</tr>
				<tr>
					<td>DOB</td>
					<td><input class="form-control" type="text" name="dob"></td>
				</tr>
				<tr>
					<td>City</td>
					<td><input class="form-control" type="text" name="city"/></td>
				</tr>
				<tr>
					<td>State</td>
					<td><select name="state" class="form-control">
						<option value="">--Select State--</option>
						<option value="Andhrapradesh">Andhrapradesh</option>
						<option value="Telangana">Telangana</option>
						<option value="Maharastra">Maharastra</option>
						<option value="Uttarapradesh">Uttarapradesh</option>
					</select></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="checkbox" name="terms" 
value="1"/>
					Please accept Terms and Conditions</td>
				</tr>
				<tr>
					<td></td>
					<td><input class="btn btn-danger" type="submit" name="register" 
					value="Register"></td>
				</tr>
			</table>
			</form>
		</div>
		<script>
			function validate()
			{
				if(document.getElementById("uname").value=="")
				{
					alert("Enter Username");
					return false;
				}
				if(document.getElementById("email").value=="")
				{
					alert("Enter Email");
					return false;
				}
				
			}			
		</script>
	<?php 
	include("footer.php");
	?>