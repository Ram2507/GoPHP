<?php 
session_start();
if(isset($_SESSION['login_true']))
{
	include("connect.php");
	$lid=$_SESSION['login_true'];
	$result=mysqli_query($con,"select *from register where id=$lid");
	$row=mysqli_fetch_assoc($result);
	
	?>
		<?php 
include("header.php");
?>

<div class="alert alert-success text-center">
	<?php 
	if($row['profile_pic']!="")
	{
		?>
			<img style="border-radius:50%; border:2px solid green; padding:2px;" class='img-circle' 
	src="avatars/<?php echo $row['profile_pic'];?>" height="80" width="80">
		<?php
	}
		
	?>
  <h3>Welcome to <?php echo ucfirst($row['username']);?></h3>
</div>
    <!-- Page Content -->
    <div class="container">

      <!-- Page Heading/Breadcrumbs -->
      
		
      
      <!-- Content Row -->
      <div class="row">
        <!-- Sidebar Column -->
        <div class="col-lg-3 mb-4">
          <?php include("sidemenu.php"); ?>
        </div>
        <!-- Content Column -->
        <div class="col-lg-9 mb-4">
          <h4>Personla Information</h4>
			<table class="table">
				<tr>
					<td>Name</td>
					<td><?php echo ucfirst($row['username']);?></td>
				</tr>
				<tr>
					<td>Email</td>
					<td><?php echo $row['email'];?></td>
				</tr>
				<tr>
					<td>Mobile</td>
					<td><?php echo $row['mobile'];?></td>
				</tr>
				<tr>
					<td>City</td>
					<td><?php echo $row['city'];?></td>
				</tr>
				<tr>
					<td>State</td>
					<td><?php echo $row['state'];?></td>
				</tr>
				<tr>
					<td>DOB</td>
					<td><?php echo $row['dob'];?></td>
				</tr>
				<tr>
					<td>Date of Reg.</td>
					<td><?php echo $row['date_of_reg'];?></td>
				</tr>
			</table>
        </div>
      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->

    <?php 
include("footer.php");
?>
	<?php
}
else
{
	header("Location:login.php");
}

?>