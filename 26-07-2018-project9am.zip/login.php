<?php 
session_start();
include("connect.php");
include("header.php");
?>

<div class="container">
	<h1 class='my-4'>Login here</h1>
	
	<?php 
	if(isset($_POST['login']))
	{
		$email=$_POST['email'];
		$pwd=md5($_POST['pwd']);
		$result=mysqli_query($con,"select *from register where 
		email='$email'");
		if(mysqli_num_rows($result)==1)
		{
			$row=mysqli_fetch_assoc($result);
			if($row['password']==$pwd)
			{
				if($row['status']=='Active')
				{
					$_SESSION['login_true']=$row['id'];
					header("Location:home.php");
				}
				else
				{
					echo "<p class='alert alert-warning'>
					Please activate your account</p>";
				}
			}
			else
			{
				echo "<p class='alert alert-danger text-center'>
				Sorry! Password does not mtached</p>";
			}
		}
		else
		{
			echo "<p class='text-center alert alert-danger'>
			Sorry! This email does not exists</p>";
		}
	}
	?>
	
	<form method="POST" action="">
				<table class="table table-striped table-hover">
				
				<tr>
					<td>Email*</td>
					<td><input class="form-control" id="email" 
					type="text" name="email"></td>
				</tr>
				<tr>
					<td>Password*</td>
					<td><input class="form-control" id="pwd" 
					type="password" name="pwd"></td>
				</tr>
				<tr>
					<td></td>
					<td><input class="btn btn-primary" type="submit" 
					name="login" 
					value="Login">
						<a href="forgot.php">Forgot Password?</a>
						&nbsp; | &nbsp; <a href='register.php'>
						Create an acocount</a>
					</td>
				</tr>
			</table>
			</form>
</div>

<?php 
include("footer.php");
?>