<?php session_start();
if(isset($_SESSION['admin_login_true']))
{
	include("../connect.php");
	include("admin_header.php");
	?>
		<div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="#">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Orders</li>
      </ol>
      <?php 
	  $result=mysqli_query($con,
	  "select register.id,register.username,
register.mobile,register.city,
orders.oid,orders.pname,orders.cost,orders.date 
FROM
register JOIN orders ON
register.id=orders.id");
	  ?>
      <div class="row">
        <div class="col-xl-9 mb-3">
			<h1>Orders</h1>
			<?php 
			if(mysqli_num_rows($result)>0)
			{
				?>
					<table class="table">
						<tr>
							<th>ID</th>
							<th>Username</th>
							<th>City</th>
							<th>Mobile</th>
							
							<th>Oid</th>
							<th>Product Name</th>
							<th>Cost</th>
							
						</tr>
						<?php 
						while($row=mysqli_fetch_assoc($result))
						{
					
							?>
								<tr>
									<td><?php echo $row['id']?></td>
									<td><?php echo $row['username']?></td>
									<td><?php echo $row['city']?></td>
									<td><?php echo $row['mobile']?></td>
									<td><?php echo $row['oid']?></td>
									<td><?php echo $row['pname']?></td>
									<td><?php echo $row['cost']?></td>
									
									
								</tr>
							<?php
						}
						?>
				</table>
				<?php
			}
			else
			{
				echo "<P class='alert alert-info'>No Users Found</p>";
			}
			?>
        </div>        
      </div>
      <!-- Area Chart Example-->
      
      
      <!-- Example DataTables Card-->
      
    </div>
	<?php
	include("admin_footer.php");
}
else
{
	header("Location:index.php");
}
?>