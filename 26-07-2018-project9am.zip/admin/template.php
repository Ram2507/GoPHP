<?php session_start();
if(isset($_SESSION['admin_login_true']))
{
	include("admin_header.php");
	?>
		<div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="#">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Users</li>
      </ol>
      <!-- Icon Cards-->
      <div class="row">
        
        <div class="col-md-9">
				<h1>Add News</h1>
        </div>
        
      </div>
      <!-- Area Chart Example-->
      
      
      <!-- Example DataTables Card-->
      
    </div>
	<?php
	include("admin_footer.php");
}
else
{
	header("Location:index.php");
}
?>