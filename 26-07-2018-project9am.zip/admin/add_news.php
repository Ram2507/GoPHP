<?php 
session_start();
if(isset($_SESSION['admin_login_true']))
{
	include("../connect.php");
	include("admin_header.php");
	?>
	<div class="content-wrapper">
		<div class="container-fluid">
		  <!-- Breadcrumbs-->
		  <ol class="breadcrumb">
			<li class="breadcrumb-item">
			  <a href="#">Dashboard</a>
			</li>
			<li class="breadcrumb-item active">Add News</li>
		  </ol>
		  <!-- Icon Cards-->
		  <div class="row">
			
			<div class="col-md-9">
				<h1>Add News</h1>
				<?php 
				if(isset($_REQUEST['status']))
				{
					echo "<p class='alert alert-success'>News Added Successfully</p>";
				}
				?>
				<?php 
					if(isset($_POST['add']))
					{
						$cat=$_POST['cat'];
						$title=$_POST['title'];
						$desc=$_POST['desc'];
						if(is_uploaded_file($_FILES['image']['tmp_name']))
						{
							$filename=$_FILES['image']['name'];
							$tmp=$_FILES['image']['tmp_name'];
							move_uploaded_file($tmp,"news/$filename");
						}
						else
						{
							$filename="";
						}
						mysqli_query($con,"insert into
						news(category,title,description,image,posted_date)
						values('$cat','$title','$desc','$filename',now())");
						if(mysqli_affected_rows($con)>0)
						{
							//setcookie("success","News Added Successfully",time()+2);
							//header("Location:add_news.php?status=true");
							?>
								<script>
									window.location="add_news.php?status=true";
								</script>
							<?php
						}
					}
					
				?>
				
				
				<form method="post" action="" enctype="multipart/form-data" onsubmit="return NewsValidate()">
					<div class='form-group'>
						<label>Category</label>
						<select name="cat" class="form-control" id="cat">
							<option value="">--select category--</option>
							<option value="Movies">Movies</option>
							<option value="Politics">Politics</option>
							<option value="Sports">Sports</option>
						</select>
					</div>
					<div class='form-group'>
						<label>News Title</label>
						<input type="text" name="title" id="title" class='form-control'>
					</div>
					<div class='form-group'>
						<label>News Description</label>
						<textarea name="desc" id="desc" class='form-control'></textarea>
					</div>
					<div class='form-group'>
						<label>Upload news image</label>
						<input type="file" name="image"  class='form-control'>
					</div>
					<div class='form-group'>
						<input type="submit" name="add" value="Add News" class='btn btn-primary'>
					</div>
				</form>
			</div>
			
			
		  </div>
		  <!-- Area Chart Example-->
		  
		  
		  <!-- Example DataTables Card-->
		  
		</div>
		<script>
			function NewsValidate()
			{
				
				if($("#cat").val()=="")
				{
					alert("select Category");
					return false;
				}
				if($("#title").val()=="")
				{
					alert("Eneter Title");
					return false;
				}
				if($("#desc").val()=="")
				{
					alert("Eneter Description");
					return false;
				}
				
			}
		</script>
		
	<?php
	include("admin_footer.php");
}
else
{
	header("Location:index.php");
}
?>



