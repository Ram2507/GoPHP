-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 22, 2018 at 08:28 AM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 7.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `9am`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `email`, `password`, `status`) VALUES
(1, 'admin', 'admin@mail.com', '202cb962ac59075b964b07152d234b70', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(32) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `dob` date NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `terms` int(11) NOT NULL,
  `date_of_reg` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ip` varchar(30) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Inactive',
  `profile_pic` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `username`, `email`, `password`, `mobile`, `gender`, `dob`, `city`, `state`, `terms`, `date_of_reg`, `ip`, `status`, `profile_pic`) VALUES
(1, 'ram', 'ram@mail.com', '202cb962ac59075b964b07152d234b70', 1212121212, 'Male', '0000-00-00', 'Hyderabad', 'Telangana', 1, '2018-07-17 09:42:01', '::1', 'Inactive', ''),
(2, 'naresh', 'naresh@mail.com', '202cb962ac59075b964b07152d234b70', 7897897894, 'Male', '1987-12-12', 'Hyderabad', 'Telangana', 1, '2018-07-17 09:48:51', '::1', 'Active', 'Jellyfish.jpg'),
(3, 'suresh', 'suresh@mail.com', '827ccb0eea8a706c4c34a16891f84e7b', 1212121212, 'Male', '1970-01-01', 'Hyderabad', 'Telangana', 1, '2018-07-17 10:03:21', '::1', 'Inactive', ''),
(4, 'Ravi Kumar', 'ravi@mail.com', 'e10adc3949ba59abbe56e057f20f883e', 98857767740, 'Male', '1987-12-12', 'Pune', 'Uttarapradesh', 1, '2018-07-17 10:08:20', '::1', 'Active', 'Lighthouse.jpg'),
(5, '', '', 'd41d8cd98f00b204e9800998ecf8427e', 0, '', '1970-01-01', '', '', 0, '2018-07-19 10:13:12', '::1', 'Inactive', ''),
(6, 'ram', 'rambabburi123@gmail.com', '202cb962ac59075b964b07152d234b70', 1212121212, 'Male', '1987-12-12', 'Hyderabad', 'Maharastra', 1, '2018-07-19 10:14:42', '::1', 'Inactive', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
