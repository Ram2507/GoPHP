<style>
.link{
	text-decoration:none;
}
.link:hover{
	background:#fff;
}
</style>
<?php 
include("header.php");
include("connect.php");
if(isset($_REQUEST['aid']))
{
	$id=$_REQUEST['aid'];
	$result=mysqli_query($con,"select *from news where id=$id");
	if(mysqli_num_rows($result)>0)
	{
		$row=mysqli_fetch_assoc($result);
		?>
			<div class="container">
		<div class="row">
			<div class='col-md-9'>
				<h3 class='my-4'><?php echo $row['title'] ?></h3>
				<img height="200" width="800" src="admin/news/<?php echo $row['image']?>">
				<p><?php echo $row['description']?></p>
			</div>
			<div class='col-md-3'>
				<h3 class='my-4'> Related Articles</h3>
				<?php 
				$aresult=mysqli_query($con,"select id,title from news where id !=$id");
				if(mysqli_num_rows($aresult))
				{
					?>
					<ul class='nav'>
						<?php while($row=mysqli_fetch_assoc($aresult))
						{
							?>
								<li style="background:#efefef;margin:2px;border-bottom:1px solid #1e6a9b; padding:5px;">
								<a class="link" href="news.php?aid=<?php echo $row['id'] ?>"><?php echo $row['title']?></a></li>
							<?php
						}	
						?>
					</ul>
					<?php
				}
				?>
				
			</div>
		</div>
	</div>
		<?php
	}
	else
	{
		echo "<p class='alert alert-warning'>Sorry! No records Found</p>";
	}
}
else
{
	header("Location:index.php");
}
?>
	
<?php
include("footer.php");
?>