<?php 
session_start();
if(isset($_SESSION['loggedin']))
{
	include("connect.php");
	include("header.php");
	
	$uid=$_SESSION['loggedin'];
	$res=mysqli_query($con,"select *from register where id=$uid");
	$row=mysqli_fetch_assoc($res);
	
	?>
		<!-- Page Content -->
    <div class="container">

      <!-- Page Heading/Breadcrumbs -->
      <h1 class="mt-4 mb-3">Dashboard
        <small>[Welcome to <?php echo ucfirst($row['username']);?>]</small>
      </h1>

      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">dashbaord</a>
        </li>
        <li class="breadcrumb-item active">Edit Profile</li>
      </ol>

      <!-- Content Row -->
      <div class="row">
        <!-- Sidebar Column -->
        <?php include("leftmenu.php");?>
        <!-- Content Column -->
        <div class="col-lg-9 mb-4">
          <h2>Edit Profile</h2>
		  
		  <?php 
		  if(isset($_REQUEST['status']))
		  {
			  echo "<p class='alert alert-success'>Profile Updated Successfully</p>";
		  }
		  
		  if(isset($_POST['update']))
		  {
			  $uname=$_POST['uname'];
			  $mobile=$_POST['mobile'];
			  $city=$_POST['city'];
			  $state=$_POST['state'];
			  
			  mysqli_query($con,"update register set username='$uname',
			  mobile='$mobile',state='$state',
			  city='$city' where id=$uid");
			  if(mysqli_affected_rows($con)==1)
			  {
					//header("Location:edit.php?status=true");
					?>
						<script>
							window.location="edit.php?status=true";
						</script>
					<?php
			  }
			  else
			  {
				  echo "<p>Sorry! Unable to Update tray again</p>";
			  }
		  }
		  ?>
		  
		  
			<form method="POST" action="">
				<div class="form-group">
					<label>Username</label>
					<input value="<?php echo $row['username']?>" type="text" name="uname" class="form-control">
				</div>
				<div class="form-group">
					<label>Mobile</label>
					<input value="<?php echo $row['mobile'];?>" type="text" name="mobile" class="form-control">
				</div>
				<div class="form-group">
					<label>City</label>
					<input value="<?php echo $row['city'];?>" type="text" name="city" class="form-control">
				</div>
				<div class="form-group">
					<label>State</label>
					<select class="form-control" 
						name="state" id="state">
							<option>--Select State--</option>
							<option <?php if($row['state']=="Andhrapradesh") echo "selected"?> value="Andhrapradesh">Andhrapradesh</option>
							<option <?php if($row['state']=="Telangana") echo "selected"?> value="Telangana">Telangana</option>
							<option <?php if($row['state']=="Maharastra") echo "selected"?> value="Maharastra">Maharastra</option>
							<option <?php if($row['state']=="Uttarapradesh") echo "selected"?> value="Uttarapradesh">Uttarapradesh</option>
						</select>
				</div>
				<div class="form-group">
					
					<input type="submit" value="Update" name="update" class="btn btn-primary">
				</div>
			</form>
        </div>
      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->
	<?php
	
	include("footer.php");
	
	$uid=$_SESSION['loggedin'];
	$res=mysqli_query($con,"select *from register where id=$uid");
	$row=mysqli_fetch_assoc($res);
	
}
else
{
	header("Location:login.php");
}
?>