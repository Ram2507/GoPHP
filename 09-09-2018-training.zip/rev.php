<?php 

$str="HelloWorld";
$s="";
for($i=strlen($str);$i>=0;$i--)
{
	@$s.=$str[$i];
}
echo $s;
?>